/* ==================== TEAMEVALUATIE (na de wedstrijd) ====================
   Onderdeel van de teams.js-modulaire split. Team-niveau evaluatie na een
   wedstrijd (8 categorieën + tags + toelichtingen) en het bijbehorende
   dashboard/geschiedenis, plus de "Stats"-tab die dit combineert met de
   spelersstatistieken uit wedstrijd.js. */
import {
  db, collection, doc, addDoc, deleteDoc, updateDoc
} from './firebase.js?v=20261106h';
import {
  S, $, $$, esc, meld, datumNL, openModal, sluitModal, toon, modAan
} from './state.js?v=20261106h';
import { NIVEAUS, niveauKleur, TEAM_CATEGORIEEN, TEAM_TAGS, teamCategorie, SEIZOEN_FALLBACK } from './config.js?v=20261106h';
import { ico } from './icons.js?v=20261106h';

import { htmlStats } from './wedstrijd.js?v=20261106h';
import { telGebruik } from './tracker.js?v=20261106h';

/* Kleine lokale kopie van de deelnemer-helper (ook aanwezig in teams-spelers.js)
   — bewust hier gedupliceerd i.p.v. een cross-module import voor één regel. */
function deelnemer(){
  return { uid: S.user.uid, naam: (S.team.ledenInfo?.[S.user.uid]?.naam) || S.user.displayName || S.user.email || '' };
}

export function modalTeamEvaluatie(wedstrijdId){
  if (!modAan('evaluaties')) return meld('Evaluaties staan uit voor dit team');
  const w = S.wedstrijden.find(x => x.id === wedstrijdId);
  if (!w) return meld('Kon de wedstrijd niet vinden, probeer de pagina te verversen');
  const bestaande = S.teamEvaluaties.find(e => e.wedstrijdId === wedstrijdId) || null;
  const scores = {...(bestaande?.scores || {})};
  let gekozenTags = new Set(bestaande?.tags || []);

  const kleurbalk = (catId) => `<div class="kleurbalk" data-cat="${catId}">${NIVEAUS.slice(1).map(n =>
    `<button data-niv="${n.n}" class="kn${n.n} ${scores[catId]===n.n?'gekozen':''}"><span class="lbl">${n.label.toUpperCase()}</span></button>`).join('')}</div>`;

  const catBlok = (c) => `
    <div class="cat-eval-kop">
      <div class="veldlabel u-m-0">${esc(c.naam)}</div>
      <div class="cat-eval-status" data-status="${c.id}"></div>
    </div>${kleurbalk(c.id)}`;

  openModal(`
    <h2>${bestaande?'Team-evaluatie bijwerken':'Team evalueren'}</h2>
    <div class="snel-kop">
      <div class="mini-shirt"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg></div>
      <div><div class="nm">${esc(S.team.naam)} – ${esc(w.tegenstander)}</div>
        <div class="pos">${datumNL(w.datum)}${w.thuis!=null?(w.thuis?'<span class="sep" aria-hidden="true"></span>Thuis':'<span class="sep" aria-hidden="true"></span>Uit'):''}</div></div>
    </div>

    <div class="te-samenvatting">
      <div class="te-ring" id="mTeRing">—</div>
      <div class="te-sam-tekst" id="mTeSam">Vul in wat je opviel, categorieën die je overslaat tellen niet mee.</div>
    </div>

    ${TEAM_CATEGORIEEN.map(catBlok).join('')}

    <div class="veldlabel">Opvallend (optioneel)</div>
    <div class="tag-rij" id="mTeTags">${TEAM_TAGS.map(t =>
      `<button class="tag ${gekozenTags.has(t.id)?'aan':''}" data-tag="${t.id}">${t.ico?ico(t.ico,16):t.emoji} ${t.label}</button>`).join('')}</div>

    <div class="veldlabel">Wat ging het beste? (optioneel)</div>
    <textarea class="invoer" id="mTeGoed" rows="2" placeholder="Bijv. de druk vooraan zorgde voor balwinst hoog op het veld">${esc(bestaande?.notitieGoed||'')}</textarea>

    <div class="veldlabel">Aandachtspunt voor volgende training? (optioneel)</div>
    <textarea class="invoer" id="mTeAandacht" rows="2" placeholder="Bijv. rustiger opbouwen vanuit de verdediging">${esc(bestaande?.notitieAandacht||'')}</textarea>

    <button class="knop vol fluo u-mt-sm" id="mTeOk" >${bestaande?'Bijwerken':'Opslaan'}</button>
    ${bestaande?`<button class="knop vol gevaar u-mt-xs" id="mTeWeg" >Verwijderen</button>`:''}
    <p class="u-t-xs u-zacht u-mt-sm u-lh-ruim"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.2"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2M6.3 6.3l1.5 1.5M16.2 16.2l1.5 1.5M17.7 6.3l-1.5 1.5M7.8 16.2l-1.5 1.5"/></svg> Alleen ingevulde categorieën tellen mee in de groeicurve. Na een drukke wedstrijd hoef je niet alles in te vullen.</p>`);

  const werkSamenvattingBij = () => {
    const ingevuld = Object.keys(scores).length;
    const vals = Object.values(scores);
    const gem = vals.length ? vals.reduce((a,b)=>a+b,0)/vals.length : 0;
    const ring = $('#mTeRing');
    if (ring){
      ring.textContent = ingevuld ? gem.toFixed(1).replace('.',',') : '—';
      ring.style.background = ingevuld ? niveauKleur(Math.max(1, Math.round(gem))) : 'var(--surface-2)';
    }
    const sam = $('#mTeSam');
    if (sam) sam.innerHTML = ingevuld
      ? `<b>${ingevuld} van ${TEAM_CATEGORIEEN.length}</b> categorieën ingevuld. De rest mag je overslaan.`
      : `Vul in wat je opviel, categorieën die je overslaat tellen niet mee.`;
    for (const c of TEAM_CATEGORIEEN){
      const el = $(`[data-status="${c.id}"]`);
      if (el){
        const aan = scores[c.id] != null;
        el.textContent = aan ? 'Ingevuld' : 'Overslaan mag';
        el.classList.toggle('klaar', aan);
      }
    }
    const ok = $('#mTeOk');
    if (ok) ok.textContent = (bestaande?'Bijwerken':'Opslaan') + ` (${ingevuld} van ${TEAM_CATEGORIEEN.length})`;
  };

  $$('.kleurbalk[data-cat] [data-niv]').forEach(b => b.onclick = () => {
    const wrap = b.closest('.kleurbalk'); const catId = wrap.dataset.cat;
    const al = b.classList.contains('gekozen');
    wrap.querySelectorAll('[data-niv]').forEach(x => x.classList.remove('gekozen'));
    if (al){ delete scores[catId]; } // nogmaals tikken = categorie overslaan
    else { scores[catId] = Number(b.dataset.niv); b.classList.add('gekozen'); }
    werkSamenvattingBij();
  });
  $$('#mTeTags [data-tag]').forEach(b => b.onclick = () => {
    const id = b.dataset.tag;
    if (gekozenTags.has(id)) gekozenTags.delete(id); else gekozenTags.add(id);
    b.classList.toggle('aan');
  });
  werkSamenvattingBij();

  $('#mTeOk').onclick = async () => {
    if (!Object.keys(scores).length) return meld('Vul minstens één categorie in');
    const ok = await bewaarTeamEvaluatie(wedstrijdId, {
      scores, tags:[...gekozenTags],
      notitieGoed:$('#mTeGoed').value.trim(), notitieAandacht:$('#mTeAandacht').value.trim(),
    });
    if (ok) sluitModal();
  };
  const wegBtn = $('#mTeWeg');
  if (wegBtn) wegBtn.onclick = async () => {
    if (!confirm('Deze teamevaluatie verwijderen?')) return;
    await deleteDoc(doc(db,'teams',S.teamId,'teamevaluaties',bestaande.id));
    sluitModal();
  };
}

/* [20260923a] Opslaan van een teamevaluatie, gedeeld door de modal hierboven
   en het desktopscherm "Evaluatie" (inline invullen naast de radar).
   Zelfde documentvorm als voorheen; geeft true terug bij succes. */
export async function bewaarTeamEvaluatie(wedstrijdId, { scores, tags = [], notitieGoed = '', notitieAandacht = '' }){
  const w = S.wedstrijden.find(x => x.id === wedstrijdId);
  if (!w){ meld('Kon de wedstrijd niet vinden, probeer de pagina te verversen'); return false; }
  if (!scores || !Object.keys(scores).length){ meld('Vul minstens één categorie in'); return false; }
  const bestaande = S.teamEvaluaties.find(e => e.wedstrijdId === wedstrijdId) || null;
  const data = {
    wedstrijdId, tegenstander:w.tegenstander, datum:w.datum, scores,
    tags:[...tags], notitieGoed, notitieAandacht,
    door:deelnemer(), gemaaktMs:Date.now(),
  };
  if (!bestaande) data.seizoen = S.huidigSeizoen || SEIZOEN_FALLBACK;
  try {
    if (bestaande) await updateDoc(doc(db,'teams',S.teamId,'teamevaluaties',bestaande.id), data);
    else await addDoc(collection(db,'teams',S.teamId,'teamevaluaties'), data);
    telGebruik('team_evaluatie');
    meld('Teamevaluatie opgeslagen');
    return true;
  } catch(e){ meld('Opslaan mislukt: '+(e.code||e.message)); return false; }
}

/* --- Dashboard-berekeningen --- */
function teamEvalGemiddelde(ev){
  const vals = TEAM_CATEGORIEEN.map(c => ev.scores?.[c.id]).filter(Boolean);
  return vals.length ? vals.reduce((a,b) => a+b, 0) / vals.length : 0;
}
function teamEvalLaagsteCategorie(ev){
  let laagste = null;
  for (const c of TEAM_CATEGORIEEN){
    const s = ev.scores?.[c.id]; if (!s) continue;
    if (!laagste || s < laagste.score) laagste = {id:c.id, score:s};
  }
  return laagste;
}

/* Historie: alle ingevulde teamevaluaties van dit team (gefilterd op het
   gekozen seizoen), nieuw → oud, met een mini kleurenstrip per categorie.
   Standaard tonen we de laatste 6; "Toon eerdere" onthoudt S._histAlles
   zodat de knop niet telkens terugklapt bij een re-render. */
function htmlTeamEvalHistorie(evalsOudNieuw){
  const evals = [...evalsOudNieuw].reverse(); // nieuw → oud
  const LIMIET = 6;
  const getoond = S._histAlles ? evals : evals.slice(0, LIMIET);
  const rest = evals.length - getoond.length;

  const rij = ev => {
    const gem = teamEvalGemiddelde(ev);
    return `
    <button class="hist-item" data-open-teameval="${ev.wedstrijdId}">
      <div class="hist-cijfer" style="background:${gem?niveauKleur(Math.round(gem)):'var(--surface-2)'}">${gem?gem.toFixed(1).replace('.',','):'—'}</div>
      <div class="hist-tekst">
        <div class="hist-titel">${esc(ev.tegenstander||'Onbekend')}</div>
        <div class="hist-datum">${datumNL(ev.datum)}</div>
        <div class="hist-strip">${TEAM_CATEGORIEEN.map(c => `<span style="background:${ev.scores?.[c.id]?niveauKleur(ev.scores[c.id]):'var(--surface-2)'}"></span>`).join('')}</div>
      </div>
      <div class="hist-pijl">›</div>
    </button>`;
  };

  return `
    <div class="kaart">
      <div class="sectie-kop u-mt-0"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.4" y="4.6" width="17.2" height="4.4" rx="1.8"/><path d="M5.2 9v10.4h13.6V9"/><path d="M10 13h4"/></svg> Historie<span class="sep" aria-hidden="true"></span>al je evaluaties</div>
      ${getoond.map(rij).join('')}
      ${rest > 0 ? `<button class="hist-meer" data-hist-toon-meer>Toon ${rest} eerdere wedstrijd${rest===1?'':'en'}</button>` : ''}
    </div>`;
}

export function htmlTeamEvaluatieDashboard(){
  const alleSeizoenen = S.statsSeizoen === 'alles';
  const evals = alleSeizoenen ? S.teamEvaluaties : S.teamEvaluaties.filter(e => e.seizoen === S.statsSeizoen); // oud → nieuw
  if (!evals.length){
    return `<div class="kaart leeg">Nog geen teamevaluaties${alleSeizoenen?'':' dit seizoen'}.<br>Vul na de eerstvolgende wedstrijd "Team evalueren" in op het wedstrijdscherm, daarna verschijnt hier de groeicurve.</div>`;
  }
  const laatste = evals[evals.length-1];
  const vorige = evals.length > 1 ? evals[evals.length-2] : null;
  const gemLaatste = teamEvalGemiddelde(laatste);
  const gemVorige = vorige ? teamEvalGemiddelde(vorige) : null;
  const verschil = gemVorige != null ? gemLaatste - gemVorige : null;

  // --- SVG-groeicurve: teamontwikkelscore per evaluatie ---
  const laatste8 = evals.slice(-8);
  const W = 300, H = 90, pad = 14;
  const punten = laatste8.map((ev,i) => {
    const x = laatste8.length > 1 ? pad + (i/(laatste8.length-1)) * (W-2*pad) : W/2;
    const g = teamEvalGemiddelde(ev);
    const y = H - pad - ((g-1)/4) * (H-2*pad); // schaal 1..5 -> boven/onder
    return {x, y};
  });
  const lijnPad = punten.map(p => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
  const laatstePunt = punten[punten.length-1];

  // --- categorieën: gemiddelde + trend over de laatste 5 evaluaties ---
  const laatste5 = evals.slice(-5);
  const vorige5  = evals.slice(-10,-5);
  const catGemiddelde = (lijst, catId) => {
    const vals = lijst.map(e => e.scores?.[catId]).filter(Boolean);
    return vals.length ? vals.reduce((a,b)=>a+b,0)/vals.length : null;
  };
  const catRijen = TEAM_CATEGORIEEN.map(c => {
    const nu = catGemiddelde(laatste5, c.id);
    const was = catGemiddelde(vorige5, c.id);
    const trend = (nu==null || was==null) ? '→' : (nu - was > 0.15 ? '↗' : nu - was < -0.15 ? '↘' : '→');
    const kleur = nu==null ? 'var(--surface-2)' : nu>=4.5?'var(--n5)':nu>=3.5?'var(--n4)':nu>=2.5?'var(--n3)':nu>=1.5?'var(--n2)':'var(--n1)';
    return {naam:c.naam, nu, trend, kleur};
  });

  // --- terugkerende aandachtspunten: welke categorie is het vaakst de laagste, laatste 4 evaluaties ---
  const laatste4 = evals.slice(-4);
  const laagsteTellingen = {};
  for (const ev of laatste4){
    const l = teamEvalLaagsteCategorie(ev); if (!l) continue;
    laagsteTellingen[l.id] = (laagsteTellingen[l.id]||0) + 1;
  }
  // Alleen signaleren als een categorie én vaak de laagste is (≥2×) én absoluut
  // laag scoort (gemiddelde < 3 over de laatste 5). Zo wordt een team dat overal
  // ruim voldoende scoort niet onterecht op zijn relatief-laagste onderdeel afgerekend.
  const DREMPEL = 3;
  const signalen = Object.entries(laagsteTellingen)
    .filter(([catId,n]) => n >= 2 && (catGemiddelde(laatste5, catId) ?? 5) < DREMPEL)
    .sort((a,b) => b[1]-a[1])
    .map(([catId,n]) => ({cat:teamCategorie(catId), n}));
  // groeiers: categorie die het sterkst is gestegen (laatste 5 t.o.v. de 5 daarvoor)
  const groeiers = catRijen.filter(c => c.trend === '↗').sort((a,b) => (b.nu||0)-(a.nu||0)).slice(0,1);

  // --- advies: zwakste categorie van de laatste evaluatie(s), gekoppeld aan leercurve-thema indien aanwezig ---
  const adviesCat = signalen[0]?.cat || teamCategorie(teamEvalLaagsteCategorie(laatste)?.id);

  return `
    <div class="kaart">
      <div class="sectie-kop u-mt-0"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg> Groeicurve</div>
      <div style="margin:var(--space-2xs) 0 var(--space-3xs)">
        <span class="u-fw-7 u-t-5xl" style="font-family:'Barlow Condensed'">${gemLaatste.toFixed(1).replace('.',',')}</span><span class="u-t-sm u-zacht"> / 5</span>
        <div class="u-t-xs u-zacht u-mb-xs">Laatste wedstrijd (${esc(laatste.tegenstander)}, ${datumNL(laatste.datum)})${verschil!=null?`<span class="sep" aria-hidden="true"></span><span style="color:${verschil>=0?'var(--ok)':'var(--warn)'};font-weight:700">${verschil>=0?'↑':'↓'} ${Math.abs(verschil).toFixed(1).replace('.',',')} t.o.v. vorige</span>`:''}</div>
      </div>
      ${punten.length > 1 ? `
      <svg viewBox="0 0 ${W} ${H}" style="width:100%;height:90px">
        <polyline points="${lijnPad}" fill="none" stroke="var(--accent)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
        <circle cx="${laatstePunt.x}" cy="${laatstePunt.y}" r="4.5" fill="var(--accent)"/>
        <line x1="${pad}" y1="${H-pad}" x2="${W-pad}" y2="${H-pad}" stroke="var(--line-d)" stroke-width="1"/>
      </svg>` : `<p class="u-t-sm u-zacht">Nog minstens 2 evaluaties nodig voor een lijn.</p>`}
    </div>

    ${htmlTeamEvalHistorie(evals)}

    <div class="kaart">
      <div class="sectie-kop u-mt-0">Categorieën<span class="sep" aria-hidden="true"></span>laatste ${Math.min(5,evals.length)} wedstrijden</div>
      ${catRijen.map(c => `
        <div style="display:flex;align-items:center;gap:var(--space-sm);padding:var(--space-xs) 0;border-bottom:1px solid var(--hair)">
          <span class="u-flex-1 u-t-sm u-fw-6">${esc(c.naam)}</span>
          <span style="width:80px;height:8px;border-radius:4px;background:var(--surface-2);overflow:hidden;flex-shrink:0">
            <span style="display:block;height:100%;border-radius:4px;width:${c.nu?Math.round((c.nu/5)*100):0}%;background:${c.kleur}"></span>
          </span>
          <span class="u-fw-7 u-t-base" style="width:34px;text-align:right;font-family:'Barlow Condensed'">${c.nu?c.nu.toFixed(1).replace('.',','):'—'}</span>
          <span style="width:16px;text-align:center;font-size:calc(12px * var(--fs));color:${c.trend==='↘'?'var(--warn)':'var(--ink-2)'}">${c.trend}</span>
        </div>`).join('')}
    </div>

    <div class="kaart">
      <div class="sectie-kop u-mt-0"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg> Terugkerende aandachtspunten</div>
      ${signalen.length ? signalen.map(s => `
        <div style="display:flex;align-items:flex-start;gap:var(--space-sm);padding:var(--space-xs) 0;border-bottom:1px solid var(--hair)">
          <div class="u-mt-2xs" style="width:9px;height:9px;border-radius:50%;background:var(--warn);flex-shrink:0"></div>
          <div><div class="u-fw-6 u-t-md">${esc(s.cat.naam)}</div>
            <div class="u-t-xs u-zacht" style="margin-top:1px">Laagst scorende onderdeel in ${s.n} van de laatste ${laatste4.length} wedstrijden.</div></div>
        </div>`).join('') : ''}
      ${groeiers.length && groeiers[0].nu ? `
        <div style="display:flex;align-items:flex-start;gap:10px;padding:9px 0;${signalen.length?'':''}">
          <div class="u-mt-2xs" style="width:9px;height:9px;border-radius:50%;background:var(--ok);flex-shrink:0"></div>
          <div><div class="u-fw-6 u-t-md">${esc(groeiers[0].naam)}</div>
            <div class="u-t-xs u-zacht" style="margin-top:1px">Positieve trend de laatste wedstrijden.</div></div>
        </div>` : ''}
      ${(!signalen.length && !groeiers.length) ? `<p class="u-t-sm u-zacht">Nog geen duidelijk patroon, na een paar evaluaties verschijnen hier terugkerende punten.</p>` : ''}
    </div>

    ${adviesCat ? `
    <div class="kaart" ${adviesCat.leercurve?`data-thema-info="${esc(adviesCat.leercurve)}" style="background:linear-gradient(150deg,var(--accent),var(--grass-2));border:none;cursor:pointer"`:`style="background:linear-gradient(150deg,var(--accent),var(--grass-2));border:none"`}>
      <div class="u-t-2xs u-fw-7 u-mb-2xs" style="color:color-mix(in srgb, var(--wit) 85%, transparent);text-transform:uppercase;letter-spacing:.4px"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.2"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2M6.3 6.3l1.5 1.5M16.2 16.2l1.5 1.5M17.7 6.3l-1.5 1.5M7.8 16.2l-1.5 1.5"/></svg> Voorgesteld trainingsthema</div>
      <div class="u-fw-7 u-t-2xl u-mb-2xs" style="color:var(--wit);font-family:'Barlow Condensed';text-transform:uppercase">${esc(adviesCat.leercurve || adviesCat.naam)}${adviesCat.leercurve?' <span class="u-t-md" style="opacity:.85">›</span>':''}</div>
      <div class="u-t-sm u-lh-ruim" style="color:color-mix(in srgb, var(--wit) 90%, transparent)">${adviesCat.leercurve
        ? `Leercurve-thema uit het jeugdbeleidsplan (§3.3), sluit direct aan op "${esc(adviesCat.naam)}", het onderdeel dat nu aandacht vraagt.`
        : `"${esc(adviesCat.naam)}" vraagt nu de meeste aandacht, geen apart leercurve-thema, wel een mooi gespreksonderwerp voor de volgende training.`}</div>
      ${adviesCat.leercurve?`<div class="u-t-2xs u-mt-xs u-fw-6" style="color:color-mix(in srgb, var(--wit) 75%, transparent)">Tik voor achtergrond en oefentips →</div>`:''}
    </div>` : ''}`;
}

/* Alle seizoenen die voorkomen in de wedstrijden/presentie van dit team,
   plus het huidige seizoen (ook als er nog geen data voor is), nieuwste eerst. */
function seizoenenLijst(){
  const set = new Set();
  if (S.huidigSeizoen) set.add(S.huidigSeizoen);
  for (const w of (S.wedstrijden||[])) if (w.seizoen) set.add(w.seizoen);
  for (const p of (S.presentie||[])) if (p.seizoen) set.add(p.seizoen);
  return [...set].sort((a,b) => (parseInt(b)||0) - (parseInt(a)||0));
}
/* Seizoensfilter (huidig seizoen + "Alle", oudere seizoenen als tweede rij).
   Gedeeld door de Stats-tab (spelersstatistieken) en de Evaluatie-pagina
   (teamevaluatie-dashboard); beide binden data-seizoenfilter zelf. */
export function htmlSeizoenFilter(){
  if (!S.statsSeizoen) S.statsSeizoen = S.huidigSeizoen || 'alles';
  const seizoenen = seizoenenLijst();
  if (!seizoenen.length) return '';
  const huidig = S.huidigSeizoen || seizoenen[0];
  const oudere = seizoenen.filter(sz => sz !== huidig); // eerdere seizoenen
  const alleActief = S.statsSeizoen === 'alles' || oudere.includes(S.statsSeizoen);
  return `
    <div class="segment" id="statsSeizoen" style="margin-bottom:${alleActief && oudere.length ? '8' : '10'}px">
      ${huidig ? `<button data-seizoenfilter="${esc(huidig)}" class="${S.statsSeizoen===huidig?'actief':''}">${esc(huidig)}</button>` : ''}
      <button data-seizoenfilter="alles" class="${alleActief?'actief':''}">Alle</button>
    </div>
    ${alleActief && oudere.length ? `
    <div class="segment segment-sub u-mb-sm" id="statsSeizoenOud" >
      <button data-seizoenfilter="alles" class="${S.statsSeizoen==='alles'?'actief':''}">Alle seizoenen</button>
      ${oudere.map(sz => `<button data-seizoenfilter="${esc(sz)}" class="${S.statsSeizoen===sz?'actief':''}">${esc(sz)}</button>`).join('')}
    </div>` : ''}`;
}

/* De Stats-tab bevat sinds de hub-navigatie alleen nog de spelersstatistieken;
   het teamevaluatie-dashboard woont op de Evaluatie-pagina (hub-tegel
   Wedstrijden → Evaluatie, samengesteld in teams.js). */
export function htmlStatsTab(){
  return htmlSeizoenFilter() + htmlStats() + `
    <button class="knop licht vol u-mt-md" id="statsExcelExport" >
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 19V10"/><path d="M11 19V5"/><path d="M18 19v-7"/></svg> Exporteer naar Excel</button>`;
}

