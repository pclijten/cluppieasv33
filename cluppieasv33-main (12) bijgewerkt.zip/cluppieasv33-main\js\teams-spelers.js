/* ==================== SPELERSPROFIEL (teams.js-modulaire split) ====================
   Onderdeel van de teams.js-modulaire split. Alles rond een individuele
   speler: het spelersoverzicht, het spelersprofiel (leerlijn, tijdlijn,
   ontwikkelbeoordelingen: snel + volledig), leerpunten, spelergegevens
   bewerken, én het uitlenen van een speler aan een ander team binnen de
   club (thematisch dezelfde "speler"-context, vandaar in één bestand). */
import {
  db, collection, doc, addDoc, deleteDoc, updateDoc, setDoc,
  getDoc, getDocs, query, where, serverTimestamp, documentId, deleteField
} from './firebase.js?v=20261106h';
import {
  S, $, $$, esc, meld, datumNL, speler, uurMin, openModal, sluitModal, modAan, isBeheerder
} from './state.js?v=20261106h';
import {
  niveau, niveauKleur, NIVEAUS, SKILLS, skillDomein,
  LEERCURVE, leercurveRelevant, leercurveThema, snelTag, SNEL_TAGS,
  POSITIE_GROEPEN, SEIZOEN_FALLBACK, AFWEZIG_REDENEN, afwezigRedenInfo,
  wisselReden, isToernooi
} from './config.js?v=20261106h';
import { analyseWedstrijd, speeltijdReserve, disciplinaireTijd, telaatTijd, persoonlijkeNoemer } from './analyse.js?v=20261106h';
import { isBouwCoordinator } from './coordinatoren.js?v=20261106h';
import { ico } from './icons.js?v=20261106h';
import { rondesVoorTeam, rondeSpelers, datumKort } from './evaluatierondes.js?v=20261106h';

import { toonThemaInfo } from './teams-leerlijn.js?v=20261106h';
import { telGebruik } from './tracker.js?v=20261106h';
import { opkomstVoor, teltMee } from './opkomst.js?v=20261106h';
import { heeftElftallen, filterOpElftal, elftalPillen } from './elftallen.js?v=20261106h';

/* Cross-module her-render: teams.js importeert functies van hieruit, dus
   deze module mag teams.js niet statisch terug-importeren (circulaire
   import). Dynamic import() binnen de aanroepende functie is het patroon
   dat de rest van de app ook al gebruikt (zie club.js/wedstrijd.js). */
async function herrenderTeam(){
  const m = await import('./teams.js?v=20261106h');
  m.renderTeam();
}

export function htmlSpelers(){
  // laatste snelle beoordeling per speler → kleurstip
  const laatsteSnel = {};
  for (const b of S.beoordelingen){
    if (b.soort !== 'snel') continue;
    if (!laatsteSnel[b.spelerId]) laatsteSnel[b.spelerId] = b;   // lijst is al op datum gesorteerd
  }
  const openLeerpunten = pid => {
    const p = speler(pid);
    return ((p?.leerpunten)||[]).filter(l => !l.klaar).length + ((p?._bronLeerpunten)||[]).length;
  };
  const evalAan = modAan('evaluaties');

  return `
    ${evalAan ? `<div class="segment u-mb-md" id="spelersModus" >
      <button data-modus="selectie" class="actief">Selectie</button>
      <button data-modus="snel">${ico('training-favorite', 15)} Snel beoordelen</button>
    </div>` : ''}

    <div class="avg-balk">
      <span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4.6" y="10.4" width="14.8" height="9.8" rx="2.4"/><path d="M8 10.4V8a4 4 0 0 1 8 0v2.4"/><circle cx="12" cy="15.2" r="1.4" fill="currentColor" stroke="none"/></svg></span>
      <span>Beoordelingen en leerpunten zijn alleen zichtbaar voor coaches van dit team. Spelers en ouders zien deze gegevens niet.</span>
    </div>

    <button class="knop vol licht u-mb-md" id="nieuweSpeler" >+ Speler toevoegen</button>
    ${(() => {
      const eigen = S.spelers.filter(p => !p._ingeleend);
      const spelerRij = (p, ingeleend) => {
        const b = laatsteSnel[p.id];
        const stip = !evalAan ? ''
                   : b ? `<span class="beoordeel-stip" style="background:${niveauKleur(b.niveau)}" title="Laatste: ${esc(niveau(b.niveau)?.label||'')}"></span>`
                       : `<span class="beoordeel-stip leeg" title="Nog niet beoordeeld"></span>`;
        const lp = openLeerpunten(p.id);
        const heeftNotitie = !!(p.notitie && p.notitie.trim());
        const pos = meestGespeeldePositie(p);
        // Subregel onder de naam: herkomst (ingeleend), uitgeleend-aan, en/of
        // positie, subtiel grijs. Een uitgeleende speler blijft gewoon
        // opstelbaar bij ons — het label maakt alleen zichtbaar dat hij ook
        // elders speelt, zodat je dat zelf tegen de klok kan houden.
        const subDelen = [];
        if (ingeleend) subDelen.push(p._gast ? `gast, gekoppeld aan uitleen van ${esc(p._bronTeamNaam||'ander team')}` : `ingeleend van ${esc(p._bronTeamNaam||'ander team')}`);
        if (p._uitgeleendAan) subDelen.push(`⇄ ook bij ${esc(p._uitgeleendAan)}`);
        if (pos) subDelen.push(esc(pos));
        const sub = subDelen.length
          ? `<div class="speler-sub">${subDelen.join(', ')}</div>` : '';
        return `
        <button class="speler-rij" data-open-profiel="${p.id}">
          <div class="mini-shirt"${ingeleend?' style="background:var(--ink-2)"':''}>${esc(p.nummer ?? '·')}</div>
          <div class="n">${esc(p.naam)}${sub}</div>
          ${lp ? `<span class="chip-info">${lp} leerpunt${lp===1?'':'en'}</span>` : ''}
          ${heeftNotitie ? `<span class="notitie-vlag" title="Heeft een coach-notitie">!</span>` : ''}
          ${ingeleend ? `<span class="chip-info u-c-ok" style="background:rgba(53,196,122,.15)">ingeleend</span>` : ''}
          ${p._uitgeleendAan ? `<span class="chip-info" style="cursor:pointer" data-uitleen-terug="${p._leenIdUit}" title="Terughalen">⇄ terug</span>` : ''}
          ${stip}
          <span class="pijl">›</span>
        </button>`;
      };

      let h = eigen.length
        ? eigen.map(p => spelerRij(p, false)).join('')
        : `<div class="kaart leeg">Nog geen spelers.<br>Voeg je selectie toe, naam en rugnummer is genoeg.</div>`;

      // Ingeleende spelers (zonder gast-koppeling): draaien volwaardig mee.
      const in_ = S.spelers.filter(p => p._ingeleend && !p._gast);
      if (in_.length){
        h += `<div class="sectie-kop">⇄ Ingeleend</div>`;
        h += in_.map(p => spelerRij(p, true)).join('');
      }

      // Gastspelers: nog-te-koppelen placeholders + gekoppelde (echte) gasten.
      const gasten = S.spelers.filter(p => p._gast);
      if (gasten.length){
        h += `<div class="sectie-kop"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="8" r="3.2"/><path d="M5.5 20a6.5 6.5 0 0 1 13 0"/></svg> Gastspelers</div>`;
        h += gasten.map(g => {
          if (g._gekoppeld) return spelerRij(g, true);   // zelfde rij als 'Ingeleend' → toont ook positie + leerpunten
          return `<button class="speler-rij" data-open-profiel="${g.id}" style="border-style:dashed">
            <div class="mini-shirt" style="background:transparent;border:1px dashed var(--ink-2)">${esc(g.nummer ?? '?')}</div>
            <div class="n">${esc(g.naam)}<div class="u-t-2xs u-zacht" style="font-weight:400">gast<span class="sep" aria-hidden="true"></span>nog te koppelen</div></div>
            <span class="chip-info u-zacht" style="background:rgba(139,149,161,.15)">gast</span>
            <span class="pijl">›</span>
          </button>`;
        }).join('');
      }

      // Gast aanmaken — alleen zinvol binnen een club (uitleen bestaat dan).
      if (S.team?.club){
        h += `<button class="knop klein licht u-w-100 u-mt-sm" id="nieuweGast" >+ Gastspeler aanmaken</button>`;
      }
      return h;
    })()}

    <p class="u-t-xs u-zacht u-mt-sm u-lh-ruim">
      <span class="notitie-vlag inline">!</span> toont een coach-notitie. Het gekleurde stipje toont de laatste snelle beoordeling. Tik op een speler voor het volledige profiel met statistieken, leerlijn en historie.</p>`;
}

/* ==================== BEOORDELINGEN ====================
   Datamodel (Firestore: teams/{teamId}/beoordelingen/{id}):
     soort:    'snel' | 'volledig'
     spelerId, datum:'YYYY-MM-DD'
     bron:     {type:'wedstrijd'|'training'|'los', id, label}
     niveau:   1..5            (soort 'snel')
     tags:     ['inzet',...]   (soort 'snel')
     scores:   {T,I,P,S}       (soort 'volledig')
     notities: {algemeen} of {T,I,P,S}
     door:     {uid, naam}, gemaaktMs
   Leerpunten leven als array op het spelerdoc (lopen dóór over beoordelingen):
     {id, domein, tekst, sinds, klaar, klaarOp} */

/* Meest gespeelde positie voor de spelertegel. Telt over alle wedstrijden hoe
   vaak de speler op elke positie stond (uit spelerStats().posities, dat de
   specifieke positienamen bijhoudt) en kiest de vaakst voorkomende. Nog geen
   speelhistorie? Val terug op de ingestelde voorkeurspositie (p.positie). */
function meestGespeeldePositie(p){
  const pos = spelerStats(p.id).posities || {};
  let best = null, max = 0;
  for (const [naam, n] of Object.entries(pos)){
    if (n > max){ max = n; best = naam; }
  }
  return best || p.positie || null;
}

/* [20260923a] geëxporteerd voor de desktopschermen (kaarten, profiel, stats). */
/* [20260928e] Optioneel elftal ('1' | '2'): alleen de wedstrijden van dat
   elftal (teams met een 1e + 2e elftal). Zonder argument: alles, zoals altijd. */
export function spelerStats(pid, elftal = null){
  let wedstrijden = 0, tijd = 0, keeper = 0, goals = 0, assists = 0;
  const posities = {};
  const lijst = elftal ? filterOpElftal(S.wedstrijden, elftal) : S.wedstrijden;
  for (const w of lijst){
    for (const g of (w.goals||[])){
      if (g.type !== 'voor') continue;
      if (g.pid === pid) goals++;
      if (g.assist === pid) assists++;
    }
    const a = analyseWedstrijd(w);
    if (!a.kwarten) continue;
    if (a.tijd[pid]){ tijd += a.tijd[pid]; wedstrijden++; }
    if (a.keeper[pid]) keeper += a.keeper[pid];
    if (a.lijn[pid]) for (const [naam, n] of Object.entries(a.lijn[pid])) posities[naam] = (posities[naam]||0) + n;
  }
  // Opkomst over alleen de trainingen die voor deze speler meetellen — zie
  // js/opkomst.js. `overTr` is wat daarbuiten viel (vóór zijn instroom).
  const sp = speler(pid) || {id:pid};
  const o = opkomstVoor(sp, S.presentie||[]);
  const totTr = o.totaal, overTr = o.overgeslagen;
  const afwPerReden = {}; // redenId -> aantal
  for (const sessie of (S.presentie||[])){
    if (!teltMee(sessie, sp)) continue;
    if (!(sessie.afwezig||[]).includes(pid)) continue;
    const rec = (sessie.afwezigRedenen||{})[pid];
    const info = rec ? afwezigRedenInfo(rec) : null;
    const id = info?.id || 'geen';
    afwPerReden[id] = (afwPerReden[id]||0) + 1;
  }
  const opkomst = o.pct;
  // reserve/speelbaar + percentages over wedstrijden waarin de speler in de selectie zat
  const sr = speeltijdReserve(lijst)[pid] || {speeltijd:0, reserve:0, speelbaar:0};
  const reserve = sr.reserve;
  const speelbaar = sr.speelbaar;
  const pctSpeeltijd = speelbaar > 0 ? Math.round((sr.speeltijd/speelbaar)*100) : null;
  const pctReserve   = pctSpeeltijd != null ? 100 - pctSpeeltijd : null;
  return {wedstrijden, tijd, keeper, goals, assists, opkomst, totTr, overTr, afwPerReden, posities,
    reserve, speelbaar, pctSpeeltijd, pctReserve, disciplinair: sr.disciplinair||0};
}

/* Meest gespeelde posities voor een speler, aflopend gesorteerd: [{naam, n}, ...] */
/* [20260923c] geëxporteerd voor de desktop-bewerkpagina. */
export function meestGespeeldePosities(pid){
  const posities = spelerStats(pid).posities;
  return Object.entries(posities)
    .map(([naam, n]) => ({naam, n}))
    .sort((a, b) => b.n - a.n);
}

function laatsteVolledig(pid){
  return S.beoordelingen.find(b => b.spelerId === pid && b.soort === 'volledig') || null;
}

function tipsBalk(score){
  let segs = '';
  for (let i = 1; i <= 5; i++)
    segs += `<div class="tips-seg" style="background:${i <= score ? niveauKleur(score) : 'rgba(255,255,255,.08)'}"></div>`;
  return `<div class="tips-track">${segs}</div>`;
}

/* ===================== Vorige teams: scope-toggle + dossier-weergave =====================
 * Een definitief overgezette speler heeft bij het nieuwe team bevroren dossiers
 * (subcollectie vorigeTeams, zie bouwOverdrachtDossier). Alleen het spelersprofiel
 * kijkt ernaar; teamcijfers blijven puur van het eigen team.
 * Scopes: 'team' (Bij dit team, standaard) · 'seizoen' (Heel seizoen) · 'carriere'. */
const OV_SUBS = [['wed','Wedstrijden'], ['beo','Beoordelingen'], ['tr','Trainingen'], ['lp','Leerpunten']];

function stintsVoor(p){
  if (!p || !p.heeftVorigeTeams) return [];
  return (S._vorigeTeams || {})[`${S.teamId}/${p.id}`] || [];
}

// Laadt de dossiers één keer per speler (lazy); daarna een her-render.
function ovZorgVoorDossier(p){
  if (!p || !p.heeftVorigeTeams || !S.teamId) return;
  const sl = `${S.teamId}/${p.id}`;
  S._vorigeTeams = S._vorigeTeams || {};
  if (S._vorigeTeams[sl] || S._vtBezig === sl) return;
  S._vtBezig = sl;
  getDocs(collection(db,'teams',S.teamId,'spelers',p.id,'vorigeTeams'))
    .then(snap => {
      S._vorigeTeams[sl] = snap.docs.map(d => ({ id:d.id, ...d.data() }))
        .sort((a, b) => (b.tot || '').localeCompare(a.tot || ''));
    })
    .catch(() => { S._vorigeTeams[sl] = []; })      // geen toegang/fout: geen herhaald laden
    .finally(() => { if (S._vtBezig === sl) S._vtBezig = null; herrenderTeam(); });
}

const ovSeizoenNu = () => S.huidigSeizoen || SEIZOEN_FALLBACK;
const ovScopeNu = (p) => stintsVoor(p).length ? (S._ovScope || 'team') : 'team';

// Tellers uit het eigen team, optioneel beperkt tot één seizoen.
function telEigen(p, seizoen){
  const sz = x => x.seizoen || ovSeizoenNu();
  const weds = (S.wedstrijden || []).filter(w => !seizoen || sz(w) === seizoen);
  let wedstrijden = 0, tijd = 0, goals = 0, assists = 0;
  for (const w of weds){
    for (const g of (w.goals || [])){
      if (g.type !== 'voor') continue;
      if (g.pid === p.id) goals++;
      if (g.assist === p.id) assists++;
    }
    const a = analyseWedstrijd(w);
    if (a.kwarten && a.tijd[p.id]){ tijd += a.tijd[p.id]; wedstrijden++; }
  }
  const sr = speeltijdReserve(weds)[p.id] || { speeltijd:0, reserve:0, speelbaar:0 };
  const sessies = (S.presentie || []).filter(s => teltMee(s, p) && (!seizoen || sz(s) === seizoen));
  const aanwezig = sessies.filter(s => !(s.afwezig || []).includes(p.id)).length;
  return { wedstrijden, tijd, goals, assists, speeltijd:sr.speeltijd, reserve:sr.reserve, speelbaar:sr.speelbaar,
    trainingen:sessies.length, aanwezig };
}

// Stats voor de gekozen scope; percentages opnieuw uit de opgetelde tellers.
function ovStatsVoor(p, st){
  const scope = ovScopeNu(p);
  if (scope === 'team') return st;
  const cur = scope === 'seizoen' ? ovSeizoenNu() : null;
  const e = telEigen(p, cur);
  const som = { wedstrijden:e.wedstrijden, tijd:e.tijd, goals:e.goals, assists:e.assists, reserve:e.reserve,
    speelbaar:e.speelbaar, speeltijd:e.speeltijd, trainingen:e.trainingen, aanwezig:e.aanwezig };
  for (const s of stintsVoor(p)){
    for (const z of (s.seizoenen || [])){
      if (cur && z.seizoen !== cur) continue;
      som.wedstrijden += z.wedstrijden || 0; som.tijd += z.tijd || 0; som.goals += z.goals || 0;
      som.assists += z.assists || 0; som.reserve += z.reserve || 0; som.speelbaar += z.speelbaar || 0;
      som.speeltijd += Math.min(z.tijd || 0, z.speelbaar || 0);
      som.trainingen += z.trainingen || 0; som.aanwezig += z.aanwezig || 0;
    }
  }
  const pctSpeeltijd = som.speelbaar > 0 ? Math.min(100, Math.round((som.speeltijd / som.speelbaar) * 100)) : null;
  return { ...st, wedstrijden:som.wedstrijden, tijd:som.tijd, goals:som.goals, assists:som.assists,
    reserve:som.reserve, speelbaar:som.speelbaar, pctSpeeltijd,
    pctReserve: pctSpeeltijd != null ? 100 - pctSpeeltijd : null,
    opkomst: som.trainingen > 0 ? Math.round((som.aanwezig / som.trainingen) * 100) : null };
}

function ovScopeKop(p){
  if (!stintsVoor(p).length) return '';
  const sc = ovScopeNu(p);
  const tekst = {
    team: `Alleen wat ${esc(p.naam.split(' ')[0])} bij ${esc(S.team.naam)} heeft gedaan.`,
    seizoen: `Dit seizoen, inclusief de wedstrijden en trainingen bij eerdere teams.`,
    carriere: `Alles bij elkaar, ook uit eerdere seizoenen en teams.`,
  }[sc];
  return `<div class="ov-scope-kop">
    <div class="segment" id="ovScope">
      <button data-ov-scope="team" class="${sc==='team'?'actief':''}">Bij dit team</button>
      <button data-ov-scope="seizoen" class="${sc==='seizoen'?'actief':''}">Heel seizoen</button>
      <button data-ov-scope="carriere" class="${sc==='carriere'?'actief':''}">Carrière</button>
    </div>
    <p class="ov-hint">${tekst}</p>
  </div>`;
}

// Per team (en seizoen) een regel, alleen bij Heel seizoen / Carrière.
function ovPerTeam(p){
  const sc = ovScopeNu(p);
  if (sc === 'team') return '';
  const cur = sc === 'seizoen' ? ovSeizoenNu() : null;
  const rij = (naam, sub, x) => `<div class="ov-team-rij">
    <div class="ov-tn"><b>${esc(naam)}</b><span>${esc(sub)}</span></div>
    <span>${x.wedstrijden} wedstr.</span><span>${x.tijd ? uurMin(x.tijd) : '—'}</span><span>${x.goals} G</span></div>`;
  let h = rij(S.team.naam, cur || 'nu', telEigen(p, cur));
  for (const s of stintsVoor(p)){
    for (const z of (s.seizoenen || [])){
      if (cur && z.seizoen !== cur) continue;
      h += rij(s.teamNaam || 'Vorig team', z.seizoen && z.seizoen !== 'onbekend' ? z.seizoen : 'seizoen onbekend', z);
    }
  }
  return `<div class="kaart"><div class="veldlabel u-mt-0">Per team</div>${h}</div>`;
}

function ovWedRij(r){
  const pct = r.speelbaar > 0 ? Math.round((r.tijd / r.speelbaar) * 100) : null;
  let label = '—', klasse = 'leeg';
  if (r.straf > 0){ label = 'Straf'; klasse = 'straf'; }
  else if (pct != null){ label = pct + '%'; klasse = pct >= 90 ? 'vol' : 'deel'; }
  const extra = [];
  if (r.goals) extra.push(`${r.goals} goal${r.goals === 1 ? '' : 's'}`);
  if (r.assists) extra.push(`${r.assists} assist${r.assists === 1 ? '' : 's'}`);
  if (r.geel) extra.push(`${r.geel} geel`);
  if (r.rood) extra.push(`${r.rood} rood`);
  if (r.keeper) extra.push(`keeper ${uurMin(r.keeper)}`);
  if (r.laat) extra.push('kwam later');
  if (r.startBank?.reden){ const w = wisselReden(r.startBank.reden); extra.push(`${w ? w.label : 'bank'}`); }
  const uitslag = (r.voor || r.tegen || r.inSelectie) ? `, ${r.voor}-${r.tegen}` : '';
  return `<div class="wed-hist-rij">
    <span class="whr-datum">${r.datum ? datumNL(r.datum) : '—'}</span>
    <div class="whr-mid"><div class="whr-teg">${esc(r.tegenstander)}${uitslag}</div>
      ${extra.length ? `<div class="whr-reden">${extra.join(', ')}</div>` : ''}</div>
    <span class="whr-status ${klasse}">${label}</span></div>`;
}

function ovPaneel(s, sub){
  const leeg = t => `<p class="ov-hint" style="padding:var(--space-xs) 0">${t}</p>`;
  if (sub === 'wed')
    return (s.wedstrijden || []).length ? s.wedstrijden.map(ovWedRij).join('') : leeg(s.mee?.wed === false ? 'Niet meegenomen bij het overzetten.' : 'Geen wedstrijden.');
  if (sub === 'beo')
    return (s.beoordelingen || []).length
      ? s.beoordelingen.map(b => htmlTijdlijnItem(b).replace(/\sdata-open-beoordeling="[^"]*"/g, '')).join('')
      : leeg(s.mee?.beo === false ? 'Niet meegenomen bij het overzetten.' : 'Geen beoordelingen.');
  if (sub === 'tr')
    return (s.presentie || []).length ? s.presentie.map(r => {
      let info = null; try { info = r.reden ? afwezigRedenInfo(r.reden) : null; } catch {}
      const txt = r.aanwezig ? 'Aanwezig' : info ? `${info.ico?ico(info.ico,14):''}${esc(info.label)}` : 'Zonder reden';
      return `<div class="presentie-hist-rij"><span>${r.datum ? datumNL(r.datum) : '—'}</span><span class="phr-status ${r.aanwezig?'aanw':'afw'}">${txt}</span></div>`;
    }).join('') : leeg(s.mee?.tr === false ? 'Niet meegenomen bij het overzetten.' : 'Geen trainingen.');
  return (s.leerpunten || []).length ? s.leerpunten.map(l => {
    const d = SKILLS.find(x => x.id === l.domein);
    return `<div class="ov-lp"><span class="ov-lp-dom">${esc(l.domein || '')}</span><div><div>${esc(l.tekst || '')}</div>
      <div class="ov-hint">${d ? esc(d.naam)+'<span class="sep" aria-hidden="true"></span>' : ''}${l.klaar ? 'afgerond' + (l.klaarOp ? ' ' + datumNL(isoDatum(l.klaarOp) || l.klaarOp) : '') : 'open'}</div></div></div>`;
  }).join('') : leeg(s.mee?.lp === false ? 'Niet meegenomen bij het overzetten.' : 'Geen leerpunten.');
}

function ovStintKaart(p, s){
  const tot = (s.seizoenen || []).reduce((a, z) => ({
    w: a.w + (z.wedstrijden || 0), t: a.t + (z.tijd || 0), g: a.g + (z.goals || 0), a: a.a + (z.assists || 0),
    tr: a.tr + (z.trainingen || 0), aw: a.aw + (z.aanwezig || 0) }), { w:0, t:0, g:0, a:0, tr:0, aw:0 });
  const open = S._ovOpen === s.id;
  const sub = S._ovSub || 'wed';
  const tel = { wed:(s.wedstrijden||[]).length, beo:(s.beoordelingen||[]).length, tr:(s.presentie||[]).length, lp:(s.leerpunten||[]).length };
  const periode = s.van ? `${datumNL(s.van)} – ${s.tot ? datumNL(s.tot) : ''}` : (s.tot ? `t/m ${datumNL(s.tot)}` : '');
  return `<div class="kaart ov-stint">
    <div class="veldlabel u-mt-0">Vorig team<span class="sep" aria-hidden="true"></span>${esc(s.teamNaam || 'onbekend')}</div>
    ${periode ? `<div class="ov-hint" style="margin:-4px 0 var(--space-xs)">${periode}</div>` : ''}
    <div class="ov-samen"><span><b>${tot.w}</b> wedstr.</span><span><b>${tot.t ? uurMin(tot.t) : '—'}</b></span>
      <span><b>${tot.g}</b> goals</span><span><b>${tot.a}</b> assists</span>
      <span><b>${tot.tr ? Math.round(tot.aw / tot.tr * 100) + '%' : '—'}</b> training</span></div>
    <button class="knop licht klein" style="width:100%;margin-top:var(--space-sm)" data-ov-open="${esc(s.id)}">${open ? 'Inklappen' : `Alles uit ${esc(s.teamNaam || 'vorig team')} tonen`}</button>
    ${open ? `
      <div class="segment ov-sub" id="ovSub">
        ${OV_SUBS.map(([k, n]) => `<button data-ov-sub="${k}" class="${sub===k?'actief':''}">${n} (${tel[k]})</button>`).join('')}
      </div>
      <div class="ov-paneel">${ovPaneel(s, sub)}</div>
      <p class="ov-voet">Bevroren op ${s.bevroren ? datumNL(s.bevroren) : '—'}. Het origineel blijft bewaard bij ${esc(s.teamNaam || 'het oude team')}.</p>
      ${isBeheerder() ? `<button class="knop licht klein" data-ov-herbereken="${esc(s.id)}">Herbereken uit ${esc(s.teamNaam || 'oud team')}</button>` : ''}` : ''}
  </div>`;
}

function htmlVorigeTeams(p){
  return stintsVoor(p).map(s => ovStintKaart(p, s)).join('');
}

/* ---------- Spelerprofiel ---------- */
/* Bepaalt voor één speler in één wedstrijd: speeltijd-label + eventuele
   wisselreden (inclusief vooraf ingestelde disciplinaire bankbeurt). Gebruikt
   in het spelersprofiel onder "Wedstrijden". */
function wisselInfoVoorSpeler(w, pid){
  const a = analyseWedstrijd(w);
  const disc = disciplinaireTijd(w)[pid] || 0;
  const laatSec = telaatTijd(w)[pid] || 0;
  const gespeeld = a.tijd?.[pid] || 0;
  // percentage over de eerlijke noemer (gecorrigeerd voor straf en te laat komen)
  const speelbaar = a.matchduur ? persoonlijkeNoemer(a, pid, disc, laatSec).speelbaar : 0;
  const pct = speelbaar > 0 ? Math.round((gespeeld / speelbaar) * 100) : null;

  // reden verzamelen: vooraf ingestelde bankbeurt of een wissel-event met reden
  let redenTekst = '';
  const sb = (w.startBankReden || {})[pid];
  const wisselEvents = [];
  for (const nr of Object.keys(w.kwarten || {})){
    for (const e of (w.kwarten[nr].events || []))
      if (e.uit === pid && (e.reden || e.disciplinair)) wisselEvents.push(e);
  }
  const disciplinair = sb?.disciplinair || wisselEvents.some(e => e.disciplinair);
  if (sb?.reden){
    const r = wisselReden(sb.reden);
    redenTekst = `${r?r.label:''}${sb.disciplinair?', disciplinaire reservebeurt':', startte op de bank'}`;
  } else if (wisselEvents.length){
    const e = wisselEvents[wisselEvents.length-1];
    const r = e.reden ? wisselReden(e.reden) : null;
    redenTekst = `${r?r.label+' gewisseld':'Gewisseld'}${e.disciplinair?', disciplinaire reservebeurt':''}`;
  }

  if (laatSec > 0){
    const m = (w.telaatVanaf||{})[pid];
    redenTekst = redenTekst
      ? `${redenTekst}, kwam later, erbij vanaf minuut ${m}`
      : `Kwam later, erbij vanaf minuut ${m}`;
  }

  let label, klasse;
  if (pct == null){ label = '—'; klasse = 'leeg'; }
  else if (disciplinair){ label = 'Straf'; klasse = 'straf'; }
  else if (pct >= 90){ label = pct+'%'; klasse = 'vol'; }
  else { label = pct+'%'; klasse = 'deel'; }
  return { label, klasse, reden: redenTekst ? esc(redenTekst) : '' };
}

export function htmlProfiel(){
  const p = speler(S._beoordeelProfiel);
  if (!p) { S._beoordeelProfiel = null; return htmlSpelers(); }

  // Niet-gekoppelde gastspeler: kaal placeholder-profiel met koppelactie.
  if (p._gast && !p._gekoppeld){
    const st = spelerStats(p.id);
    const koppelbaar = (S.uitleningenIn || []).filter(u => !u.adopteertGast);
    const lijn = p.nummer != null && p.nummer !== '' ? '#'+esc(p.nummer) : '';
    return `
      <button class="profiel-terug" id="profielTerug">‹ Terug naar spelers</button>
      <div class="profiel-top">
        <div class="pt-shirt" style="background:transparent;border:1px dashed var(--ink-2)">${esc(p.nummer ?? '?')}</div>
        <div><h2>${esc(p.naam)}</h2><div class="meta">${lijn?lijn+'<span class="sep" aria-hidden="true"></span>':''}gastspeler<span class="sep" aria-hidden="true"></span>nog te koppelen</div></div>
      </div>
      <div class="leen-strook">
        <span class="ic"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="8" r="3.2"/><path d="M5.5 20a6.5 6.5 0 0 1 13 0"/></svg></span>
        <span class="tx">Placeholder voor een nog onbekende uitleen. Doet volwaardig mee in opstelling en presentie. Koppel hem zodra bekend is wie het wordt.</span>
      </div>
      <div class="stat-grid">
        <div class="stat-box"><div class="v">${st.wedstrijden}</div><div class="l">Wedstr.</div></div>
        <div class="stat-box"><div class="v">${st.tijd ? uurMin(st.tijd) : '—'}</div><div class="l">Speeltijd</div></div>
        <div class="stat-box"><div class="v">${st.goals}</div><div class="l">Goals</div></div>
        <div class="stat-box"><div class="v">${st.opkomst != null ? st.opkomst+'%' : '—'}</div><div class="l">Training</div></div>
      </div>
      <button class="knop vol" data-gast-koppel="${p.id}" style="margin-top:var(--space-2xs)"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="17.8" cy="6" r="2.6"/><circle cx="6.2" cy="12" r="2.6"/><circle cx="17.8" cy="18" r="2.6"/><path d="M15.4 7.2 8.6 10.8"/><path d="M8.6 13.2 15.4 16.8"/></svg> Koppel aan ingeleende speler</button>
      <div class="rij u-mt-xs">
        <button class="knop licht klein" data-gast-bewerk="${p.id}">${ico('admin-edit', 16)} Gast bewerken</button>
        <button class="knop gevaar klein" data-gast-weg="${p.id}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg> Verwijderen</button>
      </div>
      ${koppelbaar.length ? '' : `<p class="u-t-xs u-zacht u-mt-sm u-lh-ruim">Er staat nog geen uitleen voor jou klaar om aan te koppelen. Zodra een ander team de speler naar jou uitleent, verschijnt die in de koppel-lijst.</p>`}
    `;
  }

  const leerlijnAan = modAan('leerlijn');
  const evalAan = modAan('evaluaties');
  // Leerlijn-module uit? Nooit op het Leerlijn-tabblad blijven staan.
  if (!leerlijnAan && S._profielTab === 'leerlijn') S._profielTab = 'overzicht';
  const tab = S._profielTab || 'overzicht';
  const st = spelerStats(p.id);
  ovZorgVoorDossier(p);
  const stS = ovStatsVoor(p, st);   // st = alleen dit team; stS = volgens de gekozen scope
  const vol = laatsteVolledig(p.id);
  const eigen = S.beoordelingen.filter(b => b.spelerId === p.id);

  const lijn = p.nummer != null && p.nummer !== '' ? '#'+esc(p.nummer) : '';
  return `
    <button class="profiel-terug" id="profielTerug">‹ Terug naar spelers</button>
    <div class="profiel-top">
      <div class="pt-shirt"${p._ingeleend?' style="background:var(--ink-2)"':''}>${esc(p.nummer ?? '·')}</div>
      <div><h2>${esc(p.naam)}</h2><div class="meta">${lijn?lijn+'<span class="sep" aria-hidden="true"></span>':''}${p._ingeleend?`ingeleend van ${esc(p._bronTeamNaam||'ander team')}`:esc(S.team.naam)}</div></div>
    </div>
    ${(() => {
      if (p._ingeleend){
        const gastNoot = p._gast ? ' Gekoppeld aan je gastspeler: je opstellingen bleven behouden.' : ' Doet volwaardig mee bij jou.';
        return `<div class="leen-strook in">
          <span class="ic">⇄</span>
          <span class="tx">Ingeleend van <b>${esc(p._bronTeamNaam||'ander team')}</b>.${gastNoot}</span>
          <button data-uitleen-terug="${p._leenId}">Terugzetten</button>
        </div>
        ${(isBeheerder() || isBouwCoordinator(S.team.bouw)) ? `<button class="knop vol" style="margin-bottom:var(--space-sm)" data-uitleen-definitief="${p._leenId}">Definitief toevoegen aan ${esc(S.team.naam)}</button>` : ''}`;
      }
      const u = actieveUitleningVoor(p.id);
      if (!u) return '';
      return `<div class="leen-strook">
        <span class="ic">⇄</span>
        <span class="tx">Uitgeleend aan <b>${esc(u.naarTeamNaam)}</b></span>
        <button data-uitleen-terug="${u.id}">Terughalen</button>
      </div>`;
    })()}

    <div class="avg-balk"><span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4.6" y="10.4" width="14.8" height="9.8" rx="2.4"/><path d="M8 10.4V8a4 4 0 0 1 8 0v2.4"/><circle cx="12" cy="15.2" r="1.4" fill="currentColor" stroke="none"/></svg></span>
      <span>Coach-only. Deel niets uit dit profiel buiten het technisch kader.</span></div>

    <div class="segment u-mb-md" id="profielTabs" >
      <button data-ptab="overzicht" class="${tab==='overzicht'?'actief':''}">Overzicht</button>
      ${leerlijnAan ? `<button data-ptab="leerlijn" class="${tab==='leerlijn'?'actief':''}">Leerlijn</button>` : ''}
      <button data-ptab="historie" class="${tab==='historie'?'actief':''}">Historie</button>
    </div>

    ${tab === 'overzicht' ? `
      ${ovScopeKop(p)}
      <div class="stat-grid">
        <div class="stat-box"><div class="v">${stS.wedstrijden}</div><div class="l">Wedstr.</div></div>
        <div class="stat-box"><div class="v">${stS.tijd ? uurMin(stS.tijd) : '—'}</div><div class="l">Speeltijd</div>${stS.pctSpeeltijd!=null?`<div class="sub">${stS.pctSpeeltijd}% van speelbaar</div>`:''}</div>
        <div class="stat-box"><div class="v">${stS.reserve ? uurMin(stS.reserve) : '—'}</div><div class="l">Reserve</div>${stS.pctReserve!=null?`<div class="sub">${stS.pctReserve}% van speelbaar</div>`:''}</div>
        <div class="stat-box"><div class="v">${stS.goals}</div><div class="l">Goals</div><div class="sub">${stS.assists} assist${stS.assists === 1 ? '' : 's'}</div></div>
      </div>
      ${(heeftElftallen() && ovScopeNu(p) === 'team') ? (() => {
        const e1 = spelerStats(p.id, '1'), e2 = spelerStats(p.id, '2');
        const r = (e, x) => `<div class="elf-split-rij"><span class="elf-pill e${e}">${e}e</span><span>${x.wedstrijden} wedstr.</span><span>${Math.round(x.tijd / 60)} min</span><span>${x.goals} G</span><span>${x.assists} A</span></div>`;
        return `<div class="kaart elf-split"><div class="veldlabel u-mt-0">Per elftal${elftalPillen(p)}</div>${r('1', e1)}${r('2', e2)}</div>`;
      })() : ''}
      ${stS.pctSpeeltijd != null ? `
      <div class="kaart" style="margin-top:-2px">
        <div class="veldlabel u-mt-0">Verhouding speeltijd / bank</div>
        <div class="speeltijd-split">
          <div class="veld" style="width:${stS.pctSpeeltijd}%"></div>
          <div class="bank" style="width:${stS.pctReserve}%"></div>
        </div>
        <div class="split-legend">
          <span><span class="dotje" style="background:var(--ok)"></span> Op het veld<span class="sep" aria-hidden="true"></span>${uurMin(stS.tijd)}</span>
          <span><span class="dotje" style="background:var(--warn)"></span> Reserve<span class="sep" aria-hidden="true"></span>${uurMin(stS.reserve)}</span>
        </div>
      </div>` : ''}
      ${ovPerTeam(p)}
      ${Object.keys(st.afwPerReden||{}).length ? `
      <div class="presentie-uitsplitsing" style="margin:-8px 0 var(--space-md)">
        ${Object.entries(st.afwPerReden).sort((a,b)=>b[1]-a[1]).map(([id,n]) => {
          if (id === 'geen') return `<span>${n}× zonder reden</span>`;
          const r = AFWEZIG_REDENEN.find(x => x.id === id) || {emoji:'❓',label:'Anders'};
          return `<span>${r.ico?ico(r.ico,15):r.emoji} ${n}× ${esc(r.label.toLowerCase())}</span>`;
        }).join('')}
      </div>` : ''}

      ${htmlVorigeTeams(p)}
      ${(() => {
        const notitie = (p.notitie || '').trim();
        return `<div class="notitie-kaart${notitie ? '' : ' leeg'}">
          <div class="notitie-kop">
            <div class="veldlabel u-m-0">Notitie</div>
            <button class="notitie-bewerk" data-notitie="${p.id}" aria-label="${notitie ? 'Notitie bewerken' : 'Notitie toevoegen'}">
              ${notitie ? ico('admin-edit', 18) : ico('action-add', 18)}
            </button>
          </div>
          ${notitie
            ? `<div class="notitie-tekst">${esc(notitie)}</div>`
            : `<div class="notitie-leeg-tekst">Nog geen notitie. Bijzonderheden, afspraken of aandachtspunten voor deze speler.</div>`}
        </div>`;
      })()}

      ${evalAan ? `<div class="kaart">
        <div class="veldlabel u-mt-0">Ontwikkelprofiel${vol ? `, ${datumNL(vol.datum)}` : ''}</div>
        ${vol ? SKILLS.map(d => `
          <div class="tips-rij">
            <div class="tips-letter">${d.id}</div>
            <div class="tips-naam">${d.naam}</div>
            ${tipsBalk(vol.scores?.[d.id] || 0)}
            <div class="tips-score">${vol.scores?.[d.id] || '—'}</div>
          </div>`).join('')
        : `<p class="u-t-sm u-zacht" style="padding:var(--space-xs) 0">Nog geen volledige beoordeling. Maak er één om het ontwikkelprofiel te zien.</p>`}
      </div>

      <div class="fab-rij">
        <button class="knop fluo klein" style="flex:1" data-snel-speler="${p.id}">${ico('training-favorite', 17)} Snel beoordelen</button>
        <button class="knop klein" style="flex:1" data-volledig-speler="${p.id}">${ico('training-completed', 17)} Volledige beoordeling</button>
      </div>` : ''}

      <div class="rij u-mt-2xs">
        ${p._ingeleend
          ? `<button class="knop licht klein" data-leen-overlay="${p.id}">${ico('admin-edit', 16)} Nummer/positie bij jou</button>`
          : `<button class="knop licht klein" data-bewerk-speler="${p.id}">${ico('admin-edit', 16)} Speler bewerken</button>
             <button class="knop gevaar klein" data-weg-speler="${p.id}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg> Verwijderen</button>`}
      </div>
      ${(!p._ingeleend && S.team?.club) ? `<button class="knop klein" style="margin-top:var(--space-2xs);width:100%" data-uitleen-speler="${p.id}">⇄ Uitlenen aan ander team</button>` : ''}
    ` : ''}

    ${tab === 'leerlijn' ? htmlLeerlijn(p) : ''}

    ${tab === 'historie' ? `
      ${evalAan ? `<div class="kaart">
        <div class="veldlabel u-mt-0">Tijdlijn</div>
        ${eigen.length ? eigen.map(b => htmlTijdlijnItem(b)).join('')
          : `<p class="u-t-sm u-zacht" style="padding:var(--space-xs) 0">Nog geen beoordelingen vastgelegd.</p>`}
      </div>` : ''}
      <div class="kaart">
        <div class="veldlabel u-mt-0">Wedstrijden</div>
        ${(() => {
          const weds = (S.wedstrijden||[])
            .filter(w => (w.selectie||[]).includes(p.id))
            .sort((a,b) => (b.datum||'').localeCompare(a.datum||''));
          if (!weds.length) return `<p class="u-t-sm u-zacht" style="padding:var(--space-xs) 0">Nog geen wedstrijden.</p>`;
          return weds.map(w => {
            const info = wisselInfoVoorSpeler(w, p.id);
            const teg = w.tegenstander || (isToernooi(w) ? 'Toernooi' : 'Wedstrijd');
            return `<div class="wed-hist-rij">
              <span class="whr-datum">${datumNL(w.datum)}</span>
              <div class="whr-mid">
                <div class="whr-teg">${esc(teg)}</div>
                ${info.reden ? `<div class="whr-reden">${info.reden}</div>` : ''}
              </div>
              <span class="whr-status ${info.klasse}">${info.label}</span>
            </div>`;
          }).join('');
        })()}
      </div>
      <div class="kaart">
        <div class="veldlabel u-mt-0">Presentie training</div>
        ${(() => {
          // Alleen de trainingen die voor deze speler meetellen; trainingen van
          // vóór zijn instroom staan niet in zijn lijst maar worden er wel
          // onder benoemd, zodat het aantal klopt met zijn percentage.
          const eigen = S.presentie.filter(ses => teltMee(ses, p));
          const buiten = S.presentie.length - eigen.length;
          if (!eigen.length) return `<p class="u-t-sm u-zacht" style="padding:var(--space-xs) 0">Nog geen presentie geregistreerd${buiten ? ' sinds hij bij het team kwam' : ''}.</p>`;
          return eigen.map(ses => {
            const afw = (ses.afwezig||[]).includes(p.id);
            const reden = (ses.afwezigRedenen||{})[p.id];
            const info = afw && reden ? afwezigRedenInfo(reden) : null;
            const statusTxt = !afw ? 'Aanwezig'
              : info ? `${info.ico?ico(info.ico,14):''}${info.label}${info.notitie ? ', '+esc(info.notitie) : ''}`
              : 'Zonder reden';
            return `<div class="presentie-hist-rij"><span>${datumNL(ses.datum)}</span><span class="phr-status ${afw?'afw':'aanw'}">${statusTxt}</span></div>`;
          }).join('') + (buiten ? `<p class="u-t-xs u-zacht u-lh-ruim" style="padding:var(--space-xs) 0 0">${buiten} training${buiten>1?'en':''} van vóór zijn komst tellen niet mee.</p>` : '');
        })()}
      </div>` : ''}`;
}

// Alleen-lezen leerpunt-item: geen toggle/verwijder-knop (die zou bij een
// ingeleende speler naar het verkeerde team proberen te schrijven).
function leerpuntItemReadOnly(l){
  const d = skillDomein(l.domein);
  return `
    <div class="leerpunt">
      <div class="lp-check" style="cursor:default"></div>
      <div class="lp-tekst">
        <div class="lp-domein">${d ? esc(d.naam) : 'Algemeen'}</div>
        <div class="t">${esc(l.tekst)}</div>
        ${l.sinds ? `<div class="d">Sinds ${datumNL(l.sinds)}</div>` : ''}
      </div>
    </div>`;
}

function htmlLeerlijn(p){
  // Rechtstreeks ingeleende speler (geen gast): het spelerdocument leeft bij
  // het bronteam, dus hier alleen een alleen-lezen momentopname tonen —
  // toggle/verwijderen/toevoegen zou bij het verkeerde team proberen te
  // schrijven. Wordt automatisch bijgewerkt zolang de uitlening loopt
  // (syncLeerpuntenNaarUitlening bij elke wijziging aan de bronkant).
  if (p._ingeleend && !p._gast){
    const lp = p.leerpunten || [];
    return `
      <div class="avg-balk"><span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4.6" y="10.4" width="14.8" height="9.8" rx="2.4"/><path d="M8 10.4V8a4 4 0 0 1 8 0v2.4"/><circle cx="12" cy="15.2" r="1.4" fill="currentColor" stroke="none"/></svg></span>
        <span>Leerpunten van ${esc(p._bronTeamNaam||'het bronteam')} — alleen-lezen, blijft vanzelf bij zolang de uitlening loopt.</span></div>
      <div class="kaart">
        <div class="veldlabel u-mt-0">Leerpunten</div>
        ${lp.length ? lp.map(leerpuntItemReadOnly).join('')
          : `<p class="u-t-sm u-zacht" style="padding:var(--space-xs) 0">Geen open leerpunten bij ${esc(p._bronTeamNaam||'het bronteam')}.</p>`}
      </div>`;
  }

  const lp = (p.leerpunten || []).slice().sort((a,b) => (a.klaar?1:0)-(b.klaar?1:0) || (b.sinds||'').localeCompare(a.sinds||''));
  // Gekoppelde gast: eigen (bewerkbare) leerpunten zoals gewoonlijk, plus
  // een losse alleen-lezen sectie met de leerpunten van het bronteam.
  const bronLp = p._bronLeerpunten || [];
  const bronSectie = (p._gast && p._gekoppeld && bronLp.length) ? `
    <div class="avg-balk"><span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4.6" y="10.4" width="14.8" height="9.8" rx="2.4"/><path d="M8 10.4V8a4 4 0 0 1 8 0v2.4"/><circle cx="12" cy="15.2" r="1.4" fill="currentColor" stroke="none"/></svg></span>
      <span>Hieronder ook de leerpunten van ${esc(p._bronTeamNaam||'het bronteam')} — alleen-lezen.</span></div>
    <div class="kaart">
      <div class="veldlabel u-mt-0">Leerpunten bij ${esc(p._bronTeamNaam||'bronteam')}</div>
      ${bronLp.map(leerpuntItemReadOnly).join('')}
    </div>` : '';
  return `
    <div class="kaart">
      <div class="veldlabel u-mt-0">Leerpunten${p._gast && p._gekoppeld ? ` bij ons` : ''}</div>
      ${lp.length ? lp.map(l => {
        const d = skillDomein(l.domein);
        const thema = leercurveThema(l.tekst);
        return `
        <div class="leerpunt ${l.klaar?'klaar':''}">
          <button class="lp-check ${l.klaar?'klaar':''}" data-lp-toggle="${l.id}">${l.klaar?'✓':''}</button>
          <div class="lp-tekst">
            <div class="lp-domein">${d ? esc(d.naam) : 'Algemeen'}</div>
            <div class="t">${esc(l.tekst)}</div>
            <div class="d">${l.klaar ? 'Afgerond op '+datumNL(l.klaarOp||l.sinds) : 'Sinds '+datumNL(l.sinds)}</div>
            ${thema ? `<div style="font-size:var(--t-2xs);color:var(--accent);font-weight:700;margin-top:var(--space-2xs);cursor:pointer" data-thema-info="${esc(thema.thema)}">Achtergrond &amp; tips bekijken</div>` : ''}
          </div>
          <button class="lp-weg" data-lp-weg="${l.id}" title="Verwijderen"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg></button>
        </div>`;
      }).join('')
      : `<p class="u-t-sm u-zacht" style="padding:var(--space-xs) 0 var(--space-sm)">Nog geen leerpunten. Voeg een concreet, observeerbaar ontwikkeldoel toe.</p>`}
      <button class="knop licht klein" style="width:100%;margin-top:var(--space-xs)" data-lp-nieuw="${p.id}">+ Leerpunt toevoegen</button>
    </div>
    <p class="u-t-xs u-zacht u-lh-ruim">Leerpunten lopen door over meerdere wedstrijden en beoordelingen. Vink ze af zodra ze beheerst zijn.</p>
    ${bronSectie}`;
}

function htmlTijdlijnItem(b){
  if (b.soort === 'snel'){
    const nv = niveau(b.niveau);
    const tags = (b.tags||[]).map(t => { const s = snelTag(t); return s ? s.label : ''; }).filter(Boolean).join(', ');
    const not = b.notities?.algemeen ? ` — "${esc(b.notities.algemeen)}"` : '';
    return `
      <div class="tijdlijn-item" data-open-beoordeling="${b.id}">
        <div class="tl-stip" style="background:${niveauKleur(b.niveau)}"></div>
        <div class="tl-lijn">
          <div class="dat">${datumNL(b.datum)}<span class="sep" aria-hidden="true"></span>Snelle beoordeling</div>
          <div class="wat">${esc(b.bron?.label || 'Los')}${nv ? '<span class="sep" aria-hidden="true"></span>'+nv.label : ''}</div>
          ${tags || not ? `<div class="det">${tags}${not}</div>` : ''}
        </div>
      </div>`;
  }
  const scores = SKILLS.map(d => d.id+(b.scores?.[d.id]||'–')).join(', ');
  return `
    <div class="tijdlijn-item" data-open-beoordeling="${b.id}">
      <div class="tl-stip" style="background:var(--n5)"></div>
      <div class="tl-lijn">
        <div class="dat">${datumNL(b.datum)}<span class="sep" aria-hidden="true"></span>Volledige beoordeling</div>
        <div class="wat">${esc(b.bron?.label || 'Periodieke meting')}</div>
        <div class="det">${scores}</div>
      </div>
    </div>`;
}


function bronOpties(){
  const opts = [];
  for (const w of S.wedstrijden.slice(0, 8)){
    const tit = w.type === 'toernooi' ? (w.tegenstander||'Toernooi')
      : (w.thuis ? S.team.naam+' – '+w.tegenstander : w.tegenstander+' – '+S.team.naam);
    opts.push({type:'wedstrijd', id:w.id, datum:w.datum, label:tit});
  }
  for (const t of (S.presentie||[]).slice(0, 8)){
    opts.push({type:'training', id:t.id, datum:t.datum, label:'Training '+datumNL(t.datum)});
  }
  opts.sort((a,b) => (b.datum||'').localeCompare(a.datum||''));
  return opts;
}

function vandaagISO(){ return new Date().toISOString().slice(0,10); }
function deelnemer(){ return {uid:S.user.uid, naam:(S.team.ledenInfo?.[S.user.uid]?.naam)||S.user.displayName||S.user.email||''}; }

/* --- Snelle beoordeling (één speler) --- */
export function modalSnelBeoordeling(spelerId, bestaande = null){
  if (!modAan('evaluaties')) return meld('Evaluaties staan uit voor dit team');
  const p = speler(spelerId); if (!p) return;
  const opts = bronOpties();
  let gekozenNiveau = bestaande?.niveau || 0;
  let gekozenTags = new Set(bestaande?.tags || []);
  // standaard bron: bestaande bron, anders meest recente wedstrijd/training, anders los
  let bronType = bestaande?.bron?.type || (opts[0]?.type || 'los');
  let bronId   = bestaande?.bron?.id   || (opts[0]?.id || '');

  const bronSelect = () => {
    const lijst = opts.filter(o => o.type === bronType);
    return lijst.length
      ? `<select class="invoer" id="mSnBron">${lijst.map(o =>
          `<option value="${o.id}" ${o.id===bronId?'selected':''}>${esc(o.label)}<span class="sep" aria-hidden="true"></span>${datumNL(o.datum)}</option>`).join('')}</select>`
      : `<p class="u-t-sm u-zacht" style="padding:var(--space-2xs) 0">Geen ${bronType==='wedstrijd'?'wedstrijden':'trainingen'} gevonden, kies "Los".</p>`;
  };

  const kleurbalk = () => `<div class="kleurbalk" id="mSnNiveau">${NIVEAUS.slice(1).map(n =>
    `<button data-niv="${n.n}" class="kn${n.n} ${gekozenNiveau===n.n?'gekozen':''}"><span class="lbl">${n.label.toUpperCase()}</span></button>`).join('')}</div>`;

  const tagRij = () => `<div class="tag-rij" id="mSnTags">${SNEL_TAGS.map(t =>
    `<button class="tag ${gekozenTags.has(t.id)?'aan':''}" data-tag="${t.id}">${t.ico?ico(t.ico,16):t.emoji} ${t.label}</button>`).join('')}</div>`;

  const rondeVoortgang = () => {
    const r = S._snelRonde; if (!r) return '';
    const totaal = r.ids.length, positie = r.index + 1, gedaan = r.index, teGaan = totaal - positie;
    const seg = r.ids.map((id,i) => {
      const kl = i < gedaan ? (r.overgeslagen && r.overgeslagen.has(id) ? 'oversla' : 'gedaan')
        : i === r.index ? 'nu' : '';
      return `<span class="rv-seg ${kl}"></span>`;
    }).join('');
    return `<div class="ronde-voortgang">
      ${r.ronde ? `<div class="veldlabel" style="margin:0 0 var(--space-2xs)">${esc(r.ronde.naam)}</div>` : ''}
      <div class="rv-top">
        <div class="rv-teller"><b>${positie}</b> / ${totaal} spelers</div>
        <div class="rv-klaar">${teGaan > 0 ? 'nog '+teGaan+' te gaan' : 'laatste speler'}</div>
      </div>
      <div class="rv-track">${seg}</div>
    </div>`;
  };

  openModal(`
    <h2>Snel beoordelen</h2>
    <div class="snel-kop">
      <div class="mini-shirt">${esc(p.nummer ?? '·')}</div>
      <div><div class="nm">${esc(p.naam)}</div><div class="pos" id="mSnPos"></div></div>
    </div>
    ${rondeVoortgang()}

    <div class="veldlabel">Koppelen aan</div>
    <div class="segment klein-seg" id="mSnBronType">
      <button data-bt="wedstrijd" class="${bronType==='wedstrijd'?'actief':''}">Wedstrijd</button>
      <button data-bt="training" class="${bronType==='training'?'actief':''}">Training</button>
      <button data-bt="los" class="${bronType==='los'?'actief':''}">Los</button>
    </div>
    <div id="mSnBronWrap" class="u-mb-2xs">${bronType==='los'?'':bronSelect()}</div>

    <div class="veldlabel">Hoe ging het?</div>
    ${kleurbalk()}

    <div class="veldlabel">Opvallend (optioneel)</div>
    ${tagRij()}

    <div class="veldlabel">Korte notitie (optioneel)</div>
    <textarea class="invoer" id="mSnNotitie" rows="2" placeholder="Bijv. durfde aan de bal te komen...">${esc(bestaande?.notities?.algemeen||'')}</textarea>

    <button class="knop vol fluo u-mt-sm" id="mSnOk" >${bestaande?'Bijwerken':'Opslaan'}</button>
    ${S._snelRonde ? `<button class="knop licht vol u-mt-xs" id="mSnSkip" >Speler overslaan (niet aanwezig) →</button>` : ''}
    ${bestaande?`<button class="knop vol gevaar u-mt-xs" id="mSnWeg" >Verwijderen</button>`:''}`);

  const updatePos = () => {
    const o = opts.find(x => x.id === bronId && x.type === bronType);
    $('#mSnPos').textContent = bronType==='los' ? 'Losse beoordeling' : (o ? o.label : '');
  };
  const koppelBron = () => {
    $('#mSnBronWrap').innerHTML = bronType==='los' ? '' : bronSelect();
    const sel = $('#mSnBron');
    if (sel){ bronId = sel.value; sel.onchange = () => { bronId = sel.value; updatePos(); }; }
    else bronId = '';
    updatePos();
  };
  $$('#mSnBronType [data-bt]').forEach(b => b.onclick = () => {
    bronType = b.dataset.bt;
    $$('#mSnBronType [data-bt]').forEach(x => x.classList.toggle('actief', x===b));
    koppelBron();
  });
  $$('#mSnNiveau [data-niv]').forEach(b => b.onclick = () => {
    gekozenNiveau = Number(b.dataset.niv);
    $$('#mSnNiveau [data-niv]').forEach(x => x.classList.toggle('gekozen', x===b));
  });
  $$('#mSnTags [data-tag]').forEach(b => b.onclick = () => {
    const id = b.dataset.tag;
    if (gekozenTags.has(id)) gekozenTags.delete(id); else gekozenTags.add(id);
    b.classList.toggle('aan');
  });
  koppelBron();

  $('#mSnOk').onclick = async () => {
    if (!gekozenNiveau) return meld('Kies een niveau');
    const o = opts.find(x => x.id === bronId && x.type === bronType);
    const bron = bronType==='los' ? {type:'los'} : (o ? {type:bronType, id:o.id, label:o.label} : {type:'los'});
    const datum = o?.datum || vandaagISO();
    const data = {
      soort:'snel', spelerId, datum, bron, niveau:gekozenNiveau,
      tags:[...gekozenTags], notities:{algemeen:$('#mSnNotitie').value.trim()},
      door:deelnemer(), gemaaktMs:Date.now(),
    };
    /* [20260929a] snelle ronde vanuit een evaluatieronde van de club */
    if (!bestaande && S._snelRonde?.ronde) data.ronde = S._snelRonde.ronde.id;
    if (!bestaande) data.seizoen = S.huidigSeizoen || SEIZOEN_FALLBACK;
    try {
      if (bestaande) await updateDoc(doc(db,'teams',S.teamId,'beoordelingen',bestaande.id), data);
      else { await addDoc(collection(db,'teams',S.teamId,'beoordelingen'), data); telGebruik('snel_beoordeling'); }
      sluitModal();
      if (S._snelRonde) volgendeSnelRonde(); else { herrenderTeam(); meld(p.naam+' beoordeeld'); }
    } catch(e){ meld('Opslaan mislukt: '+(e.code||e.message)); }
  };
  const wegBtn = $('#mSnWeg');
  if (wegBtn) wegBtn.onclick = async () => {
    if (!confirm('Deze beoordeling verwijderen?')) return;
    await deleteDoc(doc(db,'teams',S.teamId,'beoordelingen',bestaande.id));
    sluitModal(); herrenderTeam();
  };
  const skipBtn = $('#mSnSkip');
  if (skipBtn) skipBtn.onclick = () => {
    if (S._snelRonde){ (S._snelRonde.overgeslagen ||= new Set()).add(spelerId); }
    sluitModal(); volgendeSnelRonde();
  };
}

/* ---------- Snelle beoordelingsronde (alle spelers achter elkaar) ---------- */
export function startSnelRonde(){
  if (!modAan('evaluaties')) return meld('Evaluaties staan uit voor dit team');
  if (!S.spelers.length) return meld('Voeg eerst spelers toe');
  S._snelRonde = {index:0, ids:S.spelers.map(p => p.id), overgeslagen:new Set()};
  telGebruik('snel_ronde');
  modalSnelBeoordeling(S._snelRonde.ids[0]);
}
function volgendeSnelRonde(){
  const r = S._snelRonde; if (!r) return;
  r.index++;
  if (r.index >= r.ids.length){ S._snelRonde = null; herrenderTeam(); meld('Ronde klaar ✓'); return; }
  modalSnelBeoordeling(r.ids[r.index]);
}

/* --- Volledige beoordeling (5 ontwikkeldomeinen) --- */

export function modalVolledigeBeoordeling(spelerId, bestaande = null){
  if (!modAan('evaluaties')) return meld('Evaluaties staan uit voor dit team');
  const p = speler(spelerId); if (!p) return;
  const scores = {...(bestaande?.scores || {})};
  const notities = {...(bestaande?.notities || {})};
  const moment = bestaande?.bron?.label || '';
  /* [20260929a] "Hoort bij": een lopende evaluatieronde van de club, of een losse meting.
     Vervangt het vinkje "officiële halfjaarevaluatie". */
  const flow = (!bestaande && S._evalRonde && S._evalRonde.ids[S._evalRonde.index] === spelerId) ? S._evalRonde : null;
  if (!flow) S._evalRonde = null;
  const lopend = rondesVoorTeam(S._clubRondes, S.teamId).filter(r => r.soort !== 'snel');
  const rondeOpties = [...lopend];
  if (bestaande?.ronde && !rondeOpties.some(r => r.id === bestaande.ronde)){
    const oud = (S._clubRondes || []).find(r => r.id === bestaande.ronde);
    rondeOpties.push({ id: bestaande.ronde, naam: oud?.naam || 'Evaluatieronde', tot: null });
  }
  const alInRonde = r => S.beoordelingen.some(b => b.ronde === r.id && b.spelerId === spelerId && b.id !== bestaande?.id);
  const rondeStart = flow ? flow.ronde.id
    : bestaande ? (bestaande.ronde || (bestaande.officieel ? '_oud' : ''))
    : (lopend.find(r => !alInRonde(r))?.id || '');

  const domeinKaart = (d) => `
    <div class="kaart">
      <div class="veldlabel u-mt-0">${d.id}<span class="sep" aria-hidden="true"></span>${d.naam}</div>
      <p class="u-t-xs u-zacht" style="margin:-2px 0 var(--space-2xs)">${esc(d.omschrijving)}</p>
      <div class="kleurbalk dom" data-dom="${d.id}">${NIVEAUS.slice(1).map(n =>
        `<button data-niv="${n.n}" class="kn${n.n} ${scores[d.id]===n.n?'gekozen':''}"><span class="lbl">${n.kort}</span></button>`).join('')}</div>
      <textarea class="invoer" data-not="${d.id}" rows="2" placeholder="Toelichting ${d.naam.toLowerCase()}...">${esc(notities[d.id]||'')}</textarea>
    </div>`;

  const rondeVoortgang = flow ? `<div class="ronde-voortgang">
      <div class="veldlabel" style="margin:0 0 var(--space-2xs)">${esc(flow.ronde.naam)}</div>
      <div class="rv-top"><div class="rv-teller"><b>${flow.index + 1}</b> / ${flow.ids.length} nog te doen</div>
        <div class="rv-klaar">${flow.ids.length - flow.index - 1 > 0 ? 'daarna nog ' + (flow.ids.length - flow.index - 1) : 'laatste speler'}</div></div>
      <div class="rv-track">${flow.ids.map((id, i) => `<span class="rv-seg ${i < flow.index ? 'gedaan' : i === flow.index ? 'nu' : ''}"></span>`).join('')}</div>
    </div>` : '';

  openModal(`
    <h2>Volledige beoordeling</h2>
    <p class="u-t-sm u-zacht u-mb-sm">${esc(p.naam)}${p.nummer!=null&&p.nummer!==''?'<span class="sep" aria-hidden="true"></span>#'+esc(p.nummer):''}</p>
    ${rondeVoortgang}
    <div class="veldgroep"><label>Hoort bij</label>
      <select class="invoer" id="mVbRonde">
        ${rondeOpties.map(r => `<option value="${esc(r.id)}" ${rondeStart === r.id ? 'selected' : ''}>${esc(r.naam)}${r.tot ? ' (t/m ' + esc(datumKort(r.tot)) + ')' : ''}${alInRonde(r) ? '<span class="sep" aria-hidden="true"></span>al beoordeeld' : ''}</option>`).join('')}
        ${rondeStart === '_oud' ? `<option value="_oud" selected>Officiële halfjaarevaluatie (eerder ingevuld)</option>` : ''}
        <option value="" ${rondeStart === '' ? 'selected' : ''}>Geen ronde<span class="sep" aria-hidden="true"></span>losse meting</option>
      </select></div>
    <div class="veldgroep"><label>Moment</label>
      <input class="invoer" id="mVbMoment" value="${esc(moment)}" placeholder="Bijv. Kwartaalmeting Q3"></div>
    ${SKILLS.map(domeinKaart).join('')}
    <button class="knop vol fluo u-mt-xs" id="mVbOk" >${bestaande?'Bijwerken':flow?'Opslaan en volgende →':'Beoordeling opslaan'}</button>
    ${flow ? `<button class="knop licht vol u-mt-xs" id="mVbSkip" >Speler overslaan →</button>` : ''}
    ${bestaande?`<button class="knop vol gevaar u-mt-xs" id="mVbWeg" >Verwijderen</button>`:''}
    <p class="u-t-xs u-zacht u-mt-sm u-lh-ruim">Tip: leerpunten beheer je in het tabblad <b>Leerlijn</b> van de speler: die lopen door over meerdere beoordelingen.</p>`);

  $$('.kleurbalk.dom').forEach(balk => {
    const dom = balk.dataset.dom;
    balk.querySelectorAll('[data-niv]').forEach(b => b.onclick = () => {
      scores[dom] = Number(b.dataset.niv);
      balk.querySelectorAll('[data-niv]').forEach(x => x.classList.toggle('gekozen', x===b));
    });
  });

  $('#mVbOk').onclick = async () => {
    if (!Object.keys(scores).length) return meld('Geef minstens één score');
    SKILLS.forEach(d => { const t = $(`[data-not="${d.id}"]`); if (t) notities[d.id] = t.value.trim(); });
    const rondeKeuze = $('#mVbRonde')?.value || '';
    const rondeId = rondeKeuze && rondeKeuze !== '_oud' ? rondeKeuze : null;
    const rondeNaam = rondeId ? (rondeOpties.find(r => r.id === rondeId)?.naam || '') : '';
    const data = {
      soort:'volledig', spelerId, datum:bestaande?.datum || vandaagISO(),
      bron:{type:'los', label:$('#mVbMoment').value.trim() || rondeNaam || 'Periodieke meting'},
      officieel: !!rondeId || rondeKeuze === '_oud',
      scores, notities, door:deelnemer(), gemaaktMs:Date.now(),
    };
    if (rondeId) data.ronde = rondeId;
    else if (bestaande?.ronde) data.ronde = deleteField();
    if (!bestaande) data.seizoen = S.huidigSeizoen || SEIZOEN_FALLBACK;
    try {
      if (bestaande) await updateDoc(doc(db,'teams',S.teamId,'beoordelingen',bestaande.id), data);
      else { await addDoc(collection(db,'teams',S.teamId,'beoordelingen'), data); telGebruik(rondeId ? 'ronde_beoordeling' : 'volledige_beoordeling'); }
      sluitModal();
      if (flow) volgendeEvalRonde(); else { herrenderTeam(); meld('Beoordeling opgeslagen'); }
    } catch(e){ meld('Opslaan mislukt: '+(e.code||e.message)); }
  };
  const skipVb = $('#mVbSkip');
  if (skipVb) skipVb.onclick = () => { sluitModal(); volgendeEvalRonde(); };
  const wegBtn = $('#mVbWeg');
  if (wegBtn) wegBtn.onclick = async () => {
    if (!confirm('Deze beoordeling verwijderen?')) return;
    await deleteDoc(doc(db,'teams',S.teamId,'beoordelingen',bestaande.id));
    sluitModal(); herrenderTeam();
  };
}

/* ---------- Evaluatieronde van de club: speler voor speler ----------
   [20260929a] Start bij de eerste speler die nog niet in de ronde beoordeeld is.
   Volledige ronde: de volledige beoordeling met "Hoort bij" = de ronde.
   Snelle ronde: de bestaande snelle ronde, met de ronde-id mee. */
export function startRondeFlow(rondeId){
  if (!modAan('evaluaties')) return meld('Evaluaties staan uit voor dit team');
  const ronde = (S._clubRondes || []).find(r => r.id === rondeId);
  if (!ronde) return meld('Deze evaluatieronde bestaat niet meer');
  const spelers = rondeSpelers(S.spelers);
  if (!spelers.length) return meld('Voeg eerst spelers toe');
  const gedaan = new Set(S.beoordelingen.filter(b => b.ronde === rondeId).map(b => b.spelerId));
  const ids = spelers.filter(p => !gedaan.has(p.id)).map(p => p.id);
  if (!ids.length) return meld(`Alle spelers zijn al beoordeeld voor ${ronde.naam}`);
  telGebruik('ronde_start');
  if (ronde.soort === 'snel'){
    S._snelRonde = { index:0, ids, overgeslagen:new Set(), ronde:{ id:ronde.id, naam:ronde.naam } };
    modalSnelBeoordeling(ids[0]);
  } else {
    S._evalRonde = { index:0, ids, ronde:{ id:ronde.id, naam:ronde.naam } };
    modalVolledigeBeoordeling(ids[0]);
  }
}
function volgendeEvalRonde(){
  const r = S._evalRonde; if (!r){ herrenderTeam(); return; }
  r.index++;
  if (r.index >= r.ids.length){ S._evalRonde = null; herrenderTeam(); meld(`${r.ronde.naam}: ronde doorlopen ✓`); return; }
  modalVolledigeBeoordeling(r.ids[r.index]);
}

/* --- Leerpunten (array op spelerdoc) --- */
export function modalLeerpunt(spelerId, voorlopigeTekst = ''){
  const p = speler(spelerId); if (!p) return;
  const cat = S.team.categorie || '';
  let domein = 'TA';
  // leercurve: relevante thema's eerst, daarna de overige (altijd zichtbaar)
  const themas = LEERCURVE
    .map(t => ({...t, rel: leercurveRelevant(t, cat)}))
    .sort((a,b) => (b.rel?1:0)-(a.rel?1:0));

  openModal(`
    <h2>Leerpunt toevoegen</h2>
    <p class="u-t-sm u-zacht u-mb-sm">Formuleer een concreet, observeerbaar doel voor ${esc(p.naam)}. Kies een thema uit de leerlijn of schrijf je eigen leerpunt.</p>

    <div class="veldlabel">Uit de leerlijn${cat?`, ${esc(cat)}`:''}</div>
    <div class="leercurve-keuze" id="mLpCurve">
      ${themas.map(t => {
        const d = skillDomein(t.domein);
        return `<button class="lc-thema ${t.rel?'rel':''}" data-thema="${esc(t.thema)}" data-dom="${t.domein}" title="${esc(d?.naam||'')}${t.rel?'':', vanaf O'+t.vanaf}">
          <span class="lc-dot" style="background:${t.rel?'var(--n5)':'var(--line-d)'}"></span>${esc(t.thema)}<span data-thema-info="${esc(t.thema)}" title="Achtergrond en tips" style="display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;background:color-mix(in srgb, var(--wit) 15%, transparent);font-size:var(--t-2xs);font-weight:700;margin-left:1px"></span></button>`;
      }).join('')}
    </div>
    <p class="u-t-2xs u-zacht" style="margin:var(--space-3xs) 0 var(--space-sm)">= hoort bij deze leeftijd volgens het jeugdbeleidsplan. Tik voor achtergrond en oefentips.</p>

    <div class="veldlabel">Domein</div>
    <div class="dom-kiezer" id="mLpDom">${SKILLS.map(d =>
      `<button data-d="${d.id}" class="${d.id==='TA'?'actief':''}" title="${esc(d.naam)}"><span class="dk-emoji">${d.ico?ico(d.ico,18):(d.emoji||'')}</span>${esc(d.kort||d.naam)}</button>`).join('')}</div>
    <p class="u-t-2xs u-zacht u-lh-ruim" style="margin:var(--space-xs) 0 var(--space-sm)">Techniek<span class="sep" aria-hidden="true"></span>Tactiek<span class="sep" aria-hidden="true"></span>Fysiek<span class="sep" aria-hidden="true"></span>Mentaal<span class="sep" aria-hidden="true"></span>Gedrag &amp; beleving, de vijf ontwikkeldomeinen uit het jeugdbeleidsplan.</p>

    <div class="veldgroep"><label>Leerpunt</label>
      <textarea class="invoer" id="mLpTekst" rows="3" placeholder="Bijv. eerder het hoofd omhoog vóór de aanname">${esc(voorlopigeTekst)}</textarea></div>
    <button class="knop vol fluo" id="mLpOk">Toevoegen</button>`);

  const zetDomein = (d) => { domein = d; $$('#mLpDom [data-d]').forEach(x => x.classList.toggle('actief', x.dataset.d===d)); };
  $$('#mLpDom [data-d]').forEach(b => b.onclick = () => zetDomein(b.dataset.d));
  $$('#mLpCurve [data-thema]').forEach(b => b.onclick = () => {
    $('#mLpTekst').value = b.dataset.thema;
    zetDomein(b.dataset.dom);
    $$('#mLpCurve .lc-thema').forEach(x => x.classList.toggle('gekozen', x===b));
  });
  $$('#mLpCurve [data-thema-info]').forEach(el => el.addEventListener('click', (e) => {
    e.stopPropagation();
    const behouden = $('#mLpTekst').value;
    toonThemaInfo(el.dataset.themaInfo, () => modalLeerpunt(spelerId, behouden));
  }));
  $('#mLpTekst').focus();
  $('#mLpOk').onclick = async () => {
    const tekst = $('#mLpTekst').value.trim();
    if (tekst.length < 3) return meld('Vul een leerpunt in');
    const nieuw = {id:'lp_'+Date.now().toString(36), domein, tekst, sinds:vandaagISO(), klaar:false};
    const lp = [...(p.leerpunten||[]), nieuw];
    try {
      await updateDoc(doc(db,'teams',S.teamId,'spelers',spelerId), {leerpunten: lp});
      syncLeerpuntenNaarUitlening(spelerId, lp);
      telGebruik('leerpunt_nieuw');
      sluitModal(); herrenderTeam(); meld('Leerpunt toegevoegd');
    } catch(e){ meld('Opslaan mislukt: '+(e.code||e.message)); }
  };
}
export async function toggleLeerpunt(lpId){
  const p = speler(S._beoordeelProfiel); if (!p) return;
  const doel = (p.leerpunten||[]).find(l => l.id === lpId);
  const wordtKlaar = doel && !doel.klaar;
  const lp = (p.leerpunten||[]).map(l => l.id === lpId
    ? {...l, klaar:!l.klaar, klaarOp: !l.klaar ? vandaagISO() : null} : l);
  await updateDoc(doc(db,'teams',S.teamId,'spelers',p.id), {leerpunten: lp});
  syncLeerpuntenNaarUitlening(p.id, lp);
  if (wordtKlaar) telGebruik('leerpunt_klaar');
}
export async function verwijderLeerpunt(lpId){
  const p = speler(S._beoordeelProfiel); if (!p) return;
  if (!confirm('Dit leerpunt verwijderen?')) return;
  const lp = (p.leerpunten||[]).filter(l => l.id !== lpId);
  await updateDoc(doc(db,'teams',S.teamId,'spelers',p.id), {leerpunten: lp});
  syncLeerpuntenNaarUitlening(p.id, lp);
}

function meestGespeeldHtml(top){
  if (!top.length) return '';
  const beste = top[0];
  return `
    <div class="meest-gespeeld" id="mSpMg">
      <div class="mg-titel"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg> Meest gespeeld dit seizoen</div>
      <div class="mg-lijst">
        ${top.slice(0,4).map((t,i) => `<span class="mg-item${i===0?' mg-top':''}">${esc(t.naam)} <b>${t.n}×</b></span>`).join('')}
      </div>
      <button type="button" class="mg-knop" id="mSpMgOk" data-pos="${esc(beste.naam)}">Overnemen: ${esc(beste.naam)}</button>
    </div>`;
}

export function modalSpeler(p){
  const bewerken = !!p;
  let gekozenPositie = p?.positie || '';
  const topPosities = bewerken ? meestGespeeldePosities(p.id) : [];
  openModal(`
    <h2>${bewerken ? 'Speler bewerken' : 'Speler toevoegen'}</h2>
    <div class="rij">
      <div class="veldgroep" style="flex:3"><label>Voornaam</label>
        <input class="invoer" id="mSpNaam" value="${esc(p?.naam||'')}" placeholder="Voornaam" autocomplete="off"></div>
      <div class="veldgroep u-flex-1"><label>Nr.</label>
        <input class="invoer" id="mSpNr" value="${esc(p?.nummer ?? '')}" inputmode="numeric" placeholder="7"></div>
    </div>
    <div class="veldgroep"><label>Achternaam</label>
      <input class="invoer" id="mSpAchter" value="${esc(p?.achternaam||'')}" placeholder="Achternaam" autocomplete="off"></div>
    <div class="avg-balk"><span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4.6" y="10.4" width="14.8" height="9.8" rx="2.4"/><path d="M8 10.4V8a4 4 0 0 1 8 0v2.4"/><circle cx="12" cy="15.2" r="1.4" fill="currentColor" stroke="none"/></svg></span>
      <span>De achternaam blijft binnen je eigen team en wordt nergens in de app getoond. Leen je deze speler uit, dan ziet de andere coach alleen de voorletter.</span></div>
    ${bewerken ? `
      <div class="veldgroep">
        <label>Voorkeurspositie</label>
        ${meestGespeeldHtml(topPosities)}
        <div id="mSpPos">
          ${POSITIE_GROEPEN.map(g => `
            <div class="pos-groep">
              <div class="pos-lijnlabel">${esc(g.naam)}</div>
              <div class="segment klein-seg wrap">
                ${g.posities.map(pos => `<button type="button" data-pos="${esc(pos)}" class="${gekozenPositie===pos?'actief':''}">${esc(pos)}</button>`).join('')}
              </div>
            </div>`).join('')}
        </div>
      </div>` : ''}
    <button class="knop vol" id="mSpOk">${bewerken ? 'Opslaan' : 'Toevoegen'}</button>`);

  if (bewerken){
    const zetPositie = (pos) => {
      gekozenPositie = pos;
      $('#mSpPos').querySelectorAll('[data-pos]').forEach(x =>
        x.classList.toggle('actief', x.dataset.pos === gekozenPositie));
    };
    $('#mSpPos').querySelectorAll('[data-pos]').forEach(b => b.onclick = () => {
      zetPositie(gekozenPositie === b.dataset.pos ? '' : b.dataset.pos);   // nogmaals tikken = leegmaken
    });
    if ($('#mSpMgOk')) $('#mSpMgOk').onclick = () => zetPositie($('#mSpMgOk').dataset.pos);
  }

  const ok = async (sluiten) => {
    const naam = $('#mSpNaam').value.trim();
    if (!naam) return meld('Vul een naam in');
    const nr = $('#mSpNr').value.trim();
    const data = {
      naam,
      achternaam: $('#mSpAchter').value.trim() || null,
      nummer: nr === '' ? null : Number(nr),
    };
    if (bewerken) data.positie = gekozenPositie || null;
    if (p){ await updateDoc(doc(db,'teams',S.teamId,'spelers',p.id), data); telGebruik('speler_bewerken'); }
    else  { await addDoc(collection(db,'teams',S.teamId,'spelers'), data); telGebruik('speler_nieuw'); }
    if (sluiten) sluitModal();
    else { $('#mSpNaam').value=''; $('#mSpNr').value=''; $('#mSpAchter').value=''; $('#mSpNaam').focus(); meld(naam+' toegevoegd'); }
  };
  $('#mSpOk').onclick = () => ok(bewerken);
  const enterAdd = e => { if (e.key === 'Enter') ok(false); };
  $('#mSpNaam').addEventListener('keydown', enterAdd);
  $('#mSpAchter').addEventListener('keydown', enterAdd);
}

/* ===================== Coach-notitie ===================== *
 * Vrij tekstveld op het spelerdoc (veld: notitie). Coach-only, valt onder
 * dezelfde afscherming als de rest van het profiel. Een gevulde notitie
 * toont een vlaggetje in de spelerslijst (zie htmlSpelers). */
export function modalNotitie(spelerId){
  const p = speler(spelerId);
  if (!p) return;
  openModal(`
    <h2>Notitie<span class="sep" aria-hidden="true"></span>${esc(p.naam)}</h2>
    <div class="veldgroep">
      <textarea class="invoer" id="mNotTekst" rows="5"
        placeholder="Bijv. is altijd op de eerste van de maand afwezig voor werk, vindt het fijn om extra complimenten te krijgen">${esc(p.notitie || '')}</textarea>
    </div>
    <div class="avg-balk"><span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4.6" y="10.4" width="14.8" height="9.8" rx="2.4"/><path d="M8 10.4V8a4 4 0 0 1 8 0v2.4"/><circle cx="12" cy="15.2" r="1.4" fill="currentColor" stroke="none"/></svg></span>
      <span>Coach-only. Niet zichtbaar voor spelers of ouders. Zet hier geen gevoelige (medische/AVG) gegevens in.</span></div>
    <button class="knop vol" id="mNotOk">Opslaan</button>`);

  $('#mNotOk').onclick = async () => {
    const tekst = $('#mNotTekst').value.trim();
    const knop = $('#mNotOk');
    knop.disabled = true; knop.textContent = 'Opslaan...';
    try {
      await updateDoc(doc(db,'teams',S.teamId,'spelers',p.id), { notitie: tekst || null });
      telGebruik('speler_notitie');
      sluitModal();
      meld(tekst ? 'Notitie opgeslagen' : 'Notitie verwijderd');
    } catch (e){
      console.error(e); knop.disabled = false; knop.textContent = 'Opslaan';
      meld('Opslaan mislukt');
    }
  };
  setTimeout(() => $('#mNotTekst')?.focus(), 50);
}

/* ===================== Uitlenen (spiegelmodel) ===================== *
 * Leen-records leven centraal onder clubs/{clubId}/uitleningen/{leenId}.
 * Model 1a (spiegel): het echte spelerdocument BLIJFT in teams/{vanTeam}/spelers.
 * Het ontvangende team krijgt de speler via een merge in S.spelers (zie
 * herbouwSpelers in teams.js) en laat hem volwaardig meedraaien in opstelling,
 * presentie en evaluatie. Bij het bronteam blijft de speler EVENEENS gewoon
 * bruikbaar (sinds 2026-09-04 geen blokkade meer) — dekt het geval waarin
 * dezelfde speler dezelfde dag voor beide teams speelt (bv. 9:00 bij ons,
 * 11:00 elders). Een chip "⇄ ook bij {team}" bij zijn naam maakt dat
 * zichtbaar; de coach houdt zelf de klok in de gaten. Er is GEEN tijdvenster:
 * de uitleen loopt door tot coach A óf coach B hem terugzet, of tot de
 * clubadmin hem definitief overzet.
 *
 * Recordvorm:
 *   { spelerId, vanTeam, vanTeamNaam, naarTeam, naarTeamNaam,
 *     overlay:{nummer?,positie?},   // door ontvangend team aanpasbaar; origineel blijft ongemoeid
 *     snapshot:{naam,nummer,positie,achternaam,leerpunten},  // basisgegevens + open leerpunten
 *                                    // reizen mee (B heeft geen leesrecht op A's spelers)
 *     door, gemaakt }
 *
 * snapshot.leerpunten is een momentopname (alleen niet-afgeronde leerpunten,
 * ontdaan van id/domein — puur leestekst voor de ontvangende coach). Bij elke
 * leerpunt-wijziging bij het bronteam (voegLeerpuntToe/toggleLeerpunt/
 * verwijderLeerpunt) wordt syncLeerpuntenNaarUitlening() aangeroepen zodat
 * een actieve uitlening automatisch bijblijft — geen losse "ververs"-knop
 * nodig. Stopt met bijwerken zodra de uitlening wordt teruggezet (record
 * bestaat dan niet meer). */

// Actieve UITGAANDE uitlening voor een speler van het eigen team (of null).
function actieveUitleningVoor(spelerId){
  return (S.uitleningenUit||[]).find(u => u.spelerId === spelerId) || null;
}

// Open (niet-afgeronde) leerpunten, ontdaan van interne velden — dit is wat
// er in het snapshot terechtkomt en dus zichtbaar wordt bij het andere team.
function openLeerpuntenVoorSnapshot(leerpunten){
  return (leerpunten||[]).filter(l => !l.klaar).map(l => ({tekst:l.tekst, domein:l.domein||null, sinds:l.sinds||null}));
}

// Basisgegevens die met het leen-record meereizen zodat het ontvangende team
// de speler kan tonen zonder leesrecht op de spelers-collectie van het bronteam.
// Geëxporteerd zodat bouw-hub.js (coördinator, cross-team uitlenen) exact
// hetzelfde snapshot bouwt als de reguliere coach-flow hierboven.
export function bouwLeenSnapshot(p){
  return {
    naam: p.naam,
    achternaam: p.achternaam || null,
    nummer: p.nummer ?? null,
    positie: p.positie || null,
    leerpunten: openLeerpuntenVoorSnapshot(p.leerpunten),
  };
}

// Als er een actieve uitgaande uitlening voor deze speler loopt, het
// leerpunten-deel van het snapshot verversen. Stil falen (bv. net
// teruggezet) — dit mag nooit de eigenlijke leerpunt-actie blokkeren.
function syncLeerpuntenNaarUitlening(spelerId, leerpunten){
  const u = actieveUitleningVoor(spelerId);
  if (!u) return;
  const clubId = S.team?.club; if (!clubId) return;
  updateDoc(doc(db,'clubs',clubId,'uitleningen',u.id), {
    'snapshot.leerpunten': openLeerpuntenVoorSnapshot(leerpunten),
  }).catch(() => {});
}

export async function modalUitlenen(spelerId){
  const p = speler(spelerId);
  if (!p) return;
  if (p._ingeleend) return meld('Een ingeleende speler kun je niet doorlenen');
  const clubId = S.team?.club;
  if (!clubId) return meld('Dit team hoort niet bij een club');

  openModal(`
    <h2>${esc(p.naam)} uitlenen</h2>
    <div class="veldgroep"><label>Aan welk team?</label>
      <select class="invoer" id="mUlTeam"><option value="">Teams laden…</option></select></div>
    <div class="avg-balk"><span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4.6" y="10.4" width="14.8" height="9.8" rx="2.4"/><path d="M8 10.4V8a4 4 0 0 1 8 0v2.4"/><circle cx="12" cy="15.2" r="1.4" fill="currentColor" stroke="none"/></svg></span>
      <span>De speler doet vanaf nu volwaardig mee bij het gekozen team: opstelling, presentie en evaluatie. Bij jou blijft hij ook gewoon bruikbaar, handig als hij dezelfde dag voor beide teams speelt. Er zit geen einddatum op, jij of de andere coach zet hem terug.</span></div>
    <button class="knop vol" id="mUlOk" disabled>Uitlenen bevestigen</button>`);

  // Doelteams ophalen: alle teams van de club behalve het eigen team.
  let doelTeams = [];
  try {
    const csnap = await getDoc(doc(db,'clubs',clubId));
    const ids = csnap.exists() ? Object.keys(csnap.data().teams || {}) : [];
    const andere = ids.filter(id => id !== S.teamId);
    for (let i=0;i<andere.length;i+=30){
      const chunk = andere.slice(i,i+30);
      if (!chunk.length) break;
      const tsnap = await getDocs(query(collection(db,'teams'), where(documentId(),'in',chunk)));
      tsnap.docs.forEach(d => doelTeams.push({id:d.id, naam:d.data().naam || '?'}));
    }
    doelTeams.sort((a,b)=> a.naam.localeCompare(b.naam));
  } catch(e){
    meld('Teams ophalen mislukt: ' + (e.code||e.message));
  }

  const sel = $('#mUlTeam');
  if (!doelTeams.length){
    sel.innerHTML = '<option value="">Geen andere teams gevonden</option>';
  } else {
    sel.innerHTML = '<option value="">Kies een team…</option>' +
      doelTeams.map(t => `<option value="${t.id}|${esc(t.naam)}">${esc(t.naam)}</option>`).join('');
  }

  const okBtn = $('#mUlOk');
  const check = () => { okBtn.disabled = !sel.value; };
  sel.onchange = check;

  okBtn.onclick = async () => {
    const [naarTeam, naarTeamNaam] = sel.value.split('|');
    if (!naarTeam) return;
    okBtn.disabled = true; okBtn.textContent = 'Bezig…';
    try {
      telGebruik('uitlenen');
      await addDoc(collection(db,'clubs',clubId,'uitleningen'), {
        spelerId: p.id,
        vanTeam: S.teamId,
        vanTeamNaam: S.team.naam,
        naarTeam,
        naarTeamNaam,
        overlay: {},
        snapshot: bouwLeenSnapshot(p),
        door: S.user?.uid || null,
        gemaakt: serverTimestamp(),
      });
      sluitModal();
      meld(`${p.naam} uitgeleend aan ${naarTeamNaam}`);
    } catch(e){
      okBtn.disabled = false; okBtn.textContent = 'Uitlenen bevestigen';
      meld('Uitlenen mislukt: ' + (e.code||e.message));
    }
  };
}

/* Terugzetten naar het eigen team. Mag door coach A (vanTeam) én coach B
   (naarTeam): het leen-record wordt verwijderd. Alles wat team B tijdens de
   uitleen op de speler bouwde (presentie/opstelling/evaluatie in teams/B/…)
   blijft in team B staan — bewuste keuze: beide teams houden hun historie. */
/* [20260918] Generalisatie: accepteert nu ook een volledig uitlening-object
   (i.p.v. alleen een id) plus een expliciete clubId, zodat dit ook buiten
   teamcontext werkt — de bouw-hub (coördinator, meerdere teams tegelijk)
   heeft geen S.team/S.uitleningenIn/S.uitleningenUit beschikbaar. Bestaande
   aanroepen met alleen een id-string blijven ongewijzigd werken. */
export async function trekUitleningIn(uitleenIdOfObject, clubIdOverride){
  const u = typeof uitleenIdOfObject === 'string'
    ? (S.uitleningenUit||[]).find(x => x.id === uitleenIdOfObject) || (S.uitleningenIn||[]).find(x => x.id === uitleenIdOfObject)
    : uitleenIdOfObject;
  const clubId = clubIdOverride || S.team?.club;
  if (!clubId || !u) return meld('Uitlening niet gevonden');
  const naam = u.snapshot?.naam || 'De speler';
  const vraag = (S.teamId && u.naarTeam === S.teamId)
    ? `${naam} terugzetten naar ${u.vanTeamNaam}? Hij verdwijnt dan uit jouw selectie.`
    : `${naam} terughalen? Hij verdwijnt direct bij ${u.naarTeamNaam} en komt terug bij ${u.vanTeamNaam}.`;
  if (!confirm(vraag)) return;
  try {
    await deleteDoc(doc(db,'clubs',clubId,'uitleningen',u.id));
    telGebruik('uitlenen_intrek');
    // Lokale lijsten meteen bijwerken zodat de UI klopt ook als de
    // listener-snapshot voor deze eigen delete (tijdelijk) uitblijft.
    // Alleen relevant/gevuld als we in teamcontext zitten — buiten teams.js
    // om (bouw-hub) zijn dit sowieso lege arrays, dus onschuldig.
    S.uitleningenUit = (S.uitleningenUit||[]).filter(x => x.id !== u.id);
    S.uitleningenIn  = (S.uitleningenIn ||[]).filter(x => x.id !== u.id);
    S._beoordeelProfiel = null;
    if (S.teamId) herrenderTeam();
    meld('Speler teruggezet');
    return true;
  } catch(e){
    if (e.code === 'permission-denied'){
      meld('Terugzetten mislukt: je hebt geen toegang (meer) tot een van de betrokken teams.');
    } else {
      meld('Terugzetten mislukt: ' + (e.code||e.message));
    }
    return false;
  }
}

/* Overlay bewerken door het ONTVANGENDE team: nummer/positie die alleen bij
   team B gelden. Het origineel bij team A blijft ongemoeid. */
export function modalLeenOverlay(spelerId){
  const p = speler(spelerId);
  if (!p || !p._ingeleend) return;
  const clubId = S.team?.club;
  if (!clubId) return;
  let gekozenPositie = p.positie || '';
  openModal(`
    <h2>Bij jou aanpassen</h2>
    <div class="avg-balk"><span class="slot">⇄</span>
      <span>${esc(p.naam)} is ingeleend van <b>${esc(p._bronTeamNaam||'een ander team')}</b>. Wat je hier wijzigt geldt <b>alleen in jouw team</b>, het origineel bij het andere team blijft ongemoeid.</span></div>
    <div class="veldgroep"><label>Rugnummer bij jou</label>
      <input class="invoer" id="mLoNr" value="${esc(p.nummer ?? '')}" inputmode="numeric" placeholder="7"></div>
    <div class="veldgroep">
      <label>Voorkeurspositie bij jou</label>
      <div id="mLoPos">
        ${POSITIE_GROEPEN.map(g => `
          <div class="pos-groep">
            <div class="pos-lijnlabel">${esc(g.naam)}</div>
            <div class="segment klein-seg wrap">
              ${g.posities.map(pos => `<button type="button" data-pos="${esc(pos)}" class="${gekozenPositie===pos?'actief':''}">${esc(pos)}</button>`).join('')}
            </div>
          </div>`).join('')}
      </div>
    </div>
    <button class="knop vol" id="mLoOk">Opslaan</button>`);

  const zetPositie = (pos) => {
    gekozenPositie = pos;
    $('#mLoPos').querySelectorAll('[data-pos]').forEach(x =>
      x.classList.toggle('actief', x.dataset.pos === gekozenPositie));
  };
  $('#mLoPos').querySelectorAll('[data-pos]').forEach(b => b.onclick = () => {
    zetPositie(gekozenPositie === b.dataset.pos ? '' : b.dataset.pos);
  });

  $('#mLoOk').onclick = async () => {
    const nr = $('#mLoNr').value.trim();
    const overlay = {
      nummer: nr === '' ? null : Number(nr),
      positie: gekozenPositie || null,
    };
    const knop = $('#mLoOk'); knop.disabled = true; knop.textContent = 'Opslaan…';
    try {
      /* [20260928f] per veld schrijven: zo blijven overlay.elftal (selectie-bouw) en overlay.meetelVanaf staan */
      await updateDoc(doc(db,'clubs',clubId,'uitleningen',p._leenId), { 'overlay.nummer': overlay.nummer, 'overlay.positie': overlay.positie });
      telGebruik('uitlenen_overlay');
      sluitModal();
      meld('Aangepast bij jou');
    } catch(e){
      knop.disabled = false; knop.textContent = 'Opslaan';
      meld('Opslaan mislukt: ' + (e.code||e.message));
    }
  };
}

/* ===================== Overdrachtsdossier (definitief overzetten) =====================
 * Bij een definitieve overzet verhuist het spelerdocument (zelfde id) naar het
 * ontvangende team. Het ORIGINEEL bij het bronteam wordt NIET verwijderd maar
 * gearchiveerd (gearchiveerd:true, naarTeam, gearchiveerdOp): al zijn gegevens
 * daar blijven bewaard, en de wedstrijden/presentie/beoordelingen van het
 * bronteam blijven onaangeroerd. Teamlijsten negeren gearchiveerde spelers
 * (zie de spelers-listener in teams.js).
 *
 * Het ontvangende team krijgt daarnaast een BEVROREN dossier met alleen de
 * eigen gegevens van deze speler uit het bronteam, als subcollectie
 *   teams/{naarTeam}/spelers/{id}/vorigeTeams/{stintId}
 * (valt onder de bestaande /{sub=**}-regel, dus geen rules-wijziging nodig).
 * Het dossier staat bewust buiten S.wedstrijden/S.presentie: het telt nooit mee
 * in teamcijfers, alleen in het spelersprofiel (scope Heel seizoen / Carrière).
 * Andere spelers van het bronteam gaan nooit mee. */
const DOSSIER_VERSIE = 1;

// 'YYYY-MM-DD' uit een Firestore-timestamp, Date of datumtekst; null als onbekend.
function isoDatum(x){
  try {
    if (typeof x === 'string' && /^\d{4}-\d{2}-\d{2}/.test(x)) return x.slice(0, 10);
    const d = x && x.toDate ? x.toDate() : (x instanceof Date ? x : null);
    if (!d || isNaN(d)) return null;
    const p = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`;
  } catch { return null; }
}
const vandaagIso = () => isoDatum(new Date());

/* Berekent het ruwe dossier van één speler uit het bronteam. Leest alleen; schrijft niets. */
async function bouwOverdrachtDossier({ vanTeam, vanTeamNaam, spelerId, speler: bron, uitleen }){
  const pid = spelerId;
  const [wSnap, pSnap, bSnap] = await Promise.all([
    getDocs(collection(db,'teams',vanTeam,'wedstrijden')),
    getDocs(collection(db,'teams',vanTeam,'presentie')),
    getDocs(query(collection(db,'teams',vanTeam,'beoordelingen'), where('spelerId','==',pid))),
  ]);

  const wedstrijden = [];
  for (const d of wSnap.docs){
    const w = { id:d.id, ...d.data() };
    const inSel = Array.isArray(w.selectie) && w.selectie.includes(pid);
    let a = {tijd:{}, keeper:{}, lijn:{}, kwarten:0, matchduur:0}, disc = 0, laat = 0;
    try { a = analyseWedstrijd(w); disc = disciplinaireTijd(w)[pid] || 0; laat = telaatTijd(w)[pid] || 0; } catch(e){ /* beschadigde wedstrijd: tel alleen wat zeker is */ }
    const goalsLijst = Array.isArray(w.goals) ? w.goals : [];
    const goals   = goalsLijst.filter(g => g.type === 'voor' && g.pid === pid).length;
    const assists = goalsLijst.filter(g => g.type === 'voor' && g.assist === pid).length;
    const kaarten = (Array.isArray(w.kaarten) ? w.kaarten : []).filter(c => c.pid === pid);
    const tijd = a.tijd?.[pid] || 0;
    if (!inSel && !tijd && !goals && !assists && !kaarten.length) continue;
    const n = (inSel && a.kwarten && a.matchduur) ? persoonlijkeNoemer(a, pid, disc, laat) : null;
    const wissels = [];
    for (const nr of Object.keys(w.kwarten || {})){
      for (const e of (w.kwarten[nr]?.events || [])){
        if (e.uit === pid) wissels.push({ kwart: Number(nr) || nr, sec: e.sec ?? null, soort:'uit', reden: e.reden || null, disciplinair: !!e.disciplinair });
        if (e.in === pid)  wissels.push({ kwart: Number(nr) || nr, sec: e.sec ?? null, soort:'in',  reden: null, disciplinair: false });
      }
    }
    wedstrijden.push({
      id: w.id, datum: w.datum || null, seizoen: w.seizoen || null,
      tegenstander: w.tegenstander || (isToernooi(w) ? 'Toernooi' : 'Wedstrijd'),
      soort: w.type || 'normaal', thuis: !!w.thuis, elftal: w.elftal || null,
      voor: goalsLijst.filter(g => g.type === 'voor').length,
      tegen: goalsLijst.filter(g => g.type === 'tegen').length,
      inSelectie: inSel, tijd, speelbaar: n ? n.speelbaar : 0, keeper: a.keeper?.[pid] || 0,
      goals, assists,
      geel: kaarten.filter(c => c.type === 'geel').length,
      rood: kaarten.filter(c => c.type === 'rood').length,
      posities: Object.entries(a.lijn?.[pid] || {}).map(([naam, k]) => ({ naam, n:k })),
      wissels, straf: disc, laat, startBank: w.startBankReden?.[pid] || null,
    });
  }
  wedstrijden.sort((x, y) => (y.datum || '').localeCompare(x.datum || ''));

  // Training-aanwezigheid per datum, alleen sessies die voor deze speler meetellen (zie opkomst.js).
  const spInfo = { id: pid, meetelVanaf: bron.meetelVanaf || null };
  const presentie = [];
  for (const d of pSnap.docs){
    const s = { id:d.id, ...d.data() };
    if (!teltMee(s, spInfo)) continue;
    const afw = (s.afwezig || []).includes(pid);
    const rec = (s.afwezigRedenen || {})[pid];
    const info = rec ? afwezigRedenInfo(rec) : null;
    presentie.push({ id: s.id, datum: s.datum || null, seizoen: s.seizoen || null, aanwezig: !afw, reden: afw ? (info?.id || null) : null });
  }
  presentie.sort((x, y) => (y.datum || '').localeCompare(x.datum || ''));

  const beoordelingen = bSnap.docs.map(d => ({ id:d.id, ...d.data() }))
    .sort((x, y) => (y.datum || '').localeCompare(x.datum || '') || (y.gemaaktMs || 0) - (x.gemaaktMs || 0));

  return {
    spelerId: pid, naam: bron.naam || null, teamId: vanTeam, teamNaam: vanTeamNaam || null,
    wedstrijden, presentie, beoordelingen,
    leerpunten: Array.isArray(bron.leerpunten) ? bron.leerpunten : [],
    uitleen: uitleen ? { sinds: isoDatum(uitleen.gemaakt), overlay: uitleen.overlay || null } : null,
  };
}

// Per seizoen optellen uit tellers (nooit gemiddelden middelen): zo kunnen scopes later
// percentages opnieuw uitrekenen over de som.
function dossierSeizoenen(wedstrijden, presentie){
  const per = {};
  const sz = k => (per[k] ||= { seizoen:k, wedstrijden:0, tijd:0, speelbaar:0, reserve:0, goals:0, assists:0, trainingen:0, aanwezig:0 });
  for (const r of wedstrijden){
    const s = sz(r.seizoen || 'onbekend');
    if (r.tijd > 0) s.wedstrijden++;
    s.tijd += r.tijd; s.goals += r.goals; s.assists += r.assists;
    if (r.inSelectie){ s.speelbaar += r.speelbaar; s.reserve += Math.max(0, r.speelbaar - r.tijd); }
  }
  for (const r of presentie){ const s = sz(r.seizoen || 'onbekend'); s.trainingen++; if (r.aanwezig) s.aanwezig++; }
  return Object.values(per).sort((x, y) => String(y.seizoen).localeCompare(String(x.seizoen)));
}

// Ruw dossier + keuzes → het document zoals het wordt opgeslagen.
function dossierDoc(raw, mee, datum){
  const wedstrijden = mee.wed ? raw.wedstrijden : [];
  const presentie   = mee.tr  ? raw.presentie   : [];
  const datums = [...wedstrijden.map(r => r.datum), ...presentie.map(r => r.datum)].filter(Boolean).sort();
  return {
    versie: DOSSIER_VERSIE, spelerId: raw.spelerId, naam: raw.naam,
    teamId: raw.teamId, teamNaam: raw.teamNaam,
    tot: datum || null, van: datums[0] || null, laatste: datums[datums.length - 1] || null,
    bevroren: vandaagIso(), mee: { ...mee },
    seizoenen: dossierSeizoenen(wedstrijden, presentie),
    wedstrijden, presentie,
    beoordelingen: mee.beo ? raw.beoordelingen : [],
    leerpunten: mee.lp ? raw.leerpunten : [],
    uitleen: raw.uitleen,
  };
}

/* Definitief overzetten — clubadmin, of de bouwcoördinator van het
   ontvangende team. Echte verhuizing: het spelerdocument wordt naar het
   ontvangende team gekopieerd (met de overlay als nieuwe basiswaarde) en het
   leen-record opgeruimd. De speler-id verandert bewust NIET, zodat de
   historie die in beide teams aan spelerId hangt intact blijft.
   [20261010] Het origineel bij het bronteam wordt gearchiveerd i.p.v.
   verwijderd, het ontvangende team krijgt een bevroren dossier (zie hierboven),
   een gekoppelde gast wordt samengevoegd i.p.v. overschreven, en
   overlay.meetelVanaf blijft bewaard. De bevestiging is nu een dialoog.
   [20260918] accepteert ook een volledig uitlening-object + expliciete
   clubId/bouwHint, voor gebruik buiten teamcontext (bouw-hub). Geeft true bij
   gelukt, false bij annuleren of mislukken. */
export async function definitiefOverzetten(uitleenIdOfObject, clubIdOverride, bouwHint){
  const u = typeof uitleenIdOfObject === 'string'
    ? (S.uitleningenIn||[]).find(x => x.id === uitleenIdOfObject) || (S.uitleningenUit||[]).find(x => x.id === uitleenIdOfObject)
    : uitleenIdOfObject;
  const clubId = clubIdOverride || S.team?.club;
  if (!clubId) return meld('Geen club-context');
  const bouw = bouwHint || S.team?.bouw;
  if (!isBeheerder() && !isBouwCoordinator(bouw)) return meld('Alleen de clubadmin of de bouwcoördinator kan een speler definitief overzetten');
  if (!u) return meld('Uitlening niet gevonden');
  const naam = u.snapshot?.naam || 'De speler';

  openModal(`<h2>${esc(naam)} overzetten</h2><p class="ov-tekst">Gegevens uit ${esc(u.vanTeamNaam || 'het bronteam')} laden…</p>`, { vorm:'dialoog' });
  let bronRef, bron, raw;
  try {
    bronRef = doc(db,'teams',u.vanTeam,'spelers',u.spelerId);
    const snap = await getDoc(bronRef);
    if (!snap.exists()){ sluitModal(); meld('Origineel niet meer gevonden bij het bronteam'); return false; }
    bron = snap.data();
    raw = await bouwOverdrachtDossier({ vanTeam:u.vanTeam, vanTeamNaam:u.vanTeamNaam, spelerId:u.spelerId, speler:bron, uitleen:u });
  } catch(e){
    sluitModal();
    meld(e.code === 'permission-denied'
      ? 'Overzetten mislukt: je hebt niet over beide teams (coach- of coördinatorrechten) genoeg toegang.'
      : 'Overzetten mislukt: ' + (e.code || e.message));
    return false;
  }

  const datumStart = isoDatum(u.overlay?.meetelVanaf) || isoDatum(u.gemaakt) || vandaagIso();
  openModal(htmlOverzetDialoog(u, naam, raw, bron, datumStart), { vorm:'dialoog' });
  return new Promise(resolve => {
    $('#ovAnnuleer').onclick = () => { sluitModal(); resolve(false); };
    $('#ovZet').onclick = async () => {
      const knop = $('#ovZet'); knop.disabled = true; knop.textContent = 'Bezig met overzetten…';
      const mee = { wed:$('#ovMee_wed').checked, beo:$('#ovMee_beo').checked, tr:$('#ovMee_tr').checked, lp:$('#ovMee_lp').checked, not:$('#ovMee_not') ? $('#ovMee_not').checked : false };
      const d = $('#ovDatum').value;
      const datum = /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : datumStart;
      const ok = await voerOverzettenUit(u, clubId, bronRef, bron, raw, mee, datum);
      sluitModal();
      resolve(ok);
    };
  });
}

function htmlOverzetDialoog(u, naam, raw, bron, datum){
  const tijd = raw.wedstrijden.reduce((s, r) => s + r.tijd, 0);
  const goals = raw.wedstrijden.reduce((s, r) => s + r.goals, 0);
  const assists = raw.wedstrijden.reduce((s, r) => s + r.assists, 0);
  const aanw = raw.presentie.filter(r => r.aanwezig).length;
  const lpKlaar = raw.leerpunten.filter(l => l.klaar).length;
  const n = (k, een, meer) => `${k} ${k === 1 ? een : meer}`;
  const rij = (k, titel, sub) => `<label class="ov-mee-rij"><input type="checkbox" id="ovMee_${k}" checked><span>${titel}<span class="ov-n">${sub}</span></span></label>`;
  const van = esc(u.vanTeamNaam || 'het bronteam'), naar = esc(u.naarTeamNaam || 'het nieuwe team');
  return `
    <h2>${esc(naam)} overzetten</h2>
    <p class="ov-tekst">Van ${van} naar ${naar}. ${esc(naam)} blijft bij ${van} bewaard als gearchiveerde speler, met al zijn gegevens. Kies wat er naar ${naar} wordt gekopieerd.</p>
    <div class="ov-mee">
      ${rij('wed', 'Wedstrijden', `${n(raw.wedstrijden.length, 'wedstrijd', 'wedstrijden')}, ${uurMin(tijd)}, ${goals} goals, ${assists} assists`)}
      ${rij('beo', 'Beoordelingen', n(raw.beoordelingen.length, 'beoordeling', 'beoordelingen'))}
      ${rij('tr', 'Trainingsaanwezigheid per datum', `${n(raw.presentie.length, 'training', 'trainingen')}, ${aanw}× aanwezig`)}
      ${rij('lp', 'Leerpunten', `${n(raw.leerpunten.length, 'leerpunt', 'leerpunten')}, ${lpKlaar} afgerond`)}
      ${bron.notitie ? rij('not', 'Spelernotitie', 'Gaat mee, zoals nu') : ''}
    </div>
    <div class="avg-balk u-mb-sm"><span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="4.6" y="10.4" width="14.8" height="9.8" rx="2.4"/><path d="M8 10.4V8a4 4 0 0 1 8 0v2.4"/><circle cx="12" cy="15.2" r="1.4" fill="currentColor" stroke="none"/></svg></span><span>Alleen de eigen gegevens van ${esc(naam)} gaan mee. Geen andere spelers uit ${van}.</span></div>
    <div class="veldgroep"><label for="ovDatum">Bij ${naar} sinds</label>
      <input class="invoer" id="ovDatum" type="date" value="${datum}">
      <div class="ov-hint">Opkomst op trainingen telt vanaf deze datum.</div></div>
    <button class="knop fluo vol" id="ovZet">Definitief overzetten</button>
    <button class="knop licht vol u-mt-xs" id="ovAnnuleer" >Annuleren</button>`;
}

/* Voert de overzet uit. Volgorde is bewust: eerst alles bijschrijven bij het
   ontvangende team, dan pas het origineel archiveren en het leen-record
   opruimen. Mislukt het halverwege, dan is er niets kwijt (het origineel staat
   er nog) en kan de admin het opnieuw proberen: alle writes zijn merge:true. */
async function voerOverzettenUit(u, clubId, bronRef, bron, raw, mee, datum){
  const naam = u.snapshot?.naam || 'De speler';
  try {
    const naarId = u.adopteertGast || u.spelerId;           // id van het document bij het ontvangende team
    const naarRef = doc(db,'teams',u.naarTeam,'spelers',naarId);
    const stintenRef = collection(db,'teams',u.naarTeam,'spelers',naarId,'vorigeTeams');

    // 1) dossier: eerdere dossiers van deze speler (keten A→B→C) + het nieuwe
    const eerdere = await getDocs(collection(db,'teams',u.vanTeam,'spelers',u.spelerId,'vorigeTeams'));
    for (const d of eerdere.docs) await setDoc(doc(stintenRef, d.id), d.data(), { merge:true });
    await setDoc(doc(stintenRef, `${u.vanTeam}_${datum}`), dossierDoc(raw, mee, datum), { merge:true });

    // 2) spelerdocument: kopie van het origineel met overlay als nieuwe basiswaarde
    const data = { ...bron };
    if (u.overlay?.nummer !== undefined && u.overlay.nummer !== null) data.nummer = u.overlay.nummer;
    if (u.overlay?.positie) data.positie = u.overlay.positie;
    data.meetelVanaf = datum;
    data.heeftVorigeTeams = true;
    if (!mee.not) delete data.notitie;
    if (!mee.lp) data.leerpunten = [];
    data.gast = deleteField();                              // een definitief overgezette speler is nooit meer een gast
    data.gearchiveerd = deleteField(); data.naarTeam = deleteField();
    data.naarTeamNaam = deleteField(); data.gearchiveerdOp = deleteField();

    if (u.adopteertGast){
      /* Koppeling aan een gast: het ontvangende team heeft al een gast-document
         (met eigen id) waar alle opstellingen aan hangen. Wat de coach daar zelf
         bij de gast noteerde (leerpunten, notitie) wordt SAMENGEVOEGD met de
         gegevens van het bronteam; het document zelf blijft, dus id en
         opstellingen blijven intact. */
      const gSnap = await getDoc(naarRef);
      if (gSnap.exists()){
        const g = gSnap.data();
        const lp = [...(Array.isArray(data.leerpunten) ? data.leerpunten : [])];
        const ids = new Set(lp.map(l => l.id));
        for (const l of (Array.isArray(g.leerpunten) ? g.leerpunten : [])) if (!ids.has(l.id)) lp.push(l);
        data.leerpunten = lp;
        if (g.notitie && data.notitie && g.notitie !== data.notitie) data.notitie = `${data.notitie}\n\n${g.notitie}`;
        else if (g.notitie && !data.notitie) data.notitie = g.notitie;
      }
    }
    await setDoc(naarRef, data, { merge:true });

    // 3) origineel archiveren (NIET verwijderen) + leen-record opruimen
    await updateDoc(bronRef, { gearchiveerd:true, naarTeam:u.naarTeam, naarTeamNaam:u.naarTeamNaam || null, gearchiveerdOp:vandaagIso() });
    await deleteDoc(doc(db,'clubs',clubId,'uitleningen',u.id));

    telGebruik('uitlenen_definitief');
    S._vtBezig = null; if (S._vorigeTeams) delete S._vorigeTeams[`${u.naarTeam}/${naarId}`];
    meld(`${naam} nu definitief bij ${u.naarTeamNaam}`);
    if (S.teamId) herrenderTeam();
    return true;
  } catch(e){
    if (e.code === 'permission-denied'){
      meld('Overzetten mislukt: je hebt niet over beide teams (coach- of coördinatorrechten) genoeg toegang.');
    } else {
      meld('Overzetten mislukt: ' + (e.code||e.message));
    }
    return false;
  }
}

/* Clubadmin: het bevroren dossier opnieuw uit het (gearchiveerde) origineel
   berekenen, bijvoorbeeld na een correctie bij het oude team. Bewaart de
   keuzes (mee) en de uitleen-info van het oorspronkelijke dossier. */
export async function herberekenDossier(stintId){
  if (!isBeheerder()) return meld('Alleen de clubadmin kan een dossier herberekenen');
  const p = speler(S._beoordeelProfiel); if (!p) return;
  const sl = `${S.teamId}/${p.id}`;
  const s = ((S._vorigeTeams || {})[sl] || []).find(x => x.id === stintId);
  if (!s) return meld('Dossier niet gevonden');
  try {
    const bSnap = await getDoc(doc(db,'teams',s.teamId,'spelers',s.spelerId));
    if (!bSnap.exists()) return meld('Het origineel bij het oude team bestaat niet meer');
    const raw = await bouwOverdrachtDossier({ vanTeam:s.teamId, vanTeamNaam:s.teamNaam, spelerId:s.spelerId, speler:bSnap.data(), uitleen:null });
    raw.uitleen = s.uitleen || null;
    const nieuw = dossierDoc(raw, s.mee || { wed:true, beo:true, tr:true, lp:true, not:true }, s.tot);
    await setDoc(doc(db,'teams',S.teamId,'spelers',p.id,'vorigeTeams',stintId), nieuw, { merge:true });
    delete S._vorigeTeams[sl];
    meld('Dossier opnieuw berekend');
    herrenderTeam();
  } catch(e){
    meld('Herberekenen mislukt: ' + (e.code === 'permission-denied' ? 'geen toegang tot het oude team' : (e.code || e.message)));
  }
}


/* ===================== Gastspelers ===================== *
 * Een gast is een lokaal placeholder-spelerdocument in het EIGEN team
 * (teams/{teamId}/spelers met gast:true), bedoeld om alvast op te stellen
 * zolang nog niet bekend is wie precies wordt ingeleend. Zodra dat duidelijk
 * is, adopteert een inkomend leen-record het gast-id (zie modalKoppelGast):
 * de gast houdt zijn plek in alle opstellingen/presenties en toont voortaan
 * de echte naam en herkomst. Een gast hoort altijd bij een (komende) uitleen;
 * een proefspeler van buiten hoort als gewone speler in de selectie. */
export function modalGast(gastId){
  const g = gastId ? speler(gastId) : null;
  openModal(`
    <h2>${g ? 'Gast bewerken' : 'Gastspeler aanmaken'}</h2>
    <div class="avg-balk"><span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="8" r="3.2"/><path d="M5.5 20a6.5 6.5 0 0 1 13 0"/></svg></span>
      <span>Een gast is een tijdelijke placeholder om alvast op te stellen, zolang nog niet bekend is wie je precies inleent. Zodra dat duidelijk is, koppel je hem aan de echte uitleen.</span></div>
    <div class="rij">
      <div class="veldgroep" style="flex:3"><label>Label / omschrijving</label>
        <input class="invoer" id="mGNaam" value="${esc(g?.naam||'')}" placeholder="Bijv. Gast: links achter" autocomplete="off"></div>
      <div class="veldgroep u-flex-1"><label>Nr.</label>
        <input class="invoer" id="mGNr" value="${esc(g?.nummer ?? '')}" inputmode="numeric" placeholder="15"></div>
    </div>
    <button class="knop vol" id="mGOk">${g ? 'Opslaan' : 'Aanmaken'}</button>`);

  $('#mGOk').onclick = async () => {
    const naam = $('#mGNaam').value.trim() || 'Gastspeler';
    const nr = $('#mGNr').value.trim();
    const data = { naam, nummer: nr === '' ? null : Number(nr), gast: true };
    const knop = $('#mGOk'); knop.disabled = true; knop.textContent = 'Bezig…';
    try {
      if (g){ await updateDoc(doc(db,'teams',S.teamId,'spelers',g.id), { naam: data.naam, nummer: data.nummer }); }
      else  { await addDoc(collection(db,'teams',S.teamId,'spelers'), data); }
      telGebruik(g ? 'gast_bewerken' : 'gast_nieuw');
      sluitModal();
      meld(g ? 'Gast bijgewerkt' : `${naam} aangemaakt`);
    } catch(e){
      knop.disabled = false; knop.textContent = g ? 'Opslaan' : 'Aanmaken';
      meld('Opslaan mislukt: ' + (e.code||e.message));
    }
  };
  setTimeout(() => $('#mGNaam')?.focus(), 50);
}

export async function verwijderGast(gastId){
  const g = speler(gastId);
  if (!g) return;
  // Hangt er een uitlening aan (geadopteerd)? Dan is het geen losse gast meer.
  const gekoppeld = (S.uitleningenIn||[]).some(u => u.adopteertGast === gastId);
  if (gekoppeld) return meld('Deze gast is gekoppeld aan een uitleen, zet die eerst terug');
  if (!confirm(`${g.naam} verwijderen? De opstellingen en presenties waarin deze gast stond, verliezen hem.`)) return;
  try {
    await deleteDoc(doc(db,'teams',S.teamId,'spelers',gastId));
    telGebruik('gast_weg');
    S._beoordeelProfiel = null;
    herrenderTeam();
    meld('Gast verwijderd');
  } catch(e){
    meld('Verwijderen mislukt: ' + (e.code||e.message));
  }
}

/* Koppelen: een inkomend leen-record adopteert het gast-id. Eén schrijfactie
   op het leen-record — het gast-id blijft, dus alle bestaande opstellingen en
   presenties blijven intact. Alleen uitleningen die nog geen gast hebben
   geadopteerd zijn koppelbaar (één uitleen ↔ één speler). */
export function modalKoppelGast(gastId){
  const g = speler(gastId);
  if (!g) return;
  const clubId = S.team?.club;
  if (!clubId) return;
  const koppelbaar = (S.uitleningenIn||[]).filter(u => !u.adopteertGast);
  openModal(`
    <h2>Koppel aan ingeleende speler</h2>
    <div class="avg-balk"><span class="slot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="17.8" cy="6" r="2.6"/><circle cx="6.2" cy="12" r="2.6"/><circle cx="17.8" cy="18" r="2.6"/><path d="M15.4 7.2 8.6 10.8"/><path d="M8.6 13.2 15.4 16.8"/></svg></span>
      <span>Kies welke uitleen deze gast wordt. De gast houdt zijn plek in al je opstellingen en presenties, alleen de naam en herkomst komen erbij.</span></div>
    <div class="veldgroep"><label>Beschikbare uitleningen naar jouw team</label>
      <select class="invoer" id="mKgSel">
        ${koppelbaar.length
          ? koppelbaar.map(u => `<option value="${u.id}">${esc(u.snapshot?.naam || 'Speler')} — van ${esc(u.vanTeamNaam||'ander team')}</option>`).join('')
          : `<option value="">Nog geen uitleningen beschikbaar</option>`}
      </select></div>
    <button class="knop vol" id="mKgOk"${koppelbaar.length ? '' : ' disabled'}>Koppelen</button>`);

  $('#mKgOk').onclick = async () => {
    const leenId = $('#mKgSel').value;
    if (!leenId) return;
    const knop = $('#mKgOk'); knop.disabled = true; knop.textContent = 'Bezig…';
    try {
      await updateDoc(doc(db,'clubs',clubId,'uitleningen',leenId), { adopteertGast: gastId });
      telGebruik('gast_koppel');
      sluitModal();
      meld('Gast gekoppeld');
    } catch(e){
      knop.disabled = false; knop.textContent = 'Koppelen';
      meld('Koppelen mislukt: ' + (e.code||e.message));
    }
  };
}
