import {
  db, storage, collection, doc, addDoc, deleteDoc, updateDoc, deleteField, getDoc, setDoc, getDocs,
  query, where, onSnapshot, serverTimestamp, documentId, writeBatch,
  sRef, uploadBytes, getDownloadURL, deleteObject,
  functions, httpsCallable
} from './firebase.js?v=20261106h';
import {
  S, $, $$, esc, meld, nieuweCode, teamCode, clubAfkorting, openModal, sluitModal, toon, stopUnsubs, initialen, isBeheerder
} from './state.js?v=20261106h';
import { CATEGORIEEN, CATEGORIEEN_MEIDEN, catInfo, BOUWEN, bouwVanCategorie, bouwNaam, youtubeId, youtubeThumb, youtubeWatch, SEIZOEN_FALLBACK, GEBRUIK_CATEGORIEEN, gebruikEventLabel } from './config.js?v=20261106h';
import { teltMee } from './opkomst.js?v=20261106h';
import { analyseWedstrijd } from './analyse.js?v=20261106h';
import { htmlEigenBouwenBeheer, koppelEigenBouwenBeheer } from './eigen-bouwen.js?v=20261106h';
import { htmlDiagramHerstel, koppelDiagramHerstel } from './training-herstel.js?v=20261106h';
import { htmlBouwIndeling, koppelBouwIndeling, standaardBouwVoorStof, bouwGroepen } from './bouw-indeling.js?v=20261106h';
import { clubEvaluatiesOphalen, htmlClubEvaluaties, koppelClubEvaluaties } from './club-evaluaties.js?v=20261106h';
import { startClubContentListener, htmlClubContent, koppelClubContent } from './club-content.js?v=20261106h';
import { htmlInzichtTabs, htmlInzichtTab, openRapport } from './club-inzicht.js?v=20261106h';
import { telGebruik, telNav } from './tracker.js?v=20261106h';
import { ico } from './icons.js?v=20261106h';
import { htmlTraincoKaart, koppelTraincoKaart } from './trainco-beheer.js?v=20261106h';
import { htmlTeamsBeheer, koppelTeamsBeheer, htmlTeamBeheer, koppelTeamBeheer, htmlCoaches, koppelCoaches, aandachtRedenen, groepen as beheerGroepen } from './club-beheer.js?v=20261106h';
import { isBlokUpload, isZip, startBlokUpload, hervatBlokUpload, htmlPlannen, koppelPlannen, zichtbaarLabel } from './training-plan.js?v=20261106h';
import { initWachtrij, voegToeAanWachtrij, htmlUploadPaneel, htmlModelKeuze } from './upload-wachtrij.js?v=20261106h';
import { rondesVan, voortgangOphalen, htmlEvalRondes, htmlRondeDetail, htmlRondeFormulier, koppelRondeFormulier, koppelRondeDetail, startConcept } from './evaluatierondes.js?v=20261106h';

/* [20261013b] Uploadwachtrij: trainingen worden op de achtergrond verwerkt.
   De wachtrij leeft in upload-wachtrij.js; de schermen die hij nodig heeft
   (preview, alleen-PDF, navigatie, concept hervatten) wonen hier. */
initWachtrij({
  toonPreview: (file, meta, ctx) => toonPreview(file, meta, ctx),
  toonAlleenPdf: (file, meta, ctx, boodschap) => toonAlleenPdfKeuze(file, meta, ctx, boodschap),
  naarTrainingen: (clubId) => {
    if (!clubId) return;
    if (S.clubId === clubId && S.club){ S.clubTab = 'trainingen'; toon('club'); renderClub(); }
    else { openClub(clubId); S.clubTab = 'trainingen'; }
  },
  trainingenGewijzigd: () => { if (S.club && S.clubTab === 'trainingen') renderClub(); },
  hervatConcept: (job) => hervatBlokUpload(job, blokCtx(S.clubTeams || [], S.clubTrainingen || [])),
});

/* drempels voor het clubdashboard ("aandacht nodig") */
const DASH_DAGEN_INACTIEF = 14;
const DASH_OPKOMST_LAAG = 50;

/* categorieën voor het documenten-tabblad — bewust geen bouw-indeling zoals
   bij trainingen/video's: documenten (beleid, formulieren) zijn doorgaans
   niet leeftijdsgebonden maar wel van verschillend type. */
const DOC_CATEGORIEN = [
  {id:'knvb',       naam:'KNVB'},
  {id:'beleid',     naam:'Beleid'},
  {id:'overig',     naam:'Overig'},
];

/* openTeam en modalNieuwTeam komen uit teams.js; om kringverwijzing te
   vermijden importeren we ze lui binnen de functies die ze nodig hebben. */
async function teamsModule(){ return await import('./teams.js?v=20261106h'); }

/* ==================== CLUB AANMAKEN ==================== */
export function modalNieuwClub(){
  openModal(`
    <h2><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3 20 6.5V11c0 4.5-3.1 8.7-8 10-4.9-1.3-8-5.5-8-10V6.5z"/><circle cx="12" cy="10.4" r="2.1"/><path d="M8.8 16.2a3.6 3.6 0 0 1 6.4 0"/></svg> Nieuwe club</h2>
    <p class="u-t-sm u-zacht u-mb-sm">Als club-admin maak jij teams aan en deel je trainingen voor alle teams. Coaches nodig je uit met een persoonlijke teamlink.</p>
    <div class="veldgroep"><label>Clubnaam</label>
      <input class="invoer" id="mClubNaam" placeholder="Bijv. RKVV Mifano" autocomplete="off"></div>
    <button class="knop vol" id="mClubOk">Club aanmaken</button>`);
  $('#mClubOk').onclick = async () => {
    const naam = $('#mClubNaam').value.trim();
    if (!naam) return meld('Vul een clubnaam in');
    const ref = await addDoc(collection(db,'clubs'), {
      naam, code: nieuweCode(),
      admins: {[S.user.uid]: true},
      adminsInfo: {[S.user.uid]: {naam: S.user.displayName || S.user.email}},
      leden: {[S.user.uid]: true},
      teams: {},
      gemaakt: serverTimestamp(),
    });
    sluitModal(); openClub(ref.id);
  };
}

export function openClub(clubId){
  S.clubId = clubId; S.clubTab = 'hub'; S.teamId = null;
  /* [20260929a] runtime-velden van het clubbeheer (bewust niet in state.js) */
  S.clubAfgelastingen = null; S._clubSyncStatus = null; S._cbFilter = 'alle'; S._cbWeergave = 'overzicht';
  S._cbTeam = null; S._cbUitnodig = null; S._cbZoek = ''; S._clubInstelTab = 'algemeen'; S._clubRonde = null;
  stopUnsubs('club');
  S.unsub.club = onSnapshot(doc(db,'clubs',clubId), snap => {
    if (!snap.exists()){ verlaatClubView(); return; }
    S.club = {id:snap.id, ...snap.data()};
    renderClub();
  }, (err) => {
    console.error(`[Cluppie] Listener "club" kon niet lezen (clubId=${clubId}):`, err.code, err.message);
    if (err.code === 'permission-denied') meld('Geen toegang tot deze club, controleer de Firestore-rules');
  });
  toon('club');
  telNav('club:hub', 'open');
}

export function verlaatClubView(){
  stopUnsubs('club', 'clubContent');
  S.clubId = null; S.club = null;
  import('./teams.js?v=20261106h').then(m => { m.renderTeams(); toon('teams'); });
}

async function clubTeamsOphalen(){
  const ids = Object.keys(S.club.teams || {});
  if (!ids.length) return [];
  const result = [];
  for (let i = 0; i < ids.length; i += 30){
    const chunk = ids.slice(i, i+30);
    const snap = await getDocs(query(collection(db,'teams'), where(documentId(), 'in', chunk)));
    snap.docs.forEach(d => result.push({id:d.id, ...d.data()}));
  }
  return result.sort((a,b) => (a.naam||'').localeCompare(b.naam||''));
}

async function clubTrainingenOphalen(){
  const snap = await getDocs(query(collection(db,'trainingen'), where('club','==',S.clubId)));
  return snap.docs.map(d => ({id:d.id, ...d.data()}))
    .sort((a,b) => (b.week||'').localeCompare(a.week||'') || (b.gemaakt?.seconds||0) - (a.gemaakt?.seconds||0));
}

async function clubVideosOphalen(){
  const snap = await getDocs(query(collection(db,'videos'), where('club','==',S.clubId)));
  return snap.docs.map(d => ({id:d.id, ...d.data()}))
    .sort((a,b) => (b.gemaakt?.seconds||0) - (a.gemaakt?.seconds||0));
}

async function clubDocumentenOphalen(){
  const snap = await getDocs(query(collection(db,'documenten'), where('club','==',S.clubId)));
  return snap.docs.map(d => ({id:d.id, ...d.data()}))
    .sort((a,b) => (b.gemaakt?.seconds||0) - (a.gemaakt?.seconds||0));
}

/* berichten van de club (admin-weergave), nieuw → oud */
async function clubBerichtenOphalen(){
  const snap = await getDocs(query(collection(db,'berichten'), where('club','==',S.clubId)));
  return snap.docs.map(d => ({id:d.id, ...d.data()}))
    .sort((a,b) => (b.gemaakt?.seconds||0) - (a.gemaakt?.seconds||0));
}

/* afgelast-historie: centrale lijst onder clubs/{clubId}/afgelastingen (nieuw → oud) */
async function clubAfgelastingenOphalen(){
  const snap = await getDocs(collection(db,'clubs',S.clubId,'afgelastingen'));
  return snap.docs.map(d => ({id:d.id, ...d.data()}))
    .sort((a,b) => (b.datum||'').localeCompare(a.datum||''));
}

/* Sportlink-syncstatus per team uit clubs/{clubId}/geheim/{teamId}.
   Het geheim-doc is sinds de Club.Dataservice-koppeling puur een status/cache-
   store (geen tokens meer): we lezen of het team bij de laatste sync op naam
   gematcht is, plus de statusvelden. */
async function clubSyncStatusOphalen(teams){
  const status = {};
  await Promise.all(teams.map(async t => {
    try {
      const snap = await getDoc(doc(db,'clubs',S.clubId,'geheim',t.id));
      if (snap.exists()){
        const d = snap.data();
        status[t.id] = {
          gematcht: !!d.gematcht,
          laatsteSync: d.laatsteSync || null,
          laatsteAantal: d.laatsteAantal ?? null,
          laatsteFout: d.laatsteFout || null,
        };
      } else {
        status[t.id] = { gematcht: false };
      }
    } catch(e){
      status[t.id] = { gematcht: false };
    }
  }));
  return status;
}

/* 'YYYY-MM-DD' -> 'do 25 jun' (kort, voor de statslijst) */
function afgKort(datum){
  try { return new Date(datum+'T12:00').toLocaleDateString('nl-NL',{weekday:'short',day:'numeric',month:'short'}); }
  catch { return datum; }
}

/* ==================== CLUBDASHBOARD ====================
   Eén leesactie per team voor spelers/wedstrijden/presentie — alleen
   uitgevoerd als het dashboard-tabblad ook echt open staat (zie renderClub),
   net als de voetbal.nl-syncstatus die ook alleen op de instel-tab leest. */
function dagenSinds(datum){
  try { return Math.floor((Date.now() - new Date(datum+'T12:00').getTime()) / 86400000); }
  catch { return null; }
}
function dashActiviteitTekst(dagen){
  if (dagen === 0) return 'Vandaag';
  if (dagen === 1) return 'Gisteren';
  return `${dagen} dagen geleden`;
}
function dashOpkomstKlasse(p){ return p>=80?'goed':p>=DASH_OPKOMST_LAAG?'matig':'laag'; }

async function clubDashboardOphalen(teams){
  // Alleen het huidige seizoen — anders groeit deze leesactie elk seizoen mee
  // met de volledige clubhistorie, ook al gaat het dashboard over "nu".
  // Spelers blijven ongefilterd (geen seizoen-veld, en de huidige selectie
  // is altijd relevant).
  const seizoenFilter = S.huidigSeizoen ? [where('seizoen','==',S.huidigSeizoen)] : [];
  return Promise.all(teams.map(async t => {
    const [spelersSnap, wedstrijdenSnap, presentieSnap] = await Promise.all([
      getDocs(collection(db,'teams',t.id,'spelers')),
      getDocs(query(collection(db,'teams',t.id,'wedstrijden'), ...seizoenFilter)),
      getDocs(query(collection(db,'teams',t.id,'presentie'), ...seizoenFilter)),
    ]);
    const spelersDocs = spelersSnap.docs.map(d => ({id:d.id, ...d.data()})).filter(p => !p.gearchiveerd);
    const spelersAantal = spelersDocs.length;
    const wedstrijden = wedstrijdenSnap.docs.map(d => d.data());
    const presentie = presentieSnap.docs.map(d => d.data());

    // Opkomst per speler-per-sessie optellen in plaats van
    // spelersAantal × sessies: een speler die later instroomde telde anders
    // als aanwezig bij trainingen waar hij nog niet bij het team was, wat het
    // clubgemiddelde omhoog trok. Zie js/opkomst.js.
    let opkomstPct = null;
    if (presentie.length && spelersAantal){
      let totAanwezig = 0, totMogelijk = 0;
      for (const ses of presentie){
        for (const sp of spelersDocs){
          if (!teltMee(ses, sp)) continue;
          totMogelijk++;
          if (!(ses.afwezig||[]).includes(sp.id)) totAanwezig++;
        }
      }
      opkomstPct = totMogelijk ? Math.round((totAanwezig / totMogelijk) * 100) : null;
    }

    const activiteiten = [];
    for (const w of wedstrijden){
      if (!w.datum) continue;
      const heeftUitslag = (w.goals||[]).length || analyseWedstrijd(w).kwarten;
      if (!heeftUitslag) continue;
      const voor = (w.goals||[]).filter(g => g.type==='voor').length;
      const tegen = (w.goals||[]).filter(g => g.type==='tegen').length;
      const ww = voor > tegen ? `won met ${voor}-${tegen} van` : voor < tegen ? `verloor met ${voor}-${tegen} van` : `speelde ${voor}-${tegen} gelijk tegen`;
      activiteiten.push({
        soort:'wedstrijd', datum:w.datum,
        tekst: `${ww} ${w.tegenstander||'onbekend'}`,
      });
    }
    for (const p of presentie){
      if (!p.datum) continue;
      const aanwezig = spelersAantal - (p.afwezig||[]).length;
      activiteiten.push({ soort:'presentie', datum:p.datum, tekst:`presentie: ${aanwezig}/${spelersAantal} aanwezig` });
    }
    const laatsteDatum = activiteiten.length ? activiteiten.map(a => a.datum).sort().at(-1) : null;

    return {
      team:t, spelersAantal, coachesAantal: Object.keys(t.leden||{}).length,
      wedstrijdenAantal: wedstrijden.length, opkomstPct, laatsteDatum, activiteiten,
      heeftCategorie: !!t.categorie,
    };
  }));
}

/* Bereken de aandacht-signalen (gedeeld door de Aandacht-badge én -scherm). */
function clubSignalen(dash){
  const signalen = [];
  for (const d of dash){
    const dagen = d.laatsteDatum ? dagenSinds(d.laatsteDatum) : null;
    if (dagen === null || dagen > DASH_DAGEN_INACTIEF){
      signalen.push({ team:d.team.naam, ernstig:true,
        reden: dagen === null ? 'Nog geen presentie of wedstrijd geregistreerd' : `Geen presentie of wedstrijd sinds ${dagen} dagen` });
    }
    if (!d.heeftCategorie){
      signalen.push({ team:d.team.naam, ernstig:false, reden:'Geen categorie ingesteld: speeltijden kloppen mogelijk niet' });
    }
    if (d.opkomstPct != null && d.opkomstPct < DASH_OPKOMST_LAAG){
      signalen.push({ team:d.team.naam, ernstig:false, reden:`Trainingsopkomst ${d.opkomstPct}%: laag` });
    }
  }
  signalen.sort((a,b) => (b.ernstig?1:0) - (a.ernstig?1:0));
  return signalen;
}

/* Dashboard-scherm 1: Overzicht — KPI-blokjes, teams-tabel, recente activiteit. */
function htmlDashOverzicht(teams, dash){
  if (!teams.length) return `<div class="kaart leeg">Nog geen teams in deze club.<br>Zodra er teams, wedstrijden en trainingen zijn, verschijnt hier een overzicht.</div>`;

  const totSpelers = dash.reduce((s,d) => s + d.spelersAantal, 0);
  const totCoaches = dash.reduce((s,d) => s + d.coachesAantal, 0);
  const wedstrijdenWeek = dash.reduce((s,d) => s + d.activiteiten.filter(a => a.soort==='wedstrijd' && dagenSinds(a.datum) <= 7).length, 0);

  const sortDesc = (S.clubDashSort ?? 'desc') === 'desc';
  const gesorteerd = dash.map(d => ({...d, dagen: d.laatsteDatum ? dagenSinds(d.laatsteDatum) : Infinity}))
    .sort((a,b) => sortDesc ? b.dagen - a.dagen : a.dagen - b.dagen);

  const feed = dash.flatMap(d => d.activiteiten.map(a => ({...a, team:d.team.naam})))
    .sort((a,b) => b.datum.localeCompare(a.datum)).slice(0,8);

  return `
    <div class="overzicht-blokjes">
      <div class="ov-blok"><div class="ov-getal">${teams.length}</div><div class="ov-label">teams</div></div>
      <div class="ov-blok"><div class="ov-getal">${totSpelers}</div><div class="ov-label">spelers</div></div>
      <div class="ov-blok"><div class="ov-getal">${totCoaches}</div><div class="ov-label">coaches</div></div>
      <div class="ov-blok ov-wedstrijden"><div class="ov-getal">${wedstrijdenWeek}</div><div class="ov-label">wedstr. 7 dgn</div></div>
    </div>

    <div class="kaart">
      <div class="sectie-kop u-mt-0">
        Teams
        <button class="actie u-ml-auto u-t-2xs u-fw-7 u-zacht" id="dashSort" style="text-transform:uppercase;letter-spacing:.3px">Activiteit ${sortDesc?'↓':'↑'}</button>
      </div>
      <table class="stat-tabel">
        <thead><tr><th>Team</th><th>Activiteit</th><th>Opkomst</th><th>Spelers</th></tr></thead>
        <tbody>${gesorteerd.map(d => `
          <tr data-dash-team="${d.team.id}" style="cursor:pointer">
            <td class="naam-cel">${esc(d.team.naam)}</td>
            <td style="${d.dagen !== Infinity && d.dagen > DASH_DAGEN_INACTIEF ? 'color:var(--uit)' : ''}">${d.laatsteDatum ? dashActiviteitTekst(d.dagen) : '—'}</td>
            <td class="opkomst-cel ${d.opkomstPct==null?'':dashOpkomstKlasse(d.opkomstPct)}">${d.opkomstPct==null?'—':d.opkomstPct+'%'}</td>
            <td>${d.spelersAantal}</td>
          </tr>`).join('')}</tbody>
      </table>
    </div>

    <div class="kaart">
      <div class="sectie-kop u-mt-0">Recente activiteit</div>
      ${feed.length ? feed.map(a => `
        <div class="training-rij">
          <div class="ico">${a.soort==='wedstrijd'?'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg>':'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="5" y="4.5" width="14" height="16" rx="2.2"/><path d="M9 3.2h6v3H9z"/><path d="M8.8 11.4h6.4"/><path d="M8.8 15.4h4"/></svg>'}</div>
          <div class="t"><div class="t-titel">${esc(a.team)}</div>
            <div class="t-meta">${esc(a.tekst)}<span class="sep" aria-hidden="true"></span>${esc(afgKort(a.datum))}</div></div>
        </div>`).join('') : `<p class="u-t-sm u-zacht">Nog geen wedstrijden of presentie geregistreerd.</p>`}
    </div>`;
}

/* Dashboard-scherm 2: Aandacht — de signalen als lijst. */
function htmlDashAandacht(dash){
  const signalen = clubSignalen(dash);
  return `
    <div class="kaart">
      ${signalen.length ? `
        <div class="caf-historie">
          ${signalen.map(s => `
            <div class="caf-rij">
              <span class="caf-rij-datum" style="${s.ernstig?'color:var(--uit)':''}">${esc(s.team)}</span>
              <span class="caf-rij-reden">${esc(s.reden)}</span>
            </div>`).join('')}
        </div>` : `<p class="u-t-sm u-zacht"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4.6 12.4 9.6 17.4 19.6 6.6"/></svg> Alle teams zijn actief en up-to-date.</p>`}
    </div>`;
}

/* Dashboard-scherm 3: Gebruik — logins + functiegebruik. */
function htmlDashGebruik(gebruik){
  return htmlClubGebruik(gebruik) + htmlClubFunctiegebruik(gebruik);
}

/* ==================== GEBRUIKSSTATISTIEKEN (logins) ====================
   Wie hoort bij deze club? Coaches van alle teams + club-admins. Alleen
   logins van die uid's tellen mee, zodat het overzicht per club klopt. */
function clubRelevanteUids(teams){
  const set = new Set(Object.keys(S.club.admins || {}));
  for (const t of teams) for (const uid of Object.keys(t.leden||{})) set.add(uid);
  return set;
}

/* logins van de laatste ~26 weken in één keer ophalen (dekt dag/week/maand-
   weergave zonder opnieuw te hoeven lezen bij het wisselen van periode),
   plus de gebruikers-samenvatting (naam, laatste login, totaal aantal). */

/* Leest het vooraf-geaggregeerde statistiekdocument dat de Cloud Function
   aggregeerGebruik heeft weggeschreven. Eén read i.p.v. de hele navpaden-
   collectie: snel en goedkoop, ook als navpaden over het seizoen groeit.
   Geeft null terug als er nog nooit gesynchroniseerd is. */
async function gebruikstatsOphalen(clubId){
  if (!clubId) return null;
  try {
    const snap = await getDoc(doc(db, 'gebruikstats', clubId));
    return snap.exists() ? snap.data() : null;
  } catch (e){
    return null;
  }
}

async function clubGebruikOphalen(teams){
  const relevantUids = clubRelevanteUids(teams);
  if (!relevantUids.size) return { logins:[], gebruikers:[] };

  const vanaf = new Date(Date.now() - 185*24*3600*1000).toISOString().slice(0,10);
  const loginsSnap = await getDocs(query(collection(db,'logins'), where('datum','>=',vanaf)));
  const logins = loginsSnap.docs.map(d => d.data()).filter(l => relevantUids.has(l.uid));

  const ids = [...relevantUids];
  const gebruikers = [];
  for (let i = 0; i < ids.length; i += 30){
    const chunk = ids.slice(i, i+30);
    const snap = await getDocs(query(collection(db,'gebruikers'), where(documentId(), 'in', chunk)));
    snap.docs.forEach(d => gebruikers.push({id:d.id, ...d.data()}));
  }
  gebruikers.sort((a,b) => (b.aantalLogins||0) - (a.aantalLogins||0));

  // Functiegebruik: documenten gebruik/{uid}_{datum} met per-event tellingen,
  // over hetzelfde venster. Op datum gefilterd, daarna op relevante uid.
  const gebruikSnap = await getDocs(query(collection(db,'gebruik'), where('datum','>=',vanaf)));
  const gebruikDocs = gebruikSnap.docs.map(d => d.data()).filter(g => relevantUids.has(g.uid));
  const naamPerUid = {};
  gebruikers.forEach(g => { naamPerUid[g.id] = g.naam || g.email || 'Onbekend'; });

  // Navigatiepaden: documenten navpaden/{uid}_{sessieId} met geordende stappen.
  // Zelfde datum-venster; daarna op relevante uid. Faalt zacht — een dashboard
  // zonder navpad-data toont gewoon een lege staat i.p.v. te breken.
  let navpaden = [];
  try {
    const navSnap = await getDocs(query(collection(db,'navpaden'), where('datum','>=',vanaf)));
    navpaden = navSnap.docs.map(d => d.data()).filter(n => relevantUids.has(n.uid));
  } catch(e){ console.warn('[club] navpaden ophalen mislukt:', e?.code || e?.message); }

  return { logins, gebruikers, gebruikDocs, naamPerUid, navpaden };
}

/* Groepeer de functiegebruik-documenten per periode (dag/week/maand), en bereken
   per event het clubtotaal + de uitsplitsing per gebruiker. Alleen documenten
   binnen de gekozen periode tellen mee. */
function gebruikAggregeer(gebruikDocs, naamPerUid, periode){
  const nu = new Date();
  let vanafDatum;
  if (periode === 'dag') vanafDatum = new Date(nu.getTime() - 1*86400000);
  else if (periode === 'week') vanafDatum = new Date(nu.getTime() - 7*86400000);
  else vanafDatum = new Date(nu.getFullYear(), nu.getMonth()-1, nu.getDate());
  const grens = vanafDatum.toISOString().slice(0,10);

  const perEvent = {};       // ev -> totaal
  const perEventGebr = {};   // ev -> {uid: n}
  for (const g of gebruikDocs){
    if (!g.datum || g.datum < grens) continue;
    const t = g.tellingen || {};
    for (const [ev, n] of Object.entries(t)){
      if (typeof n !== 'number') continue;
      perEvent[ev] = (perEvent[ev]||0) + n;
      (perEventGebr[ev] ||= {});
      perEventGebr[ev][g.uid] = (perEventGebr[ev][g.uid]||0) + n;
    }
  }
  return { perEvent, perEventGebr };
}

function htmlClubFunctiegebruik(gebruik){
  const periode = S.clubGebruikPeriode || 'week';
  const { perEvent, perEventGebr } = gebruikAggregeer(gebruik.gebruikDocs || [], gebruik.naamPerUid || {}, periode);
  const totaalAlles = Object.values(perEvent).reduce((a,b)=>a+b, 0);

  const catBlok = (cat) => {
    // events van deze categorie met een telling > 0, aflopend
    const rijen = cat.events
      .map(e => ({ev:e.ev, label:e.label, n:perEvent[e.ev]||0}))
      .filter(r => r.n > 0)
      .sort((a,b) => b.n - a.n);
    if (!rijen.length) return '';
    const catTot = rijen.reduce((a,r)=>a+r.n, 0);
    const maxN = Math.max(1, ...rijen.map(r => r.n));
    const LIMIET = 5;
    const zichtbaar = rijen.slice(0, LIMIET);
    const rest = rijen.length - zichtbaar.length;

    const funcRij = (r) => {
      const gebr = Object.entries(perEventGebr[r.ev] || {})
        .map(([uid,n]) => ({naam: gebruik.naamPerUid?.[uid] || 'Onbekend', n}))
        .sort((a,b) => b.n - a.n);
      return `
      <div class="gebruik-func" data-func="${esc(r.ev)}">
        <div class="gebruik-func-rij">
          <span class="fnaam">${esc(r.label)}</span>
          <span class="fbar"><span style="width:${Math.round((r.n/maxN)*100)}%"></span></span>
          <span class="fn">${r.n}</span>
          ${gebr.length ? `<span class="fwie" data-gebruik-wie="${esc(r.ev)}">wie</span>` : ''}
        </div>
        <div class="gebruik-func-split">
          ${gebr.map(g => `
            <div class="gebruik-gebr-rij">
              <span class="gav">${esc(initialen(g.naam))}</span>
              <span class="gnaam">${esc(g.naam)}</span>
              <span class="gn">${g.n}</span>
            </div>`).join('')}
        </div>
      </div>`;
    };

    return `
      <div class="gebruik-cat">
        <div class="gebruik-cat-kop" data-gebruik-cat="${esc(cat.id)}">
          <span class="cnaam">${esc(cat.naam)}</span>
          <span class="ctot">${catTot}</span>
          <span class="cpijl">›</span>
        </div>
        <div class="gebruik-cat-inhoud">
          ${zichtbaar.map(funcRij).join('')}
          ${rest > 0 ? `<button class="gebruik-toon-alles" data-gebruik-meer="${esc(cat.id)}">+ Toon alle ${rijen.length} functies</button>
          <div class="gebruik-cat-rest" style="display:none">${rijen.slice(LIMIET).map(funcRij).join('')}</div>` : ''}
        </div>
      </div>`;
  };

  const blokken = GEBRUIK_CATEGORIEEN.map(catBlok).filter(Boolean).join('');

  return `
    <div class="kaart">
      <div class="sectie-kop u-mt-0">Functiegebruik</div>
      <div class="segment u-mb-md" id="gebruikFunctiePeriode" >
        ${[['dag','Dag'],['week','Week'],['maand','Maand']].map(([id,naam]) =>
          `<button data-functieperiode="${id}" class="${periode===id?'actief':''}">${naam}</button>`).join('')}
      </div>
      ${totaalAlles ? blokken : `<p class="u-t-sm u-zacht">Nog geen functiegebruik geregistreerd in deze periode.</p>`}
      <p class="u-t-2xs u-zacht u-mt-xs u-lh-ruim">Alle functies worden geteld; per categorie staan de drukste bovenaan. Tik een categorie open, of "wie" voor de uitsplitsing per coach. Alleen tellingen: geen speler- of persoonsgegevens.</p>
    </div>`;
}

/* ==================== NAVIGATIE-INZICHT (klikgedrag) ====================
   Aggregeert de navpaden/{uid}_{sid}-documenten tot drie weergaves:
   1. Top-routes    — vaakst voorkomende schermvolgordes per sessie
   2. Overgangsmatrix — van elk scherm: waar men daarna heen ging (+ terug-kolom)
   3. Uitstappunten  — vanaf welk scherm men de sessie beëindigde
   Werkt uitsluitend op schermnaam + aanleiding — geen persoonsdata. */

/* Leesbare labels voor de fijnmazige schermnamen. */
const NAV_LABELS = {
  'teams':'Teams', 'team:hub':'Team, hub', 'team:spelers':'Spelers',
  'team:trainingen':'Trainingen', 'team:presentietraining':'Presentie',
  'team:planning':'Planning', 'team:poule':'Poule', 'team:stats':'Stats',
  'team:instellingen':'Instellingen', 'spelerprofiel':'Spelerprofiel',
  'wedstrijd:opstelling':'Wedstrijd, opstelling',
  'club:teams':'Club, teams', 'club:content':'Club, content',
};
function navLabel(s){
  if (NAV_LABELS[s]) return NAV_LABELS[s];
  if (/^wedstrijd:kwart/.test(s)) return 'Wedstrijd, ' + s.replace('wedstrijd:','');
  return s;
}
/* Grove groep voor kleurcodering (teams/team/wedstrijd/club/overig). */
function navGroep(s){
  if (s === 'teams') return 'teams';
  if (s.startsWith('team:')) return 'team';
  if (s.startsWith('wedstrijd:')) return 'wedstrijd';
  if (s.startsWith('club:')) return 'club';
  return 'overig';
}

/* Kernaggregatie: loop één keer door alle sessies en bouw tegelijk de
   route-tellingen, de overgangsmatrix (incl. terug) en de uitstap-tellingen. */
function navAggregeer(navpaden){
  const routes = new Map();        // pad-signatuur → {aantal, stappen}
  const matrix = new Map();        // van → Map(naar → n), plus van → {_terug, _sluit}
  const bezoek = new Map();        // scherm → hoe vaak bezocht
  const exit   = new Map();        // scherm → hoe vaak laatste stap van sessie
  const exitMidden = new Map();    // scherm → aantal keer dat exit "middenin" was (na vooruit, niet na taak-af)
  let sessies = 0, totStappen = 0, terugStappen = 0;

  for (const doc of navpaden){
    const stappen = Array.isArray(doc.stappen) ? doc.stappen : [];
    if (!stappen.length) continue;
    sessies++;
    totStappen += stappen.length;

    // route-signatuur: alleen de schermnamen (compact, max 6 voor leesbaarheid)
    const namen = stappen.map(s => s.s);
    const sig = namen.slice(0, 8).join(' → ');
    const r = routes.get(sig) || { aantal:0, stappen: namen.slice(0,8) };
    r.aantal++; routes.set(sig, r);

    for (let i = 0; i < stappen.length; i++){
      const st = stappen[i];
      bezoek.set(st.s, (bezoek.get(st.s)||0) + 1);
      if (st.h === 'terug') terugStappen++;

      if (i < stappen.length - 1){
        const van = st.s, naar = stappen[i+1].s, hoe = stappen[i+1].h;
        const rij = matrix.get(van) || new Map();
        if (hoe === 'terug'){ rij.set('_terug', (rij.get('_terug')||0) + 1); }
        else { rij.set(naar, (rij.get(naar)||0) + 1); }
        matrix.set(van, rij);
      } else {
        // laatste stap = uitstappunt
        exit.set(st.s, (exit.get(st.s)||0) + 1);
        // "middenin" = de sessie eindigde direct na een vooruit-stap die geen
        // natuurlijk eindpunt is (ruwe heuristiek: eindigde op een profiel- of
        // bewerk-scherm i.p.v. op een overzicht/kwart).
        const rij2 = matrix.get(st.s);
        // exit telt als 'sluit' in de matrix-rij van dat scherm
        const rijS = matrix.get(st.s) || new Map();
        rijS.set('_sluit', (rijS.get('_sluit')||0) + 1);
        matrix.set(st.s, rijS);
      }
    }
  }

  // routes aflopend op aantal
  const topRoutes = [...routes.entries()]
    .map(([sig, r]) => ({sig, ...r}))
    .sort((a,b) => b.aantal - a.aantal)
    .slice(0, 6);

  return { sessies, totStappen, terugStappen, topRoutes, matrix, bezoek, exit };
}

function htmlClubNavigatie(gebruik){
  const navpaden = gebruik.navpaden || [];
  const A = navAggregeer(navpaden);
  const modus = S.clubNavModus || 'routes';

  if (!A.sessies){
    return `
      <div class="kaart">
        <div class="sectie-kop u-mt-0">Navigatie-inzicht</div>
        <p class="u-t-sm u-zacht">Nog geen navigatiedata verzameld. Zodra coaches door de app bewegen, verschijnen hier de meest gelopen routes, de overgangen tussen schermen en de uitstappunten.</p>
      </div>`;
  }

  const gemStappen = A.sessies ? (A.totStappen / A.sessies) : 0;
  const terugPct = A.totStappen ? Math.round((A.terugStappen / A.totStappen) * 100) : 0;

  // --- kpi-rijtje ---
  const kpis = `
    <div class="nav-kpis">
      <div class="nav-kpi"><div class="n">${A.sessies}</div><div class="l">sessies</div></div>
      <div class="nav-kpi"><div class="n">${gemStappen.toFixed(1)}</div><div class="l">schermen/sessie</div></div>
      <div class="nav-kpi"><div class="n" style="color:${terugPct>=25?'var(--keeper)':'var(--ink)'}">${terugPct}%</div><div class="l">"moest terug"</div></div>
    </div>`;

  const segment = `
    <div class="segment u-mb-md" id="clubNavModus" >
      ${[['routes','Top-routes'],['matrix','Overgangen'],['exit','Uitstappunten']].map(([id,naam]) =>
        `<button data-navmodus="${id}" class="${modus===id?'actief':''}">${naam}</button>`).join('')}
    </div>`;

  let inhoud = '';

  if (modus === 'routes'){
    const maxAantal = Math.max(1, ...A.topRoutes.map(r => r.aantal));
    inhoud = A.topRoutes.map((r, idx) => {
      const nodes = r.stappen.map((s,i) => {
        const g = navGroep(s);
        return `${i>0?'<span class="nav-pijl">→</span>':''}<span class="nav-node ${g}">${esc(navLabel(s))}</span>`;
      }).join('');
      const pct = Math.round((r.aantal / A.sessies) * 100);
      return `
        <div class="nav-route">
          <div class="nav-route-kop">
            <span class="nav-route-rang ${idx===0?'top':''}">${idx+1}</span>
            <span class="nav-route-stat">${pct}%<span class="sep" aria-hidden="true"></span>${r.aantal}×</span>
          </div>
          <div class="nav-flow">${nodes}</div>
          <div class="nav-balk"><i style="width:${Math.round((r.aantal/maxAantal)*100)}%"></i></div>
        </div>`;
    }).join('');
    inhoud += `<p class="nav-duiding">Elke rij is een veelvoorkomende schermvolgorde binnen één sessie. Percentage = aandeel van alle sessies dat zo begon.</p>`;
  }

  else if (modus === 'matrix'){
    // kolommen: de drukst bezochte schermen (max 6) + terug + sluit
    const drukste = [...A.bezoek.entries()].sort((a,b)=>b[1]-a[1]).slice(0,6).map(([s])=>s);
    const rijen = drukste;   // symmetrisch: rijen = kolommen (de drukste schermen)
    const kleurCel = (v, max) => {
      if (!v) return 'background:var(--surface-2);color:var(--ink-2)';
      const t = v/max;
      const bg = t<.2?'#3a1a1c':t<.4?'#6e2225':t<.6?'#a82c30':'var(--accent)';
      return `background:${bg};color:${t>=.4?'#fff':'#e6b0b2'}`;
    };
    // maxima per context voor kleurschaal
    let maxVooruit = 1, maxTerug = 1;
    for (const van of rijen){
      const rij = A.matrix.get(van); if (!rij) continue;
      for (const naar of drukste) if (naar!==van) maxVooruit = Math.max(maxVooruit, rij.get(naar)||0);
      maxTerug = Math.max(maxTerug, rij.get('_terug')||0);
    }
    const kop = `<tr><th class="nav-hoek">van ↓ / naar →</th>${drukste.map(s=>`<th>${esc(navLabel(s))}</th>`).join('')}<th style="color:var(--keeper)">↩ terug</th><th>⨯ sluit</th></tr>`;
    const body = rijen.map(van => {
      const rij = A.matrix.get(van) || new Map();
      const totVan = [...rij.values()].reduce((a,b)=>a+b,0) || 1;
      const cellen = drukste.map(naar => {
        if (naar === van) return `<td><div class="nav-cel u-zacht" style="background:var(--surface-2)">—</div></td>`;
        const v = rij.get(naar)||0; const pct = Math.round((v/totVan)*100);
        return `<td><div class="nav-cel" style="${kleurCel(v,maxVooruit)}">${v?pct+'%':'·'}</div></td>`;
      }).join('');
      const vT = rij.get('_terug')||0, pctT = Math.round((vT/totVan)*100);
      const tT = vT? (vT/maxTerug):0;
      const bgT = !vT?'background:var(--surface-2);color:var(--ink-2)':`background:${tT<.34?'#4a3a1a':tT<.67?'#8a6420':'var(--keeper)'};color:${tT>=.34?'#1a1200':'#e0c07d'}`;
      const vS = rij.get('_sluit')||0, pctS = Math.round((vS/totVan)*100);
      return `<tr><th>${esc(navLabel(van))}</th>${cellen}<td><div class="nav-cel" style="${bgT}">${vT?pctT+'%':'·'}</div></td><td><div class="nav-cel u-zacht" style="font-style:italic">${vS?pctS+'%':'·'}</div></td></tr>`;
    }).join('');
    inhoud = `<div class="nav-matrix-scroll"><table class="nav-matrix">${kop}${body}</table></div>
      <p class="nav-duiding">Lees per rij: vanaf dat scherm, waar ging men daarna heen. De gele <b style="color:var(--keeper)">↩ terug</b>-kolom toont het aandeel dat via de terugknop ging, daar kún je nergens rechtstreeks heen. Rood = veel vooruit-verkeer.</p>`;
  }

  else { // exit
    const totExit = [...A.exit.values()].reduce((a,b)=>a+b,0) || 1;
    const rijen = [...A.exit.entries()]
      .map(([s,n]) => ({s, n, bezoek: A.bezoek.get(s)||n}))
      .map(r => ({...r, pct: Math.round((r.n / r.bezoek) * 100)}))
      .sort((a,b) => b.n - a.n)
      .slice(0, 8);
    const maxN = Math.max(1, ...rijen.map(r => r.n));
    inhoud = rijen.map(r => {
      // natuurlijke eindpunten (taak af) vs. mogelijke knelpunten
      const natuurlijk = /kwart|poule|stats|opstelling/.test(r.s);
      const knelpunt = /spelerprofiel|bewerk/.test(r.s);
      const vlag = knelpunt ? '<span class="nav-vlag hoog">mogelijk knelpunt</span>'
                 : natuurlijk ? '<span class="nav-vlag norm">verwacht einde</span>'
                 : '';
      return `
        <div class="nav-exit">
          <div class="nav-exit-naam">${esc(navLabel(r.s))} ${vlag}</div>
          <div class="nav-exit-stat">
            <span class="nav-exit-pct">${r.pct}%</span>
            <span class="nav-exit-cnt">${r.n}× laatste stap</span>
          </div>
          <div class="nav-balk"><i style="width:${Math.round((r.n/maxN)*100)}%;${knelpunt?'background:linear-gradient(90deg,var(--uit),#a82c30)':''}"></i></div>
        </div>`;
    }).join('');
    inhoud += `<p class="nav-duiding">Percentage = aandeel van de bezoeken aan dat scherm dat eindigde in het sluiten van de app. Hoog op een taak-af-scherm (kwart, poule) is normaal; hoog middenin een flow (spelerprofiel) is een aandachtspunt.</p>`;
  }

  return `
    <div class="kaart">
      <div class="sectie-kop u-mt-0">Navigatie-inzicht</div>
      ${kpis}
      ${segment}
      ${inhoud}
      <p class="u-t-2xs u-zacht u-mt-xs u-lh-ruim">Toont hoe coaches door de app bewegen, alleen schermnaam, tijd en aanleiding (tab/tegel/terug). Geen speler- of persoonsgegevens.</p>
    </div>`;
}

/* ISO-weeknummer als sleutel 'YYYY-Www' */
function isoWeekKey(datumStr){
  const d = new Date(datumStr+'T12:00');
  d.setDate(d.getDate() + 4 - (d.getDay()||7));
  const jan1 = new Date(d.getFullYear(),0,1);
  const week = Math.ceil((((d - jan1) / 86400000) + 1)/7);
  return `${d.getFullYear()}-W${String(week).padStart(2,'0')}`;
}
function maandKey(datumStr){ return datumStr.slice(0,7); }

function dashGebruikGroepen(logins){
  const perDag = {}, perWeek = {}, perMaand = {};
  for (const l of logins){
    if (!l.datum || !l.uid) continue;
    (perDag[l.datum] ||= new Set()).add(l.uid);
    (perWeek[isoWeekKey(l.datum)] ||= new Set()).add(l.uid);
    (perMaand[maandKey(l.datum)] ||= new Set()).add(l.uid);
  }
  return { perDag, perWeek, perMaand };
}

function laatsteDagen(n){
  const out = [];
  for (let i=n-1;i>=0;i--) out.push(new Date(Date.now()-i*86400000).toISOString().slice(0,10));
  return out;
}
function laatsteWeken(n){
  const nu = new Date();
  const dag = (nu.getDay()+6)%7; // maandag = 0
  const maandagDeze = new Date(nu); maandagDeze.setDate(nu.getDate()-dag);
  const out = [];
  for (let i=n-1;i>=0;i--){
    const maandag = new Date(maandagDeze); maandag.setDate(maandagDeze.getDate()-i*7);
    out.push(isoWeekKey(maandag.toISOString().slice(0,10)));
  }
  return out;
}
function laatsteMaanden(n){
  const nu = new Date(); const out = [];
  for (let i=n-1;i>=0;i--){
    const d = new Date(nu.getFullYear(), nu.getMonth()-i, 1);
    out.push(`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`);
  }
  return out;
}
function dashTijdKort(ts){
  if (!ts) return '—';
  try {
    const d = ts.seconds ? new Date(ts.seconds*1000) : new Date(ts);
    return afgKort(d.toISOString().slice(0,10));
  } catch { return '—'; }
}

function htmlClubGebruik(gebruik){
  const { perDag, perWeek, perMaand } = dashGebruikGroepen(gebruik.logins);
  const periode = S.clubDashPeriode || 'dag';
  const data = periode === 'dag'
    ? laatsteDagen(14).map(k => ({ label: afgKort(k), n: perDag[k]?.size || 0 }))
    : periode === 'week'
    ? laatsteWeken(8).map(k => ({ label: k.slice(5), n: perWeek[k]?.size || 0 }))
    : laatsteMaanden(6).map(k => ({ label: new Date(k+'-01T12:00').toLocaleDateString('nl-NL',{month:'short',year:'2-digit'}), n: perMaand[k]?.size || 0 }));
  const max = Math.max(1, ...data.map(d => d.n));

  return `
    <div class="kaart">
      <div class="sectie-kop u-mt-0">Gebruik van de app</div>
      <div class="segment u-mb-md" id="gebruikPeriodeTabs" >
        ${[['dag','Dag'],['week','Week'],['maand','Maand']].map(([id,naam]) =>
          `<button data-periode="${id}" class="${periode===id?'actief':''}">${naam}</button>`).join('')}
      </div>
      ${data.map(d => `
        <div class="u-t-sm" style="display:flex;align-items:center;gap:var(--space-sm);padding:var(--space-2xs) 0">
          <span class="u-zacht" style="width:56px;flex-shrink:0">${esc(d.label)}</span>
          <span class="u-flex-1" style="height:14px;background:var(--surface-2);border-radius:7px;overflow:hidden">
            <span style="display:block;height:100%;width:${Math.round((d.n/max)*100)}%;background:var(--accent);border-radius:7px"></span>
          </span>
          <span class="u-fw-7" style="width:22px;text-align:right">${d.n}</span>
        </div>`).join('')}
      <p class="u-t-2xs u-zacht u-mt-xs">Aantal unieke coaches dat inlogde per ${periode==='dag'?'dag':periode==='week'?'week':'maand'}.</p>
    </div>

    <div class="kaart">
      <div class="sectie-kop u-mt-0">Meest actieve gebruikers</div>
      ${gebruik.gebruikers.length ? `${(S.clubAlleGebruikersOpen ? gebruik.gebruikers : gebruik.gebruikers.slice(0,10)).map(g => `
        <div class="lid-rij">
          <div class="lid-avatar">${esc(initialen(g.naam || g.email || '?'))}</div>
          <div class="lid-naam">${esc(g.naam || g.email || 'Onbekend')}
            <div class="u-t-xs u-zacht" style="font-weight:500;margin-top:1px">${g.email?esc(g.email)+'<span class="sep" aria-hidden="true"></span>':''}laatst: ${dashTijdKort(g.laatsteLogin)}</div>
          </div>
          <div class="u-fw-7 u-t-xl u-c-accent" style="font-family:'Barlow Condensed';flex-shrink:0">${g.aantalLogins||0}</div>
        </div>`).join('')}
      ${gebruik.gebruikers.length > 10 ? `<button class="knop licht vol u-mt-sm u-t-sm" id="btnAlleGebruikers" >${S.clubAlleGebruikersOpen ? 'Toon minder' : `Alle ${gebruik.gebruikers.length} gebruikers tonen`}</button>` : ''}`
      : `<p class="u-t-sm u-zacht">Nog geen logins geregistreerd.</p>`}
    </div>`;
}

/* ==================== CLUB-HUB (tegel-startscherm) ====================
   Vervangt de onderbalk. Dezelfde tegel-opmaak als de coaches-hub: secties met
   een kop, elk met tegels (icoon + naam, optioneel een badge/dot). Terug gaat
   één niveau: leaf → hub → teams, en dashboard-subs → inzicht → hub. */

/* Eén club-tegel. data-club-open="<tab>" wordt in renderClub gekoppeld. */
function clubTegel(tab, naam, icoNaam, badge){
  const mark = badge === true ? '<span class="hub-dot"></span>'
             : badge ? `<span class="hub-badge">${badge}</span>` : '';
  return `<button class="hub-tegel" data-club-open="${tab}">${mark}${ico(icoNaam, 40)}<span class="hub-tnaam">${esc(naam)}</span></button>`;
}
/* Tegel met warn-badge (geel) — voor aandacht-signalen. */
function clubTegelWarn(tab, naam, icoNaam, aantal){
  const mark = aantal ? `<span class="hub-badge warn">${aantal}</span>` : '';
  return `<button class="hub-tegel" data-club-open="${tab}">${mark}${ico(icoNaam, 40)}<span class="hub-tnaam">${esc(naam)}</span></button>`;
}

function htmlClubHub(teams){
  const admin = isBeheerder();
  const ongelezenBer = (S.clubBerichten || []).filter(b => b && b._ongelezen).length || 0;
  const vandaag = new Date().toISOString().slice(0,10);
  const actief = (S.clubAfgelastingen || []).find(a => a.datum >= vandaag);
  const aandacht = teams.filter(t => aandachtRedenen(t, S._clubSyncStatus).length).length;
  const rondesOpen = rondesVan(S.club).filter(r => r.status !== 'gesloten').length;

  /* [20260929a] herindeling: Organisatie / Materiaal / Communicatie / Club */
  const secties = [];
  secties.push(['Organisatie', [
    clubTegelWarn('teams', 'Teams', 'team-members', aandacht || null),
    clubTegel('bouwen',  'Bouwen',  'admin-roles'),
    clubTegel('coaches', 'Coaches', 'team-coach'),
  ]]);
  secties.push(['Materiaal', [
    clubTegel('trainingen', 'Trainingen', 'training-cones'),
    clubTegel('videos',     'Video’s','training-video'),
    clubTegel('documenten', 'Documenten', 'admin-document'),
  ]]);
  const comm = [];
  if (admin) comm.push(clubTegel('berichten', 'Berichten', 'communication-announcement', ongelezenBer || null));
  comm.push(clubTegel('afgelasten', 'Afgelasten', 'action-warning', actief ? '!' : null));
  if (admin) comm.push(clubTegel('content',   'Content',   'admin-file'));
  secties.push(['Communicatie', comm]);
  secties.push(['Club', [
    clubTegel('evals',    'Evaluaties',   'attendance-evaluatie', rondesOpen || null),
    clubTegel('inzicht',  'Inzicht',      'navigation-dashboard'),
    clubTegel('instel',   'Instellingen', 'navigation-settings'),
  ]]);

  const banner = actief ? `
    <div class="cb-banner"><span class="cb-banner-ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg></span>
      <div class="cb-banner-t"><b>Training afgelast — ${esc(afgKort(actief.datum))}</b>${actief.reden ? `<small>${esc(actief.reden)}</small>` : ''}</div>
      <button class="knop licht klein" data-club-open="afgelasten">Bekijk</button></div>` : '';

  return banner + secties.map(([kop, tegels]) => `
    <section class="hub-sectie">
      <div class="hub-sectie-kop">${esc(kop)}</div>
      <div class="hub-grid">${tegels.join('')}</div>
    </section>`).join('');
}

/* Afgelasten (clubbreed) — [20260929a] eigen scherm i.p.v. bovenaan Teams */
function htmlClubAfgelasten(teams, afgelastingen = []){
  const vandaag = new Date().toISOString().slice(0,10);
  const actief = afgelastingen.find(a => a.datum >= vandaag);
  const grens = new Date(Date.now() - 365*24*3600*1000).toISOString().slice(0,10);
  const recent = afgelastingen.filter(a => a.datum >= grens);
  const laatste5 = afgelastingen.slice(0, 5);
  return `
    <div class="club-afgelast-blok">
      ${actief
        ? `<div class="caf-actief">
             <div class="caf-actief-kop"><span><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg></span><b>Training afgelast — ${esc(afgKort(actief.datum))}</b></div>
             ${actief.reden ? `<div class="caf-actief-reden">${esc(actief.reden)}</div>` : ''}
             <button class="knop licht vol caf-op" id="clubAfgelastOpheffen">Afgelasting opheffen</button>
           </div>`
        : `<button class="knop vol caf-aflast" id="clubAflast"${teams.length ? '' : ' disabled'}><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg> Training afgelasten (clubbreed)</button>`}
      <div class="caf-stats">
        <div class="caf-stat"><span class="caf-getal">${recent.length}</span><span class="caf-label">laatste 12 mnd</span></div>
        <div class="caf-stat"><span class="caf-getal">${afgelastingen.length}</span><span class="caf-label">totaal</span></div>
      </div>
      ${laatste5.length ? `
        <div class="caf-historie">
          <div class="caf-historie-kop">Recente afgelastingen</div>
          ${laatste5.map(a => `
            <div class="caf-rij">
              <span class="caf-rij-datum">${esc(afgKort(a.datum))}</span>
              <span class="caf-rij-reden">${a.reden ? esc(a.reden) : '—'}</span>
            </div>`).join('')}
        </div>` : ''}
    </div>`;
}

/* Koppelt de rapport-knoppen (in de Rapporten-tab) aan de schermvullende viewer. */
function koppelInzichtRapporten(v){
  v.querySelectorAll('[data-rapport]').forEach(btn => {
    btn.onclick = () => openRapport(btn.getAttribute('data-rapport'), S._gebruikstats);
  });
}

/* De Inzicht-sub-hub: sync-knop + de statistiek-tabs (Teams/Gebruik/Pagina's/
   Tijd/Rapporten), plus de resterende losse tegels (Overzicht/Aandacht/
   Evaluaties). 'stats' = het gebruikstats-document; 'inzTab' = actieve tab. */
function htmlClubInzicht(signalenAantal, stats, inzTab){
  const laatst = stats?.gegenereerd
    ? new Date(stats.gegenereerd).toLocaleString('nl-NL', { day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' })
    : null;
  const syncBalk = isBeheerder() ? `
    <div class="kaart u-mb-sm" style="display:flex;align-items:center;justify-content:space-between;gap:var(--space-sm)">
      <div>
        <div class="u-fw-6 u-t-md">Statistieken bijwerken</div>
        <div class="u-t-2xs u-zacht u-mt-3xs">
          ${laatst ? `Laatst bijgewerkt: ${esc(laatst)}` : 'Nog niet gesynchroniseerd'}
        </div>
      </div>
      <button class="knop" id="btnSyncStats" style="flex-shrink:0">↻ Synchroniseer</button>
    </div>` : '';
  const tab = inzTab || 'teams';
  return `
    ${syncBalk}
    ${htmlInzichtTabs(tab)}
    <div id="inzichtInhoud">${htmlInzichtTab(tab, stats)}</div>
    <section class="hub-sectie u-mt-md">
      <div class="hub-grid">
        ${clubTegel('dash-overzicht',   'Overzicht',  'navigation-dashboard')}
        ${clubTegelWarn('dash-aandacht','Aandacht',   'action-warning', signalenAantal || null)}
        ${clubTegel('dash-evaluaties',  'Evaluaties', 'attendance-evaluatie')}
      </div>
    </section>`;
}

/* [20260929a] Schermen van het clubbeheer. 'terug' gaat één niveau omhoog. */
const DASH_SUBS = ['dash-overzicht','dash-aandacht','dash-gebruik','dash-navigatie','dash-evaluaties'];
const HUB_LEAVES = ['teams','bouwen','coaches','trainingen','videos','documenten','berichten','afgelasten','content','evals','inzicht','instel'];
const SCHERM_TITELS = {
  'teams':'Teams', 'teambeheer':'Teambeheer', 'bouwen':'Bouwen', 'coaches':'Coaches',
  'trainingen':'Trainingen', 'videos':"Video's", 'documenten':'Documenten',
  'berichten':'Berichten', 'afgelasten':'Afgelasten', 'content':'Content', 'instel':'Instellingen', 'inzicht':'Inzicht',
  'evals':'Evaluaties', 'ronde':'Evaluatieronde', 'rondeform':'Evaluatieronde',
  'dash-overzicht':'Overzicht', 'dash-aandacht':'Aandacht nodig', 'dash-gebruik':'Gebruik',
  'dash-navigatie':'Navigatie', 'dash-evaluaties':'Evaluaties',
};
/* Opnieuw tekenen zonder de teams opnieuw op te halen (na een lokale wijziging). */
function hertekenClub(){ return renderClub({ lokaal:true }); }
function naarClubTab(tab){ S.clubTab = tab; telNav('club:' + tab, 'tegel'); renderClub(); window.scrollTo?.(0, 0); }

async function renderClub(opts = {}){
  if (!S.club) return;
  const v = $('#view-club');
  const tab = S.clubTab;
  const lokaal = !!(opts.lokaal && S.clubTeams);

  // Teams zijn altijd nodig. De rest halen we alleen op als de open tab hem
  // echt toont — en parallel i.p.v. serieel.
  const teams = lokaal ? S.clubTeams : await clubTeamsOphalen();
  S.clubTeams = teams;

  const wilTrainingen = tab === 'trainingen';
  const wilVideos     = tab === 'videos';
  const wilDocumenten = tab === 'documenten';
  const wilAfgelast   = tab === 'afgelasten' || (tab === 'hub' && !S.clubAfgelastingen);

  const [trainingen, videos, documenten, afgelastingen] = await Promise.all([
    wilTrainingen && !lokaal ? clubTrainingenOphalen()  : Promise.resolve(S.clubTrainingen  || []),
    wilVideos && !lokaal     ? clubVideosOphalen()       : Promise.resolve(S.clubVideos      || []),
    wilDocumenten && !lokaal ? clubDocumentenOphalen()   : Promise.resolve(S.clubDocumenten  || []),
    wilAfgelast && !lokaal   ? clubAfgelastingenOphalen().catch(() => []) : Promise.resolve(S.clubAfgelastingen || []),
  ]);
  S.clubTrainingen  = trainingen;
  S.clubVideos      = videos;
  S.clubDocumenten  = documenten;
  S.clubAfgelastingen = afgelastingen;

  // Sportlink-status per team (1 read per team): alleen op de schermen die hem tonen,
  // en bewaard in S._clubSyncStatus zodat de hub-badge en filters hem kunnen gebruiken.
  if (['teams','teambeheer','instel'].includes(tab) && (!lokaal || !S._clubSyncStatus)){
    S._clubSyncStatus = await clubSyncStatusOphalen(teams);
  }
  const syncStatus = S._clubSyncStatus || {};

  const isHub     = tab === 'hub';
  const isInzicht = tab === 'inzicht';
  const isDashSub = DASH_SUBS.includes(tab);

  let inhoud = '';
  let clubEvalData = null;
  let contentLijst = null;
  let rondeVoortgang = null;

  if (isHub){
    // hub heeft de berichten alvast nodig voor de ongelezen-badge (goedkoop; klein)
    if (isBeheerder() && !S.clubBerichten){
      try { S.clubBerichten = await clubBerichtenOphalen(); } catch(e){}
    }
    inhoud = htmlClubHub(teams);
  }
  else if (isInzicht){
    const [dash, stats] = await Promise.all([
      clubDashboardOphalen(teams),
      gebruikstatsOphalen(S.clubId),
    ]);
    S._clubDashCache = dash;
    S._gebruikstats = stats;
    const inzTab = S.clubInzichtTab || 'teams';
    inhoud = htmlClubInzicht(clubSignalen(dash).length, stats, inzTab);
  }
  else if (isDashSub){
    if (tab === 'dash-evaluaties'){
      clubEvalData = await clubEvaluatiesOphalen(teams);
      inhoud = htmlClubEvaluaties(clubEvalData);
    } else if (tab === 'dash-overzicht' || tab === 'dash-aandacht'){
      const dash = S._clubDashCache || await clubDashboardOphalen(teams);
      inhoud = tab === 'dash-overzicht' ? htmlDashOverzicht(teams, dash) : htmlDashAandacht(dash);
    } else {
      const gebruik = await clubGebruikOphalen(teams);
      inhoud = tab === 'dash-gebruik' ? htmlDashGebruik(gebruik) : htmlClubNavigatie(gebruik);
    }
  }
  else if (tab === 'teams')      inhoud = htmlTeamsBeheer(teams, syncStatus);
  else if (tab === 'teambeheer') inhoud = htmlTeamBeheer(teams.find(t => t.id === S._cbTeam), syncStatus, teams);
  else if (tab === 'bouwen')     inhoud = `${htmlBouwIndeling(teams)}${htmlEigenBouwenBeheer(teams)}`;
  else if (tab === 'coaches')    inhoud = htmlTraincoKaart(teams) + htmlCoaches(teams);
  else if (tab === 'afgelasten') inhoud = htmlClubAfgelasten(teams, afgelastingen);
  else if (tab === 'evals' || tab === 'ronde'){
    const rondes = rondesVan(S.club);
    const nodig = tab === 'ronde' ? rondes.filter(r => r.id === S._clubRonde) : rondes.filter(r => r.status !== 'gesloten');
    if (nodig.length){
      try { rondeVoortgang = await voortgangOphalen(teams, nodig); }
      catch(e){ console.warn('[Cluppie] evaluatierondes: voortgang niet gelezen', e); rondeVoortgang = {}; }
    } else rondeVoortgang = {};
    inhoud = tab === 'evals' ? htmlEvalRondes(rondes, rondeVoortgang)
      : htmlRondeDetail(rondes.find(r => r.id === S._clubRonde), rondeVoortgang[S._clubRonde], beheerGroepen(teams));
  }
  else if (tab === 'rondeform')  inhoud = htmlRondeFormulier(beheerGroepen(teams), teams);
  else if (tab === 'trainingen') inhoud = htmlDiagramHerstel(trainingen, isBeheerder()) + htmlClubTrainingen(teams, trainingen);
  else if (tab === 'videos')     inhoud = htmlClubVideos(teams, videos);
  else if (tab === 'documenten') inhoud = htmlClubDocumenten(teams, documenten);
  else if (tab === 'berichten'){
    const berichten = await clubBerichtenOphalen();
    S.clubBerichten = berichten;
    inhoud = htmlClubBerichten(teams, berichten);
  }
  else if (tab === 'instel')     inhoud = htmlClubInstel(teams, syncStatus);
  else if (tab === 'content' && isBeheerder()){
    stopUnsubs('clubContent');
    await new Promise(resolve => {
      let opgelost = false;
      S.unsub.clubContent = startClubContentListener(lijst => {
        contentLijst = lijst;
        if (!opgelost){ opgelost = true; resolve(); }
        else if (S.clubTab === 'content') renderClub(); // live herrenderen
      });
    });
    inhoud = htmlClubContent(contentLijst);
  }

  // --- kop: op de hub de club-titel met veld-look; op subschermen een terug-kop ---
  let kop;
  if (isHub){
    kop = `
      <div class="welkom-kop hub-kop">
        <button class="terug" id="clubTerug">‹</button>
        <h1><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3 20 6.5V11c0 4.5-3.1 8.7-8 10-4.9-1.3-8-5.5-8-10V6.5z"/><circle cx="12" cy="10.4" r="2.1"/><path d="M8.8 16.2a3.6 3.6 0 0 1 6.4 0"/></svg> ${esc(S.club.naam)}<span class="sub">${Object.keys(S.club.teams||{}).length} teams<span class="sep" aria-hidden="true"></span>clubcode ${esc(S.club.code)}</span></h1>
      </div>`;
  } else {
    kop = `
      <div class="kop"><button class="terug" id="clubTerug">‹</button>
        <h1>${esc(SCHERM_TITELS[tab] || S.club.naam)}</h1></div>`;
  }

  // scrollpositie bewaren bij lokaal hertekenen (bijv. een schakelaar in de tabel)
  const scrollY = lokaal ? window.scrollY : null;
  v.innerHTML = `${kop}${inhoud}`;
  if (scrollY != null) window.scrollTo(0, scrollY);

  v.querySelector('#clubTerug').onclick = () => { if (!clubTerugEen()) verlaatClubView(); };

  // hub-tegels (en de banner) koppelen
  v.querySelectorAll('[data-club-open]').forEach(b => b.onclick = () => naarClubTab(b.dataset.clubOpen));

  // statistieken-sync (handmatig)
  const btnSyncStats = v.querySelector('#btnSyncStats');
  if (btnSyncStats) btnSyncStats.onclick = async () => {
    btnSyncStats.disabled = true; const orig = btnSyncStats.textContent;
    btnSyncStats.textContent = '⟳ Bezig met synchroniseren...';
    try {
      const fn = httpsCallable(functions, 'aggregeerGebruik');
      const res = await fn({ clubId: S.clubId });
      const n = res.data?.sessies ?? 0;
      S._gebruikstats = null;
      meld(`Synchronisatie klaar — ${n} sessie${n===1?'':'s'} verwerkt`);
      renderClub();
    } catch(e){
      btnSyncStats.disabled = false; btnSyncStats.textContent = orig;
      meld('Synchronisatie mislukt: ' + (e.message || e.code || 'onbekende fout'));
    }
  };

  v.querySelectorAll('.inzicht-tabs [data-inztab]').forEach(btn => {
    btn.onclick = () => {
      const nieuw = btn.getAttribute('data-inztab');
      S.clubInzichtTab = nieuw;
      v.querySelectorAll('.inzicht-tabs [data-inztab]').forEach(b => b.classList.toggle('actief', b === btn));
      const bak = v.querySelector('#inzichtInhoud');
      if (bak){ bak.innerHTML = htmlInzichtTab(nieuw, S._gebruikstats); koppelInzichtRapporten(v); }
    };
  });
  koppelInzichtRapporten(v);

  const openBeheer = id => { S._cbTeam = id; S._cbUitnodig = null; naarClubTab('teambeheer'); };
  if (tab === 'teams') koppelTeamsBeheer(v, {
    teams, herteken: hertekenClub, openBeheer,
    nieuwTeam: async () => (await teamsModule()).modalNieuwTeam(S.clubId),
    importPdf: () => modalImporteerPDF(),
    alleLinks: () => modalAlleLinks(teams),
  });
  if (tab === 'teambeheer') koppelTeamBeheer(v, {
    team: teams.find(t => t.id === S._cbTeam), teams, herteken: hertekenClub,
    openTeam: async id => (await teamsModule()).openTeam(id),
    sportlink: team => modalSportlinkTeam(team, teams),
    naarBouwen: () => naarClubTab('bouwen'),
  });
  if (tab === 'coaches'){ koppelTraincoKaart(v, { herteken: hertekenClub }); koppelCoaches(v, { herteken: hertekenClub, openBeheer }); }
  if (tab === 'bouwen'){ koppelBouwIndeling(v, teams); koppelEigenBouwenBeheer(v, teams); }
  if (tab === 'evals'){
    v.querySelector('#rondeNieuw')?.addEventListener('click', () => { startConcept(null); naarClubTab('rondeform'); });
    v.querySelectorAll('[data-ronde-open]').forEach(b => b.onclick = () => { S._clubRonde = b.dataset.rondeOpen; naarClubTab('ronde'); });
  }
  if (tab === 'ronde'){
    const r = rondesVan(S.club).find(x => x.id === S._clubRonde);
    koppelRondeDetail(v, r, rondeVoortgang?.[S._clubRonde], {
      naarFormulier: () => naarClubTab('rondeform'),
      herteken: () => renderClub(),
    });
  }
  if (tab === 'rondeform') koppelRondeFormulier(v, {
    teams, herteken: hertekenClub,
    naarRonde: id => { S._clubRonde = id; naarClubTab('ronde'); },
    naarOverzicht: () => naarClubTab('evals'),
  });

  if (tab === 'content' && contentLijst) koppelClubContent(v);
  if (tab === 'dash-evaluaties' && clubEvalData) koppelClubEvaluaties(v, clubEvalData, () => renderClub());
  koppelClubTab(v, tab, teams, trainingen, videos, documenten);
}

/* Eén niveau terug: teambeheer → teams, ronde/formulier → evaluaties,
   dash-scherm → inzicht, overige schermen → hub. Op de hub: false (club uit). */
export function clubTerugEen(){
  const tab = S.clubTab;
  const naar = DASH_SUBS.includes(tab) ? 'inzicht'
    : tab === 'teambeheer' ? 'teams'
    : tab === 'ronde' ? 'evals'
    : tab === 'rondeform' ? (S._clubRonde && rondesVan(S.club).some(r => r.id === S._clubRonde) ? 'ronde' : 'evals')
    : HUB_LEAVES.includes(tab) ? 'hub' : null;
  if (!naar) return false;
  S.clubTab = naar; telNav('club:' + naar, 'terug'); renderClub(); return true;
}

/* [20260929a] Teammodules, trainingsdagen en de teamlijst van het beheer staan nu in club-beheer.js. */

/* ==================== SPORTLINK-KOPPELING PER TEAM ====================
   [20260928] De clubbeheerder kan per team de weergavenaam in Cluppie los van
   Sportlink kiezen (bv. "Selectie") en het team koppelen aan een echt
   Sportlink-team uit de keuzelijst (bv. "ASV'33 1").

   Opslag op teams/{id}: naam, sportlinkNaam (leeg = automatisch op naam),
   sportlinkTeamcode (alleen weergave). De nachtelijke sync matcht op
   sportlinkNaam || naam. De keuzelijst komt uit clubs/{clubId}/geheim/_sportlink,
   die de sync (functions/index.js → schrijfTeamlijst) bijhoudt.

   Hernoemen wijzigt hier bewust NIET de teamcode, zodat bestaande
   uitnodigingslinks blijven werken. */

/* Moet gelijk lopen met teamSleutel() in functions/index.js: bepaalt welk
   Sportlink-team een Cluppie-naam automatisch matcht. */
const EIGEN_CLUB_RE_SL = /asv['’`]?\s*33/i;
function slTeamSleutel(naam){
  let s = String(naam || '').toLowerCase();
  s = s.replace(EIGEN_CLUB_RE_SL, ' ');
  s = s.replace(/\basv\b/g, ' ');
  const m = s.match(/\b(m)?j?o\s*(\d{1,2})\s*[-\s]\s*(\d+)\s*(?:jm|j|m)?\b/i);
  if (m) return (m[1] ? 'm' : '') + 'o' + m[2] + '-' + m[3];
  const sr = s.trim().match(/^(\d{1,2})\s*(?:\(?\s*(?:zon|zat)[a-z]*\s*\)?)?$/);
  if (sr) return 'sen' + sr[1];
  return s.replace(/[^a-z0-9+]+/g, '');
}
/* Op welke naam zoekt de sync voor dit team? */
function slZoeknaam(t){ return String(t?.sportlinkNaam || '').trim() || t?.naam || ''; }
/* Welk Sportlink-team (uit de lijst) matcht een zoeknaam? */
function slMatch(zoeknaam, lijst){
  const k = slTeamSleutel(zoeknaam);
  return k ? (lijst.find(s => slTeamSleutel(s.teamnaam) === k) || null) : null;
}

async function slTeamlijstOphalen(){
  try {
    const snap = await getDoc(doc(db,'clubs',S.clubId,'geheim','_sportlink'));
    const teams = snap.exists() ? (snap.data().teams || []) : [];
    // Eén optie per teamnaam (Sportlink kan een naam onder twee teamcodes
    // hebben, bv. veld + futsal); de variant mét klasse/poule wint.
    const perNaam = new Map();
    for (const t of teams){
      const b = perNaam.get(t.teamnaam);
      if (!b || (!b.klassepoule && t.klassepoule)) perNaam.set(t.teamnaam, t);
    }
    return [...perNaam.values()];
  } catch(e){
    console.warn('[sportlink] teamlijst lezen mislukt', e);
    return [];
  }
}

async function modalSportlinkTeam(team, teams){
  if (!team) return;
  openModal(`<h2>Sportlink<span class="sep" aria-hidden="true"></span>${esc(team.naam)}</h2><p class="u-zacht">Teamlijst laden…</p>`);
  let lijst = await slTeamlijstOphalen();
  const gekoppeld = !!S.club.sportlinkClientId;
  /* [20260929a] Het vinkje "1e én 2e elftal" is weg: de selectie werkt nu met een
     eigen bouw (ASV33-1 + ASV33-2). Een bestaand tweedeElftal-veld laten we staan. */

  const teken = () => {
    const huidig = String(team.sportlinkNaam || '').trim();
    const autoMatch = slMatch(team.naam, lijst);
    const optie = (s) => {
      const extra = [s.klassepoule, s.speeldag].filter(Boolean).join(', ');
      return `<option value="${esc(s.teamnaam)}" data-code="${esc(s.teamcode)}" ${s.teamnaam === huidig ? 'selected' : ''}>${esc(s.teamnaam)}${extra ? ' — ' + esc(extra) : ''}</option>`;
    };
    // Staat er een koppeling die (nog) niet in de lijst voorkomt? Toon hem toch.
    const onbekend = huidig && !lijst.some(s => s.teamnaam === huidig)
      ? `<option value="${esc(huidig)}" selected>${esc(huidig)} (niet in teamlijst)</option>` : '';

    openModal(`
      <h2>Sportlink<span class="sep" aria-hidden="true"></span>${esc(team.naam)}</h2>
      <div class="veldgroep"><label>Naam in Cluppie</label>
        <input class="invoer" id="mSlNaam" value="${esc(team.naam)}" maxlength="40" autocomplete="off"></div>
      <p class="u-t-xs u-zacht" style="margin:-4px 0 var(--space-sm)">De teamcode (${esc(team.code || '—')}) blijft gelijk, dus uitnodigingslinks blijven werken.</p>
      <div class="veldgroep"><label>Team in Sportlink</label>
        <select class="invoer" id="mSlTeam" ${lijst.length || huidig ? '' : 'disabled'}>
          <option value="" ${huidig ? '' : 'selected'}>Automatisch (op naam)</option>
          ${onbekend}${lijst.map(optie).join('')}
        </select></div>
      <div id="mSlInfo" class="u-t-sm u-lh-ruim" style="margin:-4px 0 var(--space-sm)"></div>
      ${!lijst.length ? `
        <div class="kaart u-t-sm u-zacht u-mb-sm">
          ${gekoppeld
            ? `De Sportlink-teamlijst is nog niet opgehaald.<br><button class="knop licht vol u-mt-xs" id="mSlOphalen" ><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg> Teamlijst ophalen</button>`
            : `Vul eerst de Sportlink Client ID in onder Club → Instellingen → Sportlink.`}
        </div>` : ''}
      <button class="knop vol" id="mSlOk">Opslaan</button>`);

    const sel = $('#mSlTeam'), naamIn = $('#mSlNaam'), info = $('#mSlInfo');

    const werkInfoBij = () => {
      const keuze = sel.value;
      const naamNu = naamIn.value.trim();
      const zoek = keuze || naamNu;
      const match = keuze ? (lijst.find(s => s.teamnaam === keuze) || { teamnaam: keuze }) : slMatch(naamNu, lijst);
      let html = '';
      if (!keuze){
        html = match
          ? `Automatisch gekoppeld aan <b>${esc(match.teamnaam)}</b>${match.klassepoule ? '<span class="sep" aria-hidden="true"></span>' + esc(match.klassepoule) : ''}.`
          : (lijst.length ? `<span class="u-c-warn">“${esc(naamNu)}” komt met geen enkel Sportlink-team overeen, kies er hierboven een.</span>` : '');
      }
      // Botsing: synct een ánder team van de club al op hetzelfde Sportlink-team?
      const k = slTeamSleutel(zoek);
      const dubbel = k ? teams.filter(t => t.id !== team.id && slTeamSleutel(slZoeknaam(t)) === k) : [];
      if (dubbel.length){
        html += `${html ? '<br>' : ''}<span class="u-c-warn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg> Let op: ${dubbel.map(t => '<b>' + esc(t.naam) + '</b>').join(', ')} ${dubbel.length === 1 ? 'is' : 'zijn'} ook aan dit Sportlink-team gekoppeld, beide teams krijgen dan dezelfde wedstrijden.</span>`;
      }
      info.innerHTML = html;
    };
    sel.onchange = werkInfoBij;
    naamIn.oninput = werkInfoBij;
    werkInfoBij();

    const ophalen = $('#mSlOphalen');
    if (ophalen) ophalen.onclick = async () => {
      ophalen.disabled = true; ophalen.textContent = 'Bezig…';
      try {
        await httpsCallable(functions, 'syncNu')({ clubId: S.clubId, alleenTeamlijst: true });
        lijst = await slTeamlijstOphalen();
        if (!lijst.length) meld('Sportlink gaf geen teams terug');
        teken();
      } catch(e){
        ophalen.disabled = false; ophalen.textContent = 'Teamlijst ophalen';
        meld('Ophalen mislukt: ' + (e.message || e.code || 'onbekende fout'));
      }
    };

    $('#mSlOk').onclick = async () => {
      const naam = naamIn.value.trim();
      if (!naam) return meld('Geef het team een naam');
      const keuze = sel.value;
      const code = keuze ? (sel.selectedOptions[0]?.dataset.code || null) : null;
      const data = {
        naam,
        sportlinkNaam: keuze || deleteField(),
        sportlinkTeamcode: code || deleteField(),
      };
      const ok = $('#mSlOk');
      ok.disabled = true; ok.textContent = 'Opslaan…';
      try {
        await updateDoc(doc(db,'teams',team.id), data);
        team.naam = naam;
        if (keuze){ team.sportlinkNaam = keuze; team.sportlinkTeamcode = code; }
        else { delete team.sportlinkNaam; delete team.sportlinkTeamcode; }
        sluitModal();
        hertekenClub();
        meld(gekoppeld ? 'Opgeslagen: Instellingen → Sportlink → “Sync nu” haalt direct op' : 'Opgeslagen');
      } catch(e){
        console.error(e); ok.disabled = false; ok.textContent = 'Opslaan';
        meld('Opslaan mislukt: ' + (e.code || e.message));
      }
    };
  };
  teken();
}

/* in welke bouwen valt een training? (op basis van de gekoppelde teams) */
function bouwenVanTraining(t, teams){
  const set = new Set();
  for (const tid of (t.teams||[])){
    const team = teams.find(x => x.id === tid);
    set.add(standaardBouwVoorStof(team));
  }
  return set;
}

/* Haalt een weeknummer uit het vrije week-veld ("Week 1", "week 3", "Wk2", …).
   Geen nummer gevonden → null (valt onder "Overig"). */
function weekNummer(week){
  const m = String(week || '').match(/(\d+)/);
  return m ? Number(m[1]) : null;
}

/* Gesorteerde, unieke lijst van weeklabels die in de trainingen voorkomen.
   Weken mét nummer eerst (oplopend), daarna eventuele losse labels alfabetisch.
   Elk item: { key (stabiel), label (zoals getoond), nr (of null) }. */
function weekLijst(trainingen){
  const gezien = new Map();   // key → {label, nr}
  for (const t of trainingen){
    const label = (t.week || '').trim();
    const key = label ? label.toLowerCase() : '__leeg';
    if (!gezien.has(key)) gezien.set(key, { label: label || 'Zonder week', nr: weekNummer(label) });
  }
  return [...gezien.entries()]
    .map(([key, v]) => ({ key, ...v }))
    .sort((a, b) => {
      if (a.nr != null && b.nr != null) return a.nr - b.nr;
      if (a.nr != null) return -1;
      if (b.nr != null) return 1;
      return a.label.localeCompare(b.label);
    });
}

/* Coverage-overzicht binnen de Trainingen-tab: per TRAININGSGROEP (A/B/C/…)
   een matrix teams × weken, zodat je in één oogopslag ziet welk team binnen
   een groep achterloopt. Elke cel toont "titel · bestandsnaam" (of amber gat).
   Teams die in géén groep zitten staan apart onderaan — die krijgen bij het
   uploaden-per-groep automatisch niets en zijn dus de blinde vlek.
   Puur informatief — geen koppel-actie (bewust, als signaal). */
function htmlClubTrainingenOverzicht(teams, trainingen){
  const weken = weekLijst(trainingen);
  const teamById = new Map(teams.map(t => [t.id, t]));

  // trainingen van één team in één week (op weeklabel gematcht, zoals de lijst)
  const trsVoor = (teamId, weekKey) =>
    trainingen.filter(t =>
      (t.teams || []).includes(teamId) &&
      (((t.week || '').trim().toLowerCase()) || '__leeg') === weekKey);

  const heeftIets = (teamId) => trainingen.some(t => (t.teams || []).includes(teamId));

  // één matrix-cel voor team × week
  const celHtml = (teamId, w) => {
    const items = trsVoor(teamId, w.key);
    if (!items.length) return `<td><div class="tm-cel mist"><span class="tm-gat">— niets</span></div></td>`;
    const inhoud = items.map(t =>
      `<div class="tm-item"><span class="tm-titel">${esc(t.titel || t.bestandsnaam || 'Training')}</span>` +
      (t.bestandsnaam ? `<span class="sep" aria-hidden="true"></span><span class="tm-best">${esc(t.bestandsnaam)}</span>` : '') +
      `</div>`).join('');
    return `<td><div class="tm-cel ok">${inhoud}</div></td>`;
  };

  // matrix voor een set team-id's
  const matrixHtml = (teamIds) => {
    if (!weken.length){
      return `<div class="kaart leeg u-m-0">Nog geen weken, upload een eerste PDF en koppel hem aan een team.</div>`;
    }
    const kop = `<thead><tr><th class="tm-teamkop">Team</th>${
      weken.map(w => `<th class="tm-wk">${esc(w.label)}</th>`).join('')}</tr></thead>`;
    const rijen = teamIds.map(id => {
      const naam = teamById.get(id)?.naam || '?';
      return `<tr><th class="tm-teamnaam">${esc(naam)}</th>${
        weken.map(w => celHtml(id, w)).join('')}</tr>`;
    }).join('');
    return `<div class="tm-scroll"><table class="tm-matrix">${kop}<tbody>${rijen}</tbody></table></div>`;
  };

  // status van een groep: aantal (team × week)-slots dat nog leeg is
  const groepStatus = (teamIds) => {
    if (!teamIds.length) return { ok:false, tekst:'geen teams' };
    if (!weken.length)   return { ok:false, tekst:'nog geen weken' };
    let gaten = 0; const teamsMist = new Set();
    for (const id of teamIds)
      for (const w of weken)
        if (!trsVoor(id, w.key).length){ gaten++; teamsMist.add(id); }
    if (gaten === 0) return { ok:true, tekst:'compleet' };
    if (gaten === teamIds.length * weken.length) return { ok:false, tekst:'niets gekoppeld' };
    return { ok:false, tekst:`${teamsMist.size} team${teamsMist.size>1?'s':''} mist ${gaten} slot${gaten>1?'s':''}` };
  };

  const groepen = trainingsGroepen();

  if (!groepen.length){
    return `<div class="kaart leeg">Nog geen trainingsgroepen ingesteld.<br>Maak eerst groepen (A, B, C …) via <b><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.1"/><path d="M12 3.2 13.6 5.4l2.6-.6 1 2.5 2.6.7-.5 2.6L21 12l-1.7 1.4.5 2.6-2.6.7-1 2.5-2.6-.6L12 20.8l-1.6-2.2-2.6.6-1-2.5-2.6-.7.5-2.6L3 12l1.7-1.4-.5-2.6 2.6-.7 1-2.5 2.6.6z"/></svg> Groepen beheren</b> hierboven: dan zie je hier per groep of alle teams gedekt zijn.</div>`;
  }

  // per groep een uitklapbaar blok; complete groepen starten dichtgeklapt zodat
  // de aandacht vanzelf naar de gaten gaat.
  const groepBlokken = groepen.map(g => {
    const ids = (g.teams || []).filter(id => teamById.has(id));
    const st = groepStatus(ids);
    const dicht = st.ok ? ' dicht' : '';
    const body = ids.length ? matrixHtml(ids)
      : `<div class="kaart leeg u-m-0">Nog geen teams in deze groep.</div>`;
    return `
      <div class="tm-groep${dicht}">
        <div class="tm-groep-kop" data-tm-klap>
          <div class="tm-letter">${esc(g.id)}</div>
          <div class="tm-groep-mid">
            <div class="tm-groep-naam">${esc(g.naam || ('Groep ' + g.id))}</div>
            <div class="tm-groep-sub">${ids.length} team${ids.length===1?'':'s'}${weken.length?`, ${weken.length} ${weken.length===1?'week':'weken'} in beeld`:''}</div>
          </div>
          <span class="tm-pil ${st.ok?'ok':'mist'}">${esc(st.tekst)}</span>
          <span class="tm-chevron">▾</span>
        </div>
        <div class="tm-groep-body">${body}</div>
      </div>`;
  }).join('');

  // teams die in geen enkele groep zitten
  const inGroep = new Set(groepen.flatMap(g => g.teams || []));
  const losTeams = teams
    .filter(t => !inGroep.has(t.id))
    .sort((a, b) => (a.naam || '').localeCompare(b.naam || ''));

  const losBlok = losTeams.length ? `
    <div class="tm-los">
      <div class="tm-los-kop">
        <span class="tm-los-ic"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg></span>
        <span class="tm-los-t">Teams zonder groep</span>
        <span class="tm-los-s">${losTeams.length} team${losTeams.length>1?'s':''}</span>
      </div>
      <div class="tm-los-uitleg">Deze teams zitten in geen enkele trainingsgroep en krijgen bij het uploaden-per-groep automatisch niets. Voeg ze toe via <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.1"/><path d="M12 3.2 13.6 5.4l2.6-.6 1 2.5 2.6.7-.5 2.6L21 12l-1.7 1.4.5 2.6-2.6.7-1 2.5-2.6-.6L12 20.8l-1.6-2.2-2.6.6-1-2.5-2.6-.7.5-2.6L3 12l1.7-1.4-.5-2.6 2.6-.7 1-2.5 2.6.6z"/></svg> Groepen beheren.</div>
      <div class="tm-los-chips">${losTeams.map(t => {
        const heeft = heeftIets(t.id);
        return `<span class="tm-los-chip ${heeft?'heeft':''}">${esc(t.naam || '?')}${heeft?'':'<span class="sep" aria-hidden="true"></span>niets'}</span>`;
      }).join('')}</div>
    </div>` : '';

  return `${groepBlokken}${losBlok}`;
}

/* ==================== TRAININGEN — DESKTOPWEERGAVE ====================
   [20260925a] Alleen als html.desk aan staat (zijbalk-desktop). Mobiel blijft
   de bestaande htmlClubTrainingen-opbouw gebruiken. Zelfde data, zelfde
   knoppen-id's/data-attributen (trainingUpload, trainingFile, trGroepenBeheer,
   data-weergave, data-tdownload, data-tbewerk, …), zodat de bestaande
   koppel-code in renderClub ongewijzigd blijft werken. Nieuw: groepstegels
   (data-trd-naar), weekvenster (data-trd-venster) en slepen op het uploadvlak. */
const TRD_WEKEN = 6;   // zoveel weken naast elkaar in de matrix

/* Korte chiptekst: "Week 39 - training 2" → "Training 2"; anders de titel
   zonder "Week NN -"-voorvoegsel. */
function trdChipLabel(t){
  const titel = String(t.titel || t.bestandsnaam || 'Training');
  const m = titel.match(/training\s*(\d+)/i);
  if (m) return 'Training ' + m[1];
  return titel.replace(/^\s*week\s*\d+\s*[-–·:]\s*/i, '').replace(/\.pdf$/i, '') || titel;
}

function htmlClubTrainingenDesk(teams, trainingen){
  const weergave = S.clubTrainWeergave || 'lijst';
  const groepen = trainingsGroepen();
  const teamById = new Map(teams.map(t => [t.id, t]));
  const alleWeken = weekLijst(trainingen);
  const nuWeek = isoWeek(new Date());
  const wkKey = t => ((t.week || '').trim().toLowerCase()) || '__leeg';

  const werkbalk = `
    <div class="trd-werkbalk">
      <button class="trd-drop" id="trainingUpload" type="button">
        <span class="trd-drop-ic">${ico('admin-upload', 20)}</span>
        <span class="trd-drop-t"><b>PDF-training(en) toevoegen</b>
          <small>Sleep PDF's of een zip hierheen of klik om te kiezen, meerdere tegelijk verdeel je per groep, een heel blok plan je in één keer in</small></span>
        <input type="file" id="trainingFile" accept="application/pdf,.zip,application/zip" multiple style="display:none">
      </button>
      <div class="segment trd-seg" id="trainWeergave">
        <button data-weergave="lijst" class="${weergave==='lijst'?'actief':''}">Lijst</button>
        <button data-weergave="overzicht" class="${weergave==='overzicht'?'actief':''}">Overzicht per groep</button>
        <button data-weergave="plannen" class="${weergave==='plannen'?'actief':''}">Plannen</button>
      </div>
      <button class="trd-knop" id="trGroepenBeheer" type="button">${ico('navigation-settings', 16)}${groepen.length ? 'Groepen beheren' : 'Trainingsgroepen instellen'}</button>
    </div>`;

  return `<div class="trd">${werkbalk}${htmlUploadPaneel()}${weergave === 'overzicht'
    ? trdOverzicht() : weergave === 'plannen' ? `<div class="bp-plannen">${htmlPlannen(trainingen, teams, groepen)}</div>` : trdLijst()}</div>`;

  /* ---------- Overzicht per groep ---------- */
  function trdOverzicht(){
    if (!groepen.length)
      return `<div class="kaart leeg">Nog geen trainingsgroepen ingesteld.<br>Maak eerst groepen (A, B, C …) via <b>Groepen beheren</b> hierboven: dan zie je hier per groep of alle teams gedekt zijn.</div>`;

    // weekvenster: standaard de laatste TRD_WEKEN weken; S._trdVenster schuift terug
    const maxTerug = Math.max(0, alleWeken.length - TRD_WEKEN);
    const terug = Math.min(Math.max(0, S._trdVenster || 0), maxTerug);
    const eind = alleWeken.length - terug;
    const weken = alleWeken.slice(Math.max(0, eind - TRD_WEKEN), eind);
    const bereik = weken.length
      ? (weken.length === 1 ? weken[0].label : `${weken[0].label} – ${weken[weken.length-1].label}`) : '';

    const trsVoor = (teamId, key) => trainingen.filter(t => (t.teams || []).includes(teamId) && wkKey(t) === key);

    const status = ids => {
      if (!ids.length) return { ok:false, tekst:'geen teams' };
      if (!weken.length) return { ok:false, tekst:'nog geen weken' };
      let gaten = 0; const mist = new Set();
      for (const id of ids) for (const w of weken) if (!trsVoor(id, w.key).length){ gaten++; mist.add(id); }
      if (!gaten) return { ok:true, tekst:'compleet', kort:'compleet' };
      if (gaten === ids.length * weken.length) return { ok:false, tekst:'niets gekoppeld', kort:'niets' };
      return { ok:false, tekst:`${mist.size} team${mist.size>1?'s':''} mist ${gaten} slot${gaten>1?'s':''}`, kort:`${gaten} gat${gaten>1?'en':''}` };
    };

    // [20261013d] de matrix toont álle weken en scrolt horizontaal (team-kolom
    // blijft staan); de status/tegels kijken nog naar het venster `weken`.
    const kolommen = alleWeken;
    const matrix = ids => {
      if (!kolommen.length) return `<div class="kaart leeg u-m-0">Nog geen weken, upload een eerste PDF en koppel hem aan een team.</div>`;
      const kop = `<thead><tr><th class="trd-teamkop">Team</th>${kolommen.map(w => {
        const nu = w.nr === nuWeek;
        return `<th class="${nu?'nu':''}">${esc(w.label)}${nu?'<small>deze week</small>':''}</th>`;
      }).join('')}</tr></thead>`;
      const rijen = ids.map(id => {
        const gevuld = weken.filter(w => trsVoor(id, w.key).length).length;
        const cellen = kolommen.map(w => {
          const nu = w.nr === nuWeek ? ' class="nu"' : '';
          const items = trsVoor(id, w.key)
            .slice().sort((a, b) => trdChipLabel(a).localeCompare(trdChipLabel(b), 'nl', { numeric:true }));
          if (!items.length) return `<td${nu}><span class="trd-gat">— niets</span></td>`;
          return `<td${nu}><div class="trd-cel">${items.map(t =>
            `<button class="trd-chip" data-tdownload="${esc(t.url)}" title="${esc(t.bestandsnaam || t.titel || '')}">${ico('action-check', 12)}<span>${esc(trdChipLabel(t))}</span></button>`
          ).join('')}</div></td>`;
        }).join('');
        return `<tr><th>${esc(teamById.get(id)?.naam || '?')}<small>${gevuld}/${weken.length} recente ${weken.length===1?'week':'weken'}</small></th>${cellen}</tr>`;
      }).join('');
      return `<div class="trd-mxscroll"><table class="trd-mx">${kop}<tbody>${rijen}</tbody></table></div>`;
    };

    const inGroep = new Set(groepen.flatMap(g => g.teams || []));
    const losTeams = teams.filter(t => !inGroep.has(t.id)).sort((a, b) => (a.naam || '').localeCompare(b.naam || ''));

    const gdata = groepen.map(g => {
      const ids = (g.teams || []).filter(id => teamById.has(id));
      return { g, ids, st: status(ids) };
    });

    const tegels = `<div class="trd-tegels">${gdata.map(({ g, ids, st }) => `
      <button class="trd-tegel" data-trd-naar="trd-g-${esc(g.id)}" type="button">
        <span class="tm-letter">${esc(g.id)}</span>
        <span class="trd-tegel-m"><b>${esc(g.naam || ('Groep ' + g.id))}</b><small>${ids.length} team${ids.length===1?'':'s'}</small></span>
        <span class="tm-pil ${st.ok?'ok':'mist'}">${esc(st.kort || st.tekst)}</span>
      </button>`).join('')}${losTeams.length ? `
      <button class="trd-tegel warn" data-trd-naar="trd-los" type="button">
        <span class="tm-letter">!</span>
        <span class="trd-tegel-m"><b>Zonder groep</b><small>${losTeams.length} team${losTeams.length>1?'s':''}</small></span>
        <span class="tm-pil mist">let op</span>
      </button>` : ''}</div>`;

    const venster = alleWeken.length > TRD_WEKEN ? `
      <div class="trd-venster"><span class="trd-scrollhint">‹ Scroll opzij voor andere weken<span class="sep" aria-hidden="true"></span>status over ${esc(bereik)} ›</span></div>` : '';

    const blokken = gdata.map(({ g, ids, st }) => `
      <div class="tm-groep trd-groep${st.ok ? ' dicht' : ''}" id="trd-g-${esc(g.id)}">
        <div class="tm-groep-kop" data-tm-klap>
          <div class="tm-letter">${esc(g.id)}</div>
          <div class="tm-groep-mid">
            <div class="tm-groep-naam">${esc(g.naam || ('Groep ' + g.id))}</div>
            <div class="tm-groep-sub">${ids.length} team${ids.length===1?'':'s'}${bereik ? `, ${esc(bereik)}` : ''}</div>
          </div>
          <span class="tm-pil ${st.ok?'ok':'mist'}">${esc(st.tekst)}</span>
          <span class="tm-chevron">▾</span>
        </div>
        <div class="tm-groep-body">${ids.length ? matrix(ids) : `<div class="kaart leeg u-m-0">Nog geen teams in deze groep.</div>`}</div>
      </div>`).join('');

    const los = losTeams.length ? `
      <div class="tm-los" id="trd-los">
        <div class="tm-los-kop"><span class="tm-los-ic"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg></span><span class="tm-los-t">Teams zonder groep</span>
          <span class="tm-los-s">${losTeams.length} team${losTeams.length>1?'s':''}</span></div>
        <div class="tm-los-uitleg">Deze teams zitten in geen enkele trainingsgroep en krijgen bij het uploaden-per-groep automatisch niets. Voeg ze toe via Groepen beheren.</div>
        <div class="tm-los-chips">${losTeams.map(t => {
          const heeft = trainingen.some(x => (x.teams || []).includes(t.id));
          return `<span class="tm-los-chip ${heeft?'heeft':''}">${esc(t.naam || '?')}${heeft?'':'<span class="sep" aria-hidden="true"></span>niets'}</span>`;
        }).join('')}</div>
      </div>` : '';

    return `${tegels}${venster}${blokken}${los}`;
  }

  /* ---------- Lijst: tabel, gegroepeerd per week (nieuwste week boven) ---------- */
  function trdLijst(){
    if (!trainingen.length)
      return `<div class="kaart leeg">Nog geen trainingen.<br>Upload een PDF en koppel hem aan een team of trainingsgroep.</div>`;

    // teams die precies één groep vormen → "Groep B · 6 teams"
    const groepVan = ids => {
      const set = new Set(ids);
      return groepen.find(g => {
        const gi = (g.teams || []).filter(id => teamById.has(id));
        return gi.length && gi.length === set.size && gi.every(id => set.has(id));
      });
    };
    const teamsHtml = t => {
      const ids = (t.teams || []);
      if (!ids.length) return '<span class="trd-leeg">geen team</span>';
      const g = groepVan(ids);
      if (g) return `<span class="trd-tg groep">${esc(g.naam || ('Groep ' + g.id))}<span class="sep" aria-hidden="true"></span>${ids.length} team${ids.length===1?'':'s'}</span>`;
      const namen = ids.map(id => teamById.get(id)?.naam || '?');
      const zicht = namen.slice(0, 5).map(n => `<span class="trd-tg">${esc(n)}</span>`).join('');
      return zicht + (namen.length > 5 ? `<span class="trd-tg" title="${esc(namen.slice(5).join(', '))}">+${namen.length - 5}</span>` : '');
    };

    const rij = t => {
      const ai = Array.isArray(t.oefeningen) && t.oefeningen.length;
      const toonBest = t.bestandsnaam && t.bestandsnaam !== (t.titel || '');
      return `
        <div class="trd-rij">
          <div class="trd-rt"><span class="trd-pdf${ai?' ai':''}">${ai?'AI':'PDF'}</span>
            <div class="trd-rt-m"><div class="trd-tt">${esc(t.titel || t.bestandsnaam || 'Training')}</div>
              ${toonBest ? `<div class="trd-fb">${esc(t.bestandsnaam)}</div>` : ''}${zichtbaarLabel(t) ? `<div class="bp-zv-badge">${esc(zichtbaarLabel(t))}</div>` : ''}</div></div>
          <div class="trd-teams">${teamsHtml(t)}</div>
          <span class="trd-ai${ai?' ja':''}">${ai ? '✓ uitgelezen' : '—'}</span>
          <div class="trd-act">
            <button data-tdownload="${esc(t.url)}" title="Openen">${ico('navigation-forward', 16)}</button>
            ${ai ? `<button data-ttekst="${t.id}" title="Tekst controleren en bewerken">${ico('admin-document', 16)}</button><button data-tnotities="${t.id}" title="Notities van coaches bekijken">${ico('communication-chat', 16)}</button>` : ''}
            <button data-tbewerk="${t.id}" title="Teams en titel wijzigen">${ico('admin-edit', 16)}</button>
            <button data-tshare="${t.id}" title="Delen naar WhatsApp">${ico('action-whatsapp', 16)}</button>
            <button data-tweg="${t.id}" title="Verwijderen" class="weg">${ico('admin-delete', 16)}</button>
          </div>
        </div>`;
    };

    // nieuwste week boven; "Zonder week"/losse labels onderaan
    const volgorde = alleWeken.slice().sort((a, b) => {
      if (a.nr != null && b.nr != null) return b.nr - a.nr;
      if (a.nr != null) return -1;
      if (b.nr != null) return 1;
      return a.label.localeCompare(b.label);
    });
    const secties = volgorde.map(w => {
      const items = trainingen.filter(t => wkKey(t) === w.key)
        .sort((a, b) => String(a.titel || a.bestandsnaam || '').localeCompare(String(b.titel || b.bestandsnaam || ''), 'nl', { numeric:true }));
      if (!items.length) return '';
      return `<div class="trd-weekkop">${esc(w.label)} <span class="trd-tel">${items.length} PDF${items.length===1?'':"'s"}</span>${w.nr === nuWeek ? '<span class="trd-nu">● deze week</span>' : ''}</div>${items.map(rij).join('')}`;
    }).join('');

    return `<div class="trd-lijst"><div class="trd-rij trd-kopr"><span>Training</span><span>Teams</span><span>Tekst</span><span style="text-align:right">Acties</span></div>${secties}</div>`;
  }
}

function htmlClubTrainingen(teams, trainingen){
  if (document.documentElement.classList.contains('desk')) return htmlClubTrainingenDesk(teams, trainingen);
  const weergave = S.clubTrainWeergave || 'lijst';   // 'lijst' | 'overzicht'
  const groepen = trainingsGroepen();

  // Uploadblok: knop met multi-select PDF-input + (indien groepen bestaan) een
  // snelknop naar het groepenbeheer. Eén helper zodat lijst- en overzichts-
  // weergave identiek zijn.
  const uploadBlok = `
    <button class="upload-knop" id="trainingUpload"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M6.6 3.4h7L18.6 8.4v12.2h-12z"/><path d="M13.6 3.4V8.4h5"/></svg> PDF-training(en) toevoegen
      <input type="file" id="trainingFile" accept="application/pdf,.zip,application/zip" multiple style="display:none"></button>
    <div class="tr-boven-acties">
      <span class="tr-boven-hint">Meerdere PDF's, of een zip met een heel blok, kan ook.</span>
      <button class="link" id="trGroepenBeheer">${groepen.length ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.1"/><path d="M12 3.2 13.6 5.4l2.6-.6 1 2.5 2.6.7-.5 2.6L21 12l-1.7 1.4.5 2.6-2.6.7-1 2.5-2.6-.6L12 20.8l-1.6-2.2-2.6.6-1-2.5-2.6-.7.5-2.6L3 12l1.7-1.4-.5-2.6 2.6-.7 1-2.5 2.6.6z"/></svg> Groepen beheren' : '＋ Trainingsgroepen instellen'}</button>
    </div>`;

  // weergave-schakelaar: Lijst (bestaand) of Overzicht per groep (met gaten)
  const weergaveKies = `
    <div class="segment tr-weergave u-mb-md" id="trainWeergave" >
      <button data-weergave="lijst" class="${weergave==='lijst'?'actief':''}">Lijst</button>
      <button data-weergave="overzicht" class="${weergave==='overzicht'?'actief':''}">Overzicht per groep</button>
      <button data-weergave="plannen" class="${weergave==='plannen'?'actief':''}">Plannen</button>
    </div>`;

  if (weergave === 'plannen'){
    return `
      ${uploadBlok}
      ${htmlUploadPaneel()}
      ${weergaveKies}
      <div class="bp-plannen">${htmlPlannen(trainingen, teams, groepen)}</div>`;
  }

  if (weergave === 'overzicht'){
    return `
      ${uploadBlok}
      ${htmlUploadPaneel()}
      ${weergaveKies}
      ${htmlClubTrainingenOverzicht(teams, trainingen)}`;
  }

  // Lijst: alle trainingen van de club, nieuw → oud zoals ze binnenkomen.
  const lijst = trainingen.length ? trainingen.map(t => {
    const teamNamen = (t.teams||[]).map(tid => (teams.find(x => x.id === tid)?.naam) || '?').join(', ');
    const heeftAi = Array.isArray(t.oefeningen) && t.oefeningen.length;
    const tekstKnop = heeftAi
      ? `<button data-ttekst="${t.id}" title="Tekst controleren en bewerken"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M15.4 4.8 19.2 8.6 9 18.8l-4 1.2 1.2-4z"/><path d="M13.4 6.8 17.2 10.6"/></svg></button>`
      : '';
    const notitieKnop = heeftAi
      ? `<button data-tnotities="${t.id}" title="Notities van coaches bekijken"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 5.5h16a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1H9l-4 3.2V16.5H4a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1z"/><path d="M8 9.5h8M8 12.5h5"/></svg></button>`
      : '';
    // bestandsnaam apart tonen als hij afwijkt van de titel (anders dubbelop)
    const toonBest = t.bestandsnaam && t.bestandsnaam !== (t.titel || '');
    return `
      <div class="training-rij">
        <div class="ico${heeftAi?' ai':''}">${heeftAi?`<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg>`:'PDF'}</div>
        <div class="t"><div class="t-titel">${esc(t.titel || t.bestandsnaam)}</div>
          ${toonBest ? `<div class="t-best">${esc(t.bestandsnaam)}</div>` : ''}
          <div class="t-meta">${esc(t.week || '')}${t.week?'<span class="sep" aria-hidden="true"></span>':''}${esc(teamNamen)}</div>
          ${zichtbaarLabel(t) ? `<div class="bp-zv-badge">${esc(zichtbaarLabel(t))}</div>` : ''}</div>
        <div class="acties">
          <button data-tdownload="${esc(t.url)}" title="Openen">↗</button>
          ${tekstKnop}
          ${notitieKnop}
          <button data-tbewerk="${t.id}" title="Teams en titel wijzigen"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M15.4 4.8 19.2 8.6 9 18.8l-4 1.2 1.2-4z"/><path d="M13.4 6.8 17.2 10.6"/></svg></button>
          <button data-tshare="${t.id}" title="Delen naar WhatsApp"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M5 21h14"/></svg></button>
          <button data-tweg="${t.id}" title="Verwijderen" style="color:var(--uit)"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg></button>
        </div>
      </div>`;
  }).join('')
  : `<div class="kaart leeg">Nog geen trainingen.<br>Upload een PDF en koppel hem aan een team of trainingsgroep.</div>`;

  return `
    ${uploadBlok}
    ${htmlUploadPaneel()}
    ${weergaveKies}
    ${lijst}`;
}

function htmlClubVideos(teams, videos){
  const actief = S.clubVideoBouw || 'onder';
  const telPerBouw = {onder:0, midden:0, boven:0};
  for (const vid of videos)
    for (const b of bouwenVanTraining(vid, teams)) telPerBouw[b]++;
  const zichtbaar = videos.filter(vid => bouwenVanTraining(vid, teams).has(actief));

  const segment = `
    <div class="segment u-mb-md" id="videoBouwTabs" >
      ${BOUWEN.map(b => `<button data-vbouw="${b.id}" class="${actief===b.id?'actief':''}">${b.kort}${telPerBouw[b.id]?` <span style="opacity:.6">(${telPerBouw[b.id]})</span>`:''}</button>`).join('')}
    </div>`;

  const lijst = zichtbaar.length ? zichtbaar.map(vid => {
    const teamNamen = (vid.teams||[]).map(tid => (teams.find(x => x.id === tid)?.naam) || '?').join(', ');
    const upload = vid.bron === 'upload';
    const id = upload ? null : youtubeId(vid.url);
    const href = upload ? vid.url : (youtubeWatch(id) || vid.url);
    const thumbInner = id
      ? `<img src="${esc(youtubeThumb(id))}" alt="" loading="lazy"><span class="play">▶</span>`
      : `<span class="play">▶</span>${upload ? '<span class="u-t-2xs u-fw-7" style="position:absolute;bottom:2px;right:3px;letter-spacing:.5px;color:var(--wit);background:color-mix(in srgb, var(--zwart) 55%, transparent);padding:1px var(--space-2xs);border-radius:3px;line-height:1">MP4</span>' : ''}`;
    return `
      <div class="video-rij">
        <a class="thumb" href="${esc(href)}" target="_blank" rel="noopener">${thumbInner}</a>
        <div class="v"><div class="v-titel">${esc(vid.titel || 'Video')}</div>
          <div class="v-meta">${esc(teamNamen || '—')}</div></div>
        <div class="acties">
          <button data-vbewerk="${vid.id}" title="Teams en titel wijzigen"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M15.4 4.8 19.2 8.6 9 18.8l-4 1.2 1.2-4z"/><path d="M13.4 6.8 17.2 10.6"/></svg></button>
          <button data-vshare="${vid.id}" title="Delen naar WhatsApp"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M5 21h14"/></svg></button>
          <button data-vweg="${vid.id}" title="Verwijderen" style="color:var(--uit)"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg></button>
        </div>
      </div>`;
  }).join('')
  : `<div class="kaart leeg">Nog geen video's voor de ${esc(bouwNaam(actief).toLowerCase())}.<br>Plak een YouTube-link of upload een eigen clip en koppel hem aan een team.</div>`;

  return `
    <button class="upload-knop" id="videoToevoegen"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3" y="6" width="13" height="12" rx="2.2"/><path d="M16 10l5-3v10l-5-3z"/></svg> YouTube-video toevoegen voor één of meer teams</button>
    <button class="upload-knop u-mt-xs" id="videoUpload" >Eigen video uploaden (mp4) voor één of meer teams
      <input type="file" id="videoFile" accept="video/mp4,video/*" style="display:none"></button>
    ${segment}
    ${lijst}`;
}

function htmlClubDocumenten(teams, documenten){
  const actief = S.clubDocCategorie || 'alle';
  const telPerCat = {knvb:0, beleid:0, overig:0};
  for (const d of documenten) telPerCat[d.categorie] = (telPerCat[d.categorie]||0) + 1;

  const segment = `
    <div class="segment u-mb-md" id="docCatTabs" >
      <button data-doccat="alle" class="${actief==='alle'?'actief':''}">Alle</button>
      ${DOC_CATEGORIEN.map(c => `<button data-doccat="${c.id}" class="${actief===c.id?'actief':''}">${c.naam}${telPerCat[c.id]?` <span style="opacity:.6">(${telPerCat[c.id]})</span>`:''}</button>`).join('')}
    </div>`;

  const zichtbaar = actief === 'alle' ? documenten : documenten.filter(d => d.categorie === actief);
  const icoonPerCat = {beleid:'PDF', knvb:'KNVB', overig:'DOC'};

  const lijst = zichtbaar.length ? zichtbaar.map(d => {
    const teamNamen = (d.teams||[]).map(tid => (teams.find(x => x.id === tid)?.naam) || '?').join(', ');
    const catNaam = DOC_CATEGORIEN.find(c => c.id === d.categorie)?.naam || 'Overig';
    return `
      <div class="training-rij">
        <div class="ico ${d.categorie==='knvb'?'knvb':d.categorie==='overig'?'overig':''}">${icoonPerCat[d.categorie] || 'DOC'}</div>
        <div class="t"><div class="t-titel">${esc(d.titel || d.bestandsnaam)}</div>
          <div class="t-meta">${esc(catNaam)}<span class="sep" aria-hidden="true"></span>${esc(teamNamen)}</div></div>
        <div class="acties">
          <button data-ddownload="${esc(d.url)}" title="Openen">↗</button>
          <button data-dbewerk="${d.id}" title="Titel, categorie en teams wijzigen"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M15.4 4.8 19.2 8.6 9 18.8l-4 1.2 1.2-4z"/><path d="M13.4 6.8 17.2 10.6"/></svg></button>
          <button data-dshare="${d.id}" title="Delen naar WhatsApp"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M5 21h14"/></svg></button>
          <button data-dweg="${d.id}" title="Verwijderen" style="color:var(--uit)"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg></button>
        </div>
      </div>`;
  }).join('')
  : `<div class="kaart leeg">Nog geen documenten${actief!=='alle' ? ' in deze categorie' : ''}.<br>Upload een PDF en koppel 'm aan één of meer teams.</div>`;

  return `
    <button class="upload-knop" id="documentUpload"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M6.6 3.4h7L18.6 8.4v12.2h-12z"/><path d="M13.6 3.4V8.4h5"/></svg> Document toevoegen voor één of meer teams
      <input type="file" id="documentFile" accept="application/pdf" style="display:none"></button>
    ${segment}
    ${lijst}`;
}

/* ---------- BERICHTEN (admin) ---------- */
const BERICHT_DUUR = [
  {id:'3d',   label:'3 dagen',  ms: 3*86400000},
  {id:'1w',   label:'1 week',   ms: 7*86400000},
  {id:'2w',   label:'2 weken',  ms: 14*86400000},
  {id:'1m',   label:'1 maand',  ms: 30*86400000},
  {id:'perm', label:"Tot ik 'm verwijder", ms: null},
];

function htmlClubBerichten(teams, berichten){
  const nu = Date.now();
  const lijst = berichten.length ? berichten.map(b => {
    const teamNamen = (b.teams||[]).map(tid => (teams.find(x => x.id === tid)?.naam) || '?').join(', ');
    const verlopen = b.zichtbaarTot != null && b.zichtbaarTot < nu;
    return `
      <div class="training-rij ${verlopen ? 'verlopen' : ''}">
        <div class="ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 9.8 16.4 5.6v12.8L5.4 14.2z"/><path d="M5.4 9.8H3.8v4.4h1.6"/><path d="M9.2 14.8v4.4"/></svg></div>
        <div class="t"><div class="t-titel">${esc(b.titel)}</div>
          <div class="t-meta">${esc(teamNamen)}<span class="sep" aria-hidden="true"></span>${verlopen ? 'verlopen' : (b.zichtbaarTot == null ? 'blijft staan' : 'actief')}</div></div>
        <div class="acties">
          <button data-bewerk-bericht="${b.id}" title="Aanpassen"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M15.4 4.8 19.2 8.6 9 18.8l-4 1.2 1.2-4z"/><path d="M13.4 6.8 17.2 10.6"/></svg></button>
          <button data-verwijder-bericht="${b.id}" title="Verwijderen" style="color:var(--uit)"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg></button>
        </div>
      </div>`;
  }).join('')
  : `<div class="kaart leeg">Nog geen berichten.<br>Plaats een bericht voor één of meer teams, coaches zien het als een balk bij het openen van hun team.</div>`;

  return `
    <button class="upload-knop" id="nieuwBericht"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 9.8 16.4 5.6v12.8L5.4 14.2z"/><path d="M5.4 9.8H3.8v4.4h1.6"/><path d="M9.2 14.8v4.4"/></svg> Nieuw bericht voor één of meer teams</button>
    ${lijst}`;
}

/* Bericht opstellen of aanpassen. Toewijzing via dezelfde team-picker als
   trainingen/documenten (teamKeuzePerBouw). */
function modalNieuwBericht(teams, bestaand = null){
  const huidig = new Set(bestaand?.teams || []);
  // bij een bestaand bericht de duur-keuze niet terug-afleiden; default 'perm'
  // als het bericht al liep, anders 1 week voor een nieuw bericht.
  const duurStart = bestaand ? 'perm' : '1w';
  openModal(`
    <h2>${bestaand ? 'Bericht aanpassen' : 'Nieuw bericht'}</h2>
    <div class="veldgroep"><label>Titel</label>
      <input class="invoer" id="mBerTitel" value="${esc(bestaand?.titel || '')}" placeholder="Bijv. Nieuwe veldverdeling" autocomplete="off"></div>
    <div class="veldgroep"><label>Bericht</label>
      <textarea class="invoer" id="mBerBody" rows="3" placeholder="Wat moeten de coaches weten?">${esc(bestaand?.body || '')}</textarea></div>
    <div class="veldgroep"><label>Voor welke teams?</label>
      <div id="mBerTeams">${teams.length ? teamKeuzePerBouw(teams, huidig) : '<p class="u-t-sm u-zacht">Geen teams in deze club.</p>'}</div>
      <div class="rij u-mt-xs">
        <button class="knop licht klein" id="mBerAlle">Alle teams</button>
        <button class="knop licht klein" id="mBerGeen">Geen</button>
      </div>
    </div>
    <div class="veldgroep"><label>Hoe lang zichtbaar?</label>
      <div class="duur-rij" id="mBerDuur">
        ${BERICHT_DUUR.map(d => `<button type="button" class="duur-opt ${d.id===duurStart?'aan':''}" data-duur="${d.id}">${esc(d.label)}</button>`).join('')}
      </div>
    </div>
    <button class="knop vol" id="mBerOk">${bestaand ? 'Wijzigingen opslaan' : 'Bericht plaatsen'}</button>`);

  const sync = () => $$('#mBerTeams label').forEach(l => l.classList.toggle('aan', l.querySelector('input').checked));
  $$('#mBerTeams input').forEach(c => c.onchange = sync);
  $('#mBerAlle').onclick = () => { $$('#mBerTeams input').forEach(c => c.checked = true); sync(); };
  $('#mBerGeen').onclick = () => { $$('#mBerTeams input').forEach(c => c.checked = false); sync(); };
  let duur = duurStart;
  $$('#mBerDuur [data-duur]').forEach(b => b.onclick = () => {
    duur = b.dataset.duur;
    $$('#mBerDuur [data-duur]').forEach(x => x.classList.toggle('aan', x.dataset.duur === duur));
  });
  $('#mBerOk').onclick = async () => {
    const gekozen = $$('#mBerTeams input').filter(c => c.checked).map(c => c.dataset.tid);
    if (!gekozen.length) return meld('Kies minstens één team');
    const titel = $('#mBerTitel').value.trim();
    if (!titel) return meld('Geef het bericht een titel');
    const body = $('#mBerBody').value.trim();
    const duurDef = BERICHT_DUUR.find(d => d.id === duur) || BERICHT_DUUR[1];
    const zichtbaarTot = duurDef.ms == null ? null : Date.now() + duurDef.ms;
    sluitModal();
    try {
      if (bestaand){
        await updateDoc(doc(db,'berichten',bestaand.id), {titel, body, teams: gekozen, zichtbaarTot});
        meld('Bericht bijgewerkt');
      } else {
        await addDoc(collection(db,'berichten'), {
          club: S.clubId, clubNaam: S.club.naam,
          titel, body, teams: gekozen,
          zichtbaarTot,
          gemaakt: serverTimestamp(),
          door: S.user.displayName || S.user.email || '',
        });
        meld('Bericht geplaatst');
      }
      renderClub();
    } catch(e){
      console.error(e); meld('Opslaan mislukt: ' + (e.code || e.message));
    }
  };
}

/* [20260929a] Instellingen in drie tabbladen: Algemeen · Sportlink · Beheerders.
   Coördinatoren en bouwen staan nu onder Club → Bouwen. */
function htmlClubInstel(teams = [], syncStatus = {}){
  const sub = S._clubInstelTab || 'algemeen';
  const seg = `<div class="segment cb-instel-seg">${[['algemeen','Algemeen'],['sportlink','Sportlink'],['beheer','Beheerders']]
    .map(([id, n]) => `<button class="${sub === id ? 'actief' : ''}" data-instel-tab="${id}">${n}</button>`).join('')}</div>`;
  let inhoud = '';

  if (sub === 'algemeen'){
    const huidigSeizoen = S.club.huidigSeizoen || SEIZOEN_FALLBACK;
    const modus = S.club.themaModus || 'coachKiest';
    const opt = (waarde, titel, uitleg) => `
      <button class="thema-optie ${modus===waarde?'gekozen':''}" data-thema-modus="${waarde}">
        <span class="tk-radio"></span>
        <span class="tk-body"><span class="tk-titel">${titel}</span><span class="tk-sub">${uitleg}</span></span>
      </button>`;
    inhoud = `
      <div class="cb-kaart">
        <div class="cb-kaart-kop">${ico('planning-calendar',18)}<b>Seizoen</b></div>
        <div style="display:flex;align-items:center;gap:var(--space-sm)">
          <div class="u-flex-1">
            <div class="u-t-2xs u-zacht u-mb-3xs">Huidig seizoen</div>
            <div class="cond u-fw-7 u-t-3xl">${esc(huidigSeizoen)}</div>
          </div>
          <button class="knop fluo klein" id="btnNieuwSeizoen">Nieuw seizoen →</button>
        </div>
        <p class="cb-uitleg">Nieuwe wedstrijden, trainingen, beoordelingen en teamevaluaties van alle teams tellen vanaf de start mee voor het nieuwe seizoen. Oude data blijft bewaard en is terug te zien via het seizoenfilter in de statistieken.</p>
        <button class="cb-inklap" id="migreerSeizoen"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.4" y="4.6" width="17.2" height="4.4" rx="1.8"/><path d="M5.2 9v10.4h13.6V9"/><path d="M10 13h4"/></svg> Oude data zonder seizoen labelen <span>›</span></button>
      </div>
      <div class="cb-kaart">
        <div class="cb-kaart-kop">${ico('navigation-settings',18)}<b>Weergave &amp; thema</b></div>
        <p class="cb-uitleg" style="margin:0 0 var(--space-sm)">Het thema voor de hele club. Een vaste stand gaat vóór de persoonlijke keuze van een coach.</p>
        <div class="thema-modus" id="clubThemaModus">
          ${opt('donker','Alleen donker','Iedereen zit vast op donker. Coaches zien geen keuze.')}
          ${opt('licht','Alleen licht','Iedereen zit vast op licht. Coaches zien geen keuze.')}
          ${opt('lichtDefault','Standaard licht','Nieuwe coaches beginnen in het licht, maar kunnen zelf naar donker wisselen. Wie al bewust donker koos, houdt dat.')}
          ${opt('coachKiest','Coach mag kiezen','Elke coach kiest zelf, opgeslagen op zijn eigen toestel. Zonder keuze volgt de app het toestel.')}
        </div>
      </div>`;
  }

  else if (sub === 'sportlink'){
    const syncTijd = (ts) => {
      if (!ts) return '';
      try {
        const d = ts.seconds ? new Date(ts.seconds*1000) : new Date(ts);
        return d.toLocaleDateString('nl-NL',{day:'numeric',month:'short'}) + ' ' +
               d.toLocaleTimeString('nl-NL',{hour:'2-digit',minute:'2-digit'});
      } catch { return ''; }
    };
    const clientId = S.club.sportlinkClientId || '';
    const gekoppeld = !!clientId;
    const rij = t => {
      const st = syncStatus[t.id] || {};
      let badge, onder = '';
      if (!gekoppeld) badge = `<span class="tok-status leeg">Wacht op koppeling</span>`;
      else if (st.laatsteFout){ badge = `<span class="tok-status leeg">Fout</span>`; onder = `<div class="tok-laatste u-c-warn">Laatste sync mislukt: ${esc(st.laatsteFout)}</div>`; }
      else if (st.gematcht){
        badge = `<span class="tok-status gekoppeld">Gematcht</span>`;
        const aantal = st.laatsteAantal != null ? `${st.laatsteAantal} wedstrijd${st.laatsteAantal===1?'':'en'}` : '';
        onder = `<div class="tok-laatste">Laatste sync: <b>${esc(syncTijd(st.laatsteSync))}</b>${aantal?'<span class="sep" aria-hidden="true"></span>'+aantal:''}</div>`;
      }
      else if (st.laatsteSync){ badge = `<span class="tok-status leeg">Niet gevonden</span>`; onder = `<div class="tok-laatste">${t.sportlinkNaam ? `Sportlink-team “${esc(t.sportlinkNaam)}”` : `Teamnaam “${esc(t.naam)}”`} niet in Sportlink gevonden. <button class="cb-link" data-sl-koppel="${esc(t.id)}">Koppelen ›</button></div>`; }
      else badge = `<span class="tok-status leeg">Nog niet gesynct</span>`;
      return `<div class="tok-rij"><div class="tok-kop"><span class="tok-team">${esc(t.naam)}</span>${badge}</div>${onder}</div>`;
    };
    const goed = teams.filter(t => syncStatus[t.id]?.gematcht && !syncStatus[t.id]?.laatsteFout);
    const aandacht = teams.filter(t => !goed.includes(t));
    const laatste = goed.map(t => syncStatus[t.id]?.laatsteSync).filter(Boolean)
      .map(ts => ts.seconds ? ts.seconds*1000 : new Date(ts).getTime()).sort((a,b) => b-a)[0];
    const koppelKaart = `
      <div class="cb-kaart">
        <div class="cb-kaart-kop">${ico('admin-permissions',18)}<b>Koppeling</b></div>
        <div class="tok-invoer">
          <input type="text" id="clientIdInput" placeholder="Bijv. oEGJY6X0n9" value="${esc(clientId)}" autocomplete="off" spellcheck="false">
          <button id="clientIdOpslaan">Opslaan</button>
        </div>
        ${gekoppeld ? `<p class="u-t-xs" style="color:var(--in);margin:var(--space-xs) 0 0">✓ Gekoppeld met Client ID <code class="u-t-2xs">${esc(clientId)}</code></p>` : ''}
        <p class="cb-uitleg">De Client ID van jullie Sportlink Club.Dataservice. Daarmee haalt Cluppie het programma, de uitslagen en de standen op voor alle teams. Teams koppelen automatisch op naam; heet een team anders, koppel het dan in Teambeheer.</p>
      </div>`;
    inhoud = gekoppeld ? `
      <div class="cb-samenvat">
        <div class="ok"><b>${goed.length}</b><span>teams gematcht</span></div>
        <div class="${aandacht.length ? 'let' : ''}"><b>${aandacht.length}</b><span>aandacht nodig</span></div>
        <div><b>${laatste ? new Date(laatste).toLocaleTimeString('nl-NL',{hour:'2-digit',minute:'2-digit'}) : '—'}</b><span>laatste sync</span></div>
      </div>
      ${aandacht.length ? `<div class="sectie-kop u-mt-2xs">Aandacht nodig</div><div class="kaart">${aandacht.map(rij).join('')}</div>` : ''}
      <button class="knop vol" id="syncNu"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg> Sync nu alle teams</button>
      <p class="u-t-xs u-zacht u-tc" style="margin:var(--space-xs) 0 var(--space-md)">De sync draait sowieso elke nacht automatisch.</p>
      ${goed.length ? `<button class="cb-inklap" id="slAlles">Alle ${goed.length} gematchte teams <span>${S._clubSlAlles ? '▴' : '▾'}</span></button>
        ${S._clubSlAlles ? `<div class="kaart">${goed.map(rij).join('')}</div>` : ''}` : ''}
      ${koppelKaart}` : `${koppelKaart}
      ${teams.length ? `<div class="sectie-kop">Teams</div><div class="kaart">${teams.map(rij).join('')}</div>` : ''}`;
  }

  else {
    const admins = Object.entries(S.club.adminsInfo || {});
    const link = location.origin + location.pathname + '?club=' + S.club.code;
    inhoud = `
      <div class="cb-kaart">
        <div class="cb-kaart-kop">${ico('admin-admin',18)}<b>Clubbeheerders</b><span class="cb-telling">${admins.length}</span></div>
        ${admins.length ? admins.map(([uid, a]) => { const n = String(a?.naam || 'Beheerder').split('@')[0];
          return `<div class="cb-persoon"><div class="cb-av">${esc(n.split(/\s+/).map(w => w[0]).slice(0,2).join('').toUpperCase())}</div><div class="cb-persoon-n">${esc(n)}</div>${uid === S.user?.uid ? '<span class="cb-rol admin">Jij</span>' : ''}</div>`; }).join('')
          : '<p class="cb-uitleg u-m-0">—</p>'}
      </div>
      <div class="cb-kaart">
        <div class="cb-kaart-kop">${ico('team-add',18)}<b>Mede-beheerder uitnodigen</b></div>
        <p class="cb-uitleg" style="margin:0 0 var(--space-xs)">Wie deze link opent, wordt beheerder van de hele club. Deel hem alleen met mede-bestuurders.</p>
        <div class="uitnodig-link" id="clubLink">${esc(link)}</div>
        <button class="knop licht vol klein u-mt-xs" id="kopieerClubLink" >${ico('action-copy',15)} Link kopiëren</button>
      </div>
      <div class="cb-kaart cb-gevaar">
        <div class="cb-kaart-kop">${ico('action-warning',18)}<b>Gevarenzone</b></div>
        <p class="cb-uitleg" style="margin:0 0 var(--space-sm)">Club opheffen ontkoppelt alle teams van de club. Teams en trainingen zelf blijven bestaan.</p>
        <button class="knop gevaar vol" id="verwijderClub">Club opheffen</button>
      </div>`;
  }
  return seg + inhoud;
}

/* Stelt op basis van het huidige seizoen-label (bijv. "2025/'26") het
   volgende seizoen voor (bijv. "2026/'27"), als startpunt in de modal. */
function volgendSeizoen(huidig){
  const m = /^(\d{4})/.exec(huidig || '');
  const jaar = m ? Number(m[1]) + 1 : new Date().getFullYear();
  return `${jaar}/'${String(jaar+1).slice(-2)}`;
}

/* ---------- Nieuw seizoen starten ----------
   Alleen clubs/{clubId}.huidigSeizoen wordt bijgewerkt. Nieuwe documenten
   (wedstrijden, presentie, beoordelingen, teamevaluaties) van alle teams
   krijgen dit label vanaf hun eerstvolgende aanmaak-moment (zie teams.js/
   wedstrijd.js: die lezen S.huidigSeizoen, dat live meeluistert met dit veld).
   Bestaande data verandert hier niet — daarvoor is de migratieknop. */
function modalNieuwSeizoen(){
  const huidig = S.club.huidigSeizoen || SEIZOEN_FALLBACK;
  const voorstel = volgendSeizoen(huidig);
  openModal(`
    <h2>Nieuw seizoen starten</h2>
    <p class="u-t-sm u-zacht u-mb-md">Je huidige seizoen is <b>${esc(huidig)}</b>. Vanaf bevestigen loggen nieuwe wedstrijden, trainingen, beoordelingen en teamevaluaties van alle teams onder het nieuwe seizoen. Oude data blijft gewoon bewaard en is terug te zien via het seizoenfilter in de statistieken.</p>
    <div class="veldgroep"><label>Nieuw seizoen</label>
      <input class="invoer" id="mSeizoenNaam" value="${esc(voorstel)}" autocomplete="off" style="text-align:center;font-weight:700"></div>
    <div class="rij u-mt-xs">
      <button class="knop licht vol" id="mSeizoenAnnuleer">Annuleren</button>
      <button class="knop vol" id="mSeizoenOk">Bevestigen</button>
    </div>`);
  $('#mSeizoenAnnuleer').onclick = () => sluitModal();
  $('#mSeizoenOk').onclick = async () => {
    const nieuw = $('#mSeizoenNaam').value.trim();
    if (!nieuw) return meld('Vul een seizoensnaam in');
    const knop = $('#mSeizoenOk'); knop.disabled = true; knop.textContent = 'Bezig...';
    try {
      await updateDoc(doc(db,'clubs',S.clubId), { huidigSeizoen: nieuw });
      sluitModal();
      meld(`Seizoen ${nieuw} gestart ✓`);
      renderClub();
    } catch(e){
      knop.disabled = false; knop.textContent = 'Bevestigen';
      meld('Opslaan mislukt: ' + (e.code || e.message));
    }
  };
}

/* ---------- Eenmalige migratie: bestaande data labelen ----------
   Loopt over wedstrijden/presentie/beoordelingen/teamevaluaties van alle
   teams van de club en zet seizoen = huidig clubseizoen op elk document dat
   nog geen seizoen-veld heeft. Documenten die al een label hebben (van ná
   deze feature) worden overgeslagen. Mag zo vaak gedraaid worden als nodig. */
async function migreerSeizoenData(teams){
  if (!teams.length) return meld('Geen teams om te migreren');
  const doel = S.club.huidigSeizoen || SEIZOEN_FALLBACK;
  if (!confirm(`Alle bestaande wedstrijden, trainingen, beoordelingen en teamevaluaties zonder seizoen-label worden gelabeld als "${doel}". Doorgaan?`)) return;
  const knop = $('#migreerSeizoen');
  const origTekst = knop ? knop.textContent : '';
  if (knop){ knop.disabled = true; knop.textContent = 'Bezig met migreren...'; }
  const subcollecties = ['wedstrijden','presentie','beoordelingen','teamevaluaties'];
  let batch = writeBatch(db);
  let inBatch = 0, totaal = 0;
  try {
    for (const t of teams){
      for (const sub of subcollecties){
        const snap = await getDocs(collection(db,'teams',t.id,sub));
        for (const d of snap.docs){
          if (d.data().seizoen) continue;
          batch.update(d.ref, { seizoen: doel });
          inBatch++; totaal++;
          if (inBatch >= 450){ await batch.commit(); batch = writeBatch(db); inBatch = 0; }
        }
      }
    }
    if (inBatch > 0) await batch.commit();
    meld(totaal ? `${totaal} bestaande items gelabeld als ${doel}` : 'Alles was al gelabeld');
  } catch(e){
    meld('Migreren mislukt: ' + (e.code || e.message));
  } finally {
    if (knop){ knop.disabled = false; knop.textContent = origTekst || 'Migreer bestaande data naar dit seizoen'; }
  }
}

/* ---------- Clubbrede afgelasting ---------- */
/* Schrijft het afgelast-veld naar ALLE team-documenten van de club tegelijk (Optie B),
   plus één centraal historie-record onder clubs/{clubId}/afgelastingen voor de stats.
   Geen naam in de afgelasting. Alleen de beheerder ziet/gebruikt deze knop. */
function modalClubAflasten(teams){
  const vandaag = new Date().toISOString().slice(0,10);
  openModal(`
    <h2>Training afgelasten</h2>
    <p class="u-t-sm u-zacht u-mb-md">Dit last de training af voor <b>alle ${teams.length} teams</b> van de club. Elke trainer kan het bericht daarna doorsturen in zijn eigen WhatsApp-groep.</p>
    <div class="veldgroep"><label>Welke dag?</label>
      <input class="invoer" id="mAflasDatum" type="date" value="${vandaag}" min="${vandaag}"></div>
    <div class="veldgroep"><label>Reden (optioneel)</label>
      <input class="invoer" id="mAflasReden" placeholder="Bijv. slecht weer, velden onbespeelbaar" autocomplete="off" maxlength="140"></div>
    <div class="rij u-mt-xs">
      <button class="knop licht vol" id="mAflasAnnuleer">Annuleren</button>
      <button class="knop vol" id="mAflasOk">Aflasten voor hele club</button>
    </div>`);

  $('#mAflasAnnuleer').onclick = () => sluitModal();
  $('#mAflasOk').onclick = async () => {
    const datum = $('#mAflasDatum').value;
    if (!datum) return meld('Kies eerst een dag');
    const reden = ($('#mAflasReden').value || '').trim();
    const knop = $('#mAflasOk'); knop.disabled = true; knop.textContent = 'Aflasten...';
    const data = { datum, reden, tijd: serverTimestamp() };
    try {
      // 1) naar alle team-documenten van de club (Optie B)
      await Promise.all(teams.map(t =>
        updateDoc(doc(db,'teams',t.id), { afgelast: data })
      ));
      // 2) één centraal historie-record voor de stats
      await addDoc(collection(db,'clubs',S.clubId,'afgelastingen'), data);
      telGebruik('afgelasting');
      sluitModal();
      meld(`Training afgelast voor ${teams.length} teams`);
      renderClub();
    } catch(e){
      knop.disabled = false; knop.textContent = 'Aflasten voor hele club';
      meld('Aflasten mislukt: ' + (e.code || e.message));
    }
  };
}

async function clubAfgelastOpheffen(teams){
  if (!confirm('Afgelasting opheffen? De trainingen gaan dan weer gewoon door.')) return;
  try {
    // 1) wis het afgelast-veld op alle team-documenten (verbergt de banner)
    await Promise.all(teams.map(t =>
      updateDoc(doc(db,'teams',t.id), { afgelast: deleteField() })
    ));
    // 2) verwijder de actieve (vandaag/toekomstige) historie-records, zodat een
    //    per ongeluk ingestelde afgelasting de stats niet vervuilt en het clubscherm
    //    niet langer 'actief' toont. Opheffen = correctie van een vergissing.
    const vandaag = new Date().toISOString().slice(0,10);
    const actieve = (S.clubAfgelastingen || []).filter(a => a.datum >= vandaag);
    await Promise.all(actieve.map(a =>
      deleteDoc(doc(db,'clubs',S.clubId,'afgelastingen',a.id))
    ));
    meld('Afgelasting opgeheven');
    renderClub();
  } catch(e){
    meld('Opheffen mislukt: ' + (e.code || e.message));
  }
}

function koppelClubTab(v, tab, teams, trainingen, videos, documenten){
  if (tab === 'afgelasten'){
    const aflastBtn = v.querySelector('#clubAflast');
    if (aflastBtn) aflastBtn.onclick = () => modalClubAflasten(teams);
    const opheffenBtn = v.querySelector('#clubAfgelastOpheffen');
    if (opheffenBtn) opheffenBtn.onclick = () => clubAfgelastOpheffen(teams);
  }
  if (tab === 'trainingen'){
    if (isBeheerder()) koppelDiagramHerstel(v, trainingen, { clubId: S.clubId, meld, herteken: () => renderClub() });
    v.querySelectorAll('[data-weergave]').forEach(b => b.onclick = () => {
      S.clubTrainWeergave = b.dataset.weergave; renderClub();
    });
    // groepsblokken in het overzicht in-/uitklappen (puur UI, geen re-render)
    v.querySelectorAll('[data-tm-klap]').forEach(kop => kop.onclick = () => {
      kop.closest('.tm-groep')?.classList.toggle('dicht');
    });
    const knop = v.querySelector('#trainingUpload');
    const input = v.querySelector('#trainingFile');
    knop.onclick = () => input.click();
    input.onchange = e => {
      const files = [...e.target.files]; if (!files.length) return;
      e.target.value = '';   // zelfde bestand later opnieuw kunnen kiezen
      uploadGekozen(files, teams, trainingen);
    };
    // [20260925a] desktop: groepstegel → groep openklappen en ernaartoe scrollen
    v.querySelectorAll('[data-trd-naar]').forEach(b => b.onclick = () => {
      const doel = v.querySelector('#' + CSS.escape(b.dataset.trdNaar)); if (!doel) return;
      doel.classList.remove('dicht');
      doel.scrollIntoView({ behavior:'smooth', block:'start' });
    });
    // [20261013d] matrix: naar deze week scrollen en alle groepen synchroon laten scrollen
    const scrollers = [...v.querySelectorAll('.trd-mxscroll')];
    if (scrollers.length){
      const eerste = scrollers[0];
      const doel = eerste.querySelector('thead th.nu') || eerste.querySelector('thead th:last-child');
      const teamKol = eerste.querySelector('thead th.trd-teamkop')?.offsetWidth || 150;
      const x = doel ? Math.max(0, doel.offsetLeft - teamKol - 24) : 0;
      let bezig = false;
      scrollers.forEach(sc => {
        sc.scrollLeft = x;
        sc.addEventListener('scroll', () => {
          if (bezig) return; bezig = true;
          scrollers.forEach(o => { if (o !== sc) o.scrollLeft = sc.scrollLeft; });
          bezig = false;
        }, { passive:true });
      });
    }
    // desktop: weekvenster verschuiven (runtime-veld op S, geen state.js-wijziging)
    v.querySelectorAll('[data-trd-venster]').forEach(b => b.onclick = () => {
      S._trdVenster = Math.max(0, Number(b.dataset.trdVenster) || 0); renderClub();
    });
    // PDF's op het uploadvlak slepen (werkt overal waar slepen kan)
    const pdfUitDrop = e => [...(e.dataTransfer?.files || [])]
      .filter(f => f.type === 'application/pdf' || /\.pdf$/i.test(f.name) || isZip(f));
    ['dragenter','dragover'].forEach(n => knop.addEventListener(n, e => { e.preventDefault(); knop.classList.add('sleep'); }));
    knop.addEventListener('dragleave', () => knop.classList.remove('sleep'));
    knop.addEventListener('drop', e => {
      e.preventDefault(); knop.classList.remove('sleep');
      const files = pdfUitDrop(e);
      if (!files.length){ meld('Alleen PDF- of zip-bestanden kunnen hier worden toegevoegd'); return; }
      uploadGekozen(files, teams, trainingen);
    });
    // [20261013a] Plannen-weergave: week laten vervallen / terugzetten
    koppelPlannen(v, trainingen, { renderClub: () => renderClub() });
    const grpBeheer = v.querySelector('#trGroepenBeheer');
    if (grpBeheer) grpBeheer.onclick = () => modalTrainingsGroepen(teams);
    v.querySelectorAll('[data-tdownload]').forEach(b => b.onclick = () => window.open(b.dataset.tdownload, '_blank'));
    v.querySelectorAll('[data-tnotities]').forEach(b => b.onclick = async () => {
      const t = trainingen.find(x => x.id === b.dataset.tnotities);
      if (!t) return;
      const { openBeheerNotities } = await import('./training-notities-beheer.js?v=20261106h');
      openBeheerNotities({ trainingId: t.id, titel: t.titel || t.bestandsnaam || 'Training', oefeningen: t.oefeningen || [] });
    });
    v.querySelectorAll('[data-ttekst]').forEach(b => b.onclick = async () => {
      const t = trainingen.find(x => x.id === b.dataset.ttekst);
      if (!t) return;
      const datum = t.gemaakt?.seconds ? new Date(t.gemaakt.seconds*1000).toLocaleDateString('nl-NL',{day:'numeric',month:'short'}) : '';
      const { openTrainingBewerken } = await import('./training-bewerken.js?v=20261106h');
      openTrainingBewerken({
        trainingId: t.id,
        titel: t.titel || t.bestandsnaam || 'Training',
        meta: [t.week, datum].filter(Boolean).join(', '),
        oefeningen: t.oefeningen || [],
        paginas: t.paginas || [],
        onOpgeslagen: (nieuw) => { t.oefeningen = nieuw; },
      });
    });
    v.querySelectorAll('[data-tbewerk]').forEach(b => b.onclick = () => {
      const t = trainingen.find(x => x.id === b.dataset.tbewerk);
      modalBewerkTraining(t, teams);
    });
    v.querySelectorAll('[data-tshare]').forEach(b => b.onclick = () => {
      const t = trainingen.find(x => x.id === b.dataset.tshare);
      const tekst = `Training ${t.titel || ''}\n${t.week || ''}\n${t.url}`;
      window.open('https://wa.me/?text=' + encodeURIComponent(tekst), '_blank');
    });
    v.querySelectorAll('[data-tweg]').forEach(b => b.onclick = async () => {
      const t = trainingen.find(x => x.id === b.dataset.tweg);
      if (!confirm(`Training "${t.titel || t.bestandsnaam}" verwijderen?`)) return;
      try { if (t.path) await deleteObject(sRef(storage, t.path)); } catch(e){}
      await deleteDoc(doc(db,'trainingen',t.id));
      meld('Training verwijderd'); renderClub();
    });
  }
  if (tab === 'videos'){
    v.querySelectorAll('[data-vbouw]').forEach(b => b.onclick = () => {
      S.clubVideoBouw = b.dataset.vbouw; renderClub();
    });
    v.querySelector('#videoToevoegen').onclick = () => modalNieuweVideo(teams, S.clubVideoBouw);
    const vUpKnop = v.querySelector('#videoUpload');
    const vUpInput = v.querySelector('#videoFile');
    if (vUpKnop && vUpInput){
      vUpKnop.onclick = () => vUpInput.click();
      vUpInput.onchange = e => {
        const file = e.target.files[0]; if (!file) return;
        modalUploadVideo(file, teams, S.clubVideoBouw);
      };
    }
    v.querySelectorAll('[data-vbewerk]').forEach(b => b.onclick = () => {
      const vid = videos.find(x => x.id === b.dataset.vbewerk);
      modalBewerkVideo(vid, teams);
    });
    v.querySelectorAll('[data-vshare]').forEach(b => b.onclick = () => {
      const vid = videos.find(x => x.id === b.dataset.vshare);
      const tekst = `🎬 ${vid.titel || 'Video'}\n${vid.url}`;
      window.open('https://wa.me/?text=' + encodeURIComponent(tekst), '_blank');
    });
    v.querySelectorAll('[data-vweg]').forEach(b => b.onclick = async () => {
      const vid = videos.find(x => x.id === b.dataset.vweg);
      if (!confirm(`Video "${vid.titel || ''}" verwijderen?`)) return;
      try { if (vid.path) await deleteObject(sRef(storage, vid.path)); } catch(e){}
      await deleteDoc(doc(db,'videos',vid.id));
      meld('Video verwijderd'); renderClub();
    });
  }
  if (tab === 'documenten'){
    v.querySelectorAll('[data-doccat]').forEach(b => b.onclick = () => {
      S.clubDocCategorie = b.dataset.doccat; renderClub();
    });
    const knop = v.querySelector('#documentUpload');
    const input = v.querySelector('#documentFile');
    knop.onclick = () => input.click();
    input.onchange = e => {
      const file = e.target.files[0]; if (!file) return;
      modalNieuwDocument(file, teams, S.clubDocCategorie);
    };
    v.querySelectorAll('[data-ddownload]').forEach(b => b.onclick = () => window.open(b.dataset.ddownload, '_blank'));
    v.querySelectorAll('[data-dbewerk]').forEach(b => b.onclick = () => {
      const d = documenten.find(x => x.id === b.dataset.dbewerk);
      modalBewerkDocument(d, teams);
    });
    v.querySelectorAll('[data-dshare]').forEach(b => b.onclick = () => {
      const d = documenten.find(x => x.id === b.dataset.dshare);
      const tekst = `📄 ${d.titel || 'Document'}\n${d.url}`;
      window.open('https://wa.me/?text=' + encodeURIComponent(tekst), '_blank');
    });
    v.querySelectorAll('[data-dweg]').forEach(b => b.onclick = async () => {
      const d = documenten.find(x => x.id === b.dataset.dweg);
      if (!confirm(`Document "${d.titel || d.bestandsnaam}" verwijderen?`)) return;
      try { if (d.path) await deleteObject(sRef(storage, d.path)); } catch(e){}
      await deleteDoc(doc(db,'documenten',d.id));
      meld('Document verwijderd'); renderClub();
    });
  }
  if (tab === 'berichten'){
    const knop = v.querySelector('#nieuwBericht');
    if (knop) knop.onclick = () => modalNieuwBericht(teams);
    v.querySelectorAll('[data-bewerk-bericht]').forEach(b => b.onclick = () => {
      const ber = (S.clubBerichten||[]).find(x => x.id === b.dataset.bewerkBericht);
      modalNieuwBericht(teams, ber);
    });
    v.querySelectorAll('[data-verwijder-bericht]').forEach(b => b.onclick = async () => {
      const ber = (S.clubBerichten||[]).find(x => x.id === b.dataset.verwijderBericht);
      if (!confirm(`Bericht "${ber?.titel || ''}" verwijderen?`)) return;
      await deleteDoc(doc(db,'berichten',b.dataset.verwijderBericht));
      meld('Bericht verwijderd'); renderClub();
    });
  }
  if (tab === 'dash-overzicht' || tab === 'dash-gebruik' || tab === 'dash-navigatie'){
    const sortBtn = v.querySelector('#dashSort');
    if (sortBtn) sortBtn.onclick = () => {
      S.clubDashSort = (S.clubDashSort ?? 'desc') === 'desc' ? 'asc' : 'desc';
      renderClub();
    };
    v.querySelectorAll('[data-dash-team]').forEach(tr => tr.onclick = async () => {
      (await teamsModule()).openTeam(tr.dataset.dashTeam);
    });
    v.querySelectorAll('[data-periode]').forEach(b => b.onclick = () => {
      S.clubDashPeriode = b.dataset.periode; renderClub();
    });
    v.querySelectorAll('[data-functieperiode]').forEach(b => b.onclick = () => {
      S.clubGebruikPeriode = b.dataset.functieperiode; renderClub();
    });
    v.querySelectorAll('[data-gebruik-cat]').forEach(kop => kop.onclick = () => {
      kop.closest('.gebruik-cat').classList.toggle('open');
    });
    v.querySelectorAll('[data-gebruik-wie]').forEach(t => t.onclick = e => {
      e.stopPropagation();
      const func = t.closest('.gebruik-func');
      const open = func.classList.toggle('open');
      t.textContent = open ? 'sluit' : 'wie';
    });
    v.querySelectorAll('[data-gebruik-meer]').forEach(b => b.onclick = () => {
      const rest = b.parentElement.querySelector('.gebruik-cat-rest');
      if (rest){ rest.style.display = 'block'; b.style.display = 'none'; }
    });
    // inklapbare dashboard-secties (aandacht, statistieken) — puur CSS-toggle,
    // stand onthouden zodat een re-render (periode wisselen) hem niet dichtklapt
    v.querySelectorAll('[data-dash-inklap]').forEach(kop => kop.onclick = () => {
      const blok = kop.closest('.dash-inklap');
      const open = blok.classList.toggle('open');
      blok.classList.toggle('dicht', !open);
      if (kop.dataset.dashInklap === 'aandacht') S.clubAandachtOpen = open;
      if (kop.dataset.dashInklap === 'stats')    S.clubStatsOpen = open;
      if (kop.dataset.dashInklap === 'nav')      S.clubNavOpen = open;
    });
    v.querySelectorAll('[data-navmodus]').forEach(b => b.onclick = () => { S.clubNavModus = b.dataset.navmodus; renderClub(); });
    const btnAlleGebr = v.querySelector('#btnAlleGebruikers');
    if (btnAlleGebr) btnAlleGebr.onclick = () => { S.clubAlleGebruikersOpen = !S.clubAlleGebruikersOpen; renderClub(); };
  }
  if (tab === 'instel'){
    v.querySelectorAll('[data-instel-tab]').forEach(b => b.onclick = () => { S._clubInstelTab = b.dataset.instelTab; hertekenClub(); });
    const slAlles = v.querySelector('#slAlles');
    if (slAlles) slAlles.onclick = () => { S._clubSlAlles = !S._clubSlAlles; hertekenClub(); };
    v.querySelectorAll('[data-sl-koppel]').forEach(b => b.onclick = () => { S._cbTeam = b.dataset.slKoppel; S._cbUitnodig = null; naarClubTab('teambeheer'); });
    const nieuwSeizoenBtn = v.querySelector('#btnNieuwSeizoen');
    if (nieuwSeizoenBtn) nieuwSeizoenBtn.onclick = () => modalNieuwSeizoen();
    const migreerBtn = v.querySelector('#migreerSeizoen');
    if (migreerBtn) migreerBtn.onclick = () => migreerSeizoenData(teams);
    // Clubbreed thema: 'donker'|'licht' forceren, of 'coachKiest' vrijlaten.
    // Wegschrijven naar het clubdocument; de seizoen-listener bij elke coach
    // pikt de wijziging live op en past het thema toe (clubdwang overschrijft
    // de persoonlijke voorkeur). De admin ziet direct het resultaat via de
    // eigen listener → renderClub.
    v.querySelectorAll('#clubThemaModus [data-thema-modus]').forEach(b => b.onclick = async () => {
      const modus = b.dataset.themaModus;
      if (S.club.themaModus === modus || (!S.club.themaModus && modus === 'coachKiest')){
        // al actief — alleen visueel bevestigen
        v.querySelectorAll('#clubThemaModus [data-thema-modus]').forEach(x =>
          x.classList.toggle('gekozen', x === b));
        return;
      }
      v.querySelectorAll('#clubThemaModus [data-thema-modus]').forEach(x =>
        x.classList.toggle('gekozen', x === b));
      try {
        await updateDoc(doc(db,'clubs',S.clubId), { themaModus: modus });
        S.club.themaModus = modus;
        const naam = modus === 'donker' ? 'Alleen donker'
                   : modus === 'licht'  ? 'Alleen licht'
                   : modus === 'lichtDefault' ? 'Standaard licht'
                   : 'Coach mag kiezen';
        meld('Thema voor de hele club: ' + naam);
      } catch(e){
        meld('Opslaan mislukt: ' + (e.code || e.message));
      }
    });
    const kopLink = v.querySelector('#kopieerClubLink');
    if (kopLink) kopLink.onclick = async () => {
      try { await navigator.clipboard.writeText($('#clubLink').textContent); meld('Link gekopieerd'); }
      catch { meld('Link: ' + $('#clubLink').textContent); }
    };
    // Sportlink Client ID (clubbreed) opslaan
    const clientIdBtn = v.querySelector('#clientIdOpslaan');
    if (clientIdBtn) clientIdBtn.onclick = async () => {
      const input = v.querySelector('#clientIdInput');
      const waarde = (input.value || '').trim();
      if (!waarde) return meld('Vul eerst een Client ID in');
      // Client ID's zijn korte alfanumerieke codes (bv. oEGJY6X0n9).
      if (!/^[A-Za-z0-9]{6,}$/.test(waarde)) return meld('Dat lijkt geen geldige Client ID');
      clientIdBtn.disabled = true; clientIdBtn.textContent = '...';
      try {
        await updateDoc(doc(db,'clubs',S.clubId), { sportlinkClientId: waarde });
        S.club.sportlinkClientId = waarde;
        meld('Client ID opgeslagen: klik op “Sync nu” om op te halen');
        renderClub();
      } catch(e){
        clientIdBtn.disabled = false; clientIdBtn.textContent = 'Opslaan';
        meld('Opslaan mislukt: ' + (e.code || e.message));
      }
    };
    // handmatige sync nu
    const syncBtn = v.querySelector('#syncNu');
    if (syncBtn) syncBtn.onclick = async () => {
      syncBtn.disabled = true; const orig = syncBtn.textContent; syncBtn.textContent = 'Bezig met synchroniseren...';
      try {
        const fn = httpsCallable(functions, 'syncNu');
        const res = await fn({ clubId: S.clubId });
        const n = res.data?.totaalWedstrijden ?? 0;
        meld(`Sync klaar — ${n} wedstrijd${n===1?'':'en'} verwerkt`);
        renderClub();
      } catch(e){
        syncBtn.disabled = false; syncBtn.textContent = orig;
        meld('Sync mislukt: ' + (e.message || e.code || 'onbekende fout'));
      }
    };
    const wegClub = v.querySelector('#verwijderClub');
    if (wegClub) wegClub.onclick = async () => {
      if (!confirm('Club opheffen? Teams en trainingen blijven bestaan, maar zijn niet meer aan deze club gekoppeld.')) return;
      await deleteDoc(doc(db,'clubs',S.clubId));
      verlaatClubView();
    };
  }
}

/* ==================== UITNODIGEN ==================== */
export function modalUitnodig(team){
  const link = location.origin + location.pathname + '?team=' + team.code;
  openModal(`
    <h2>Coach uitnodigen voor ${esc(team.naam)}</h2>
    <p class="u-t-md u-zacht u-mb-sm">Stuur deze persoonlijke link naar de coach. Hij of zij klikt erop, logt in met e-mail of Google en zit direct in dit team.</p>
    <div class="uitnodig-link" id="uitnodigLink">${esc(link)}</div>
    <div class="rij u-mt-sm">
      <button class="knop vol" id="mUitnodigKopieer">Link kopiëren</button>
      <button class="knop fluo vol" id="mUitnodigWa"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 20l1.3-3.9A7.5 7.5 0 1 1 8.1 18.7z"/><path d="M9 9.2c.2-.5.4-.5.7-.5h.5c.2 0 .4 0 .6.5l.7 1.6c.1.2 0 .4-.1.5l-.5.6c-.1.1-.2.3-.1.5a5 5 0 0 0 2.4 2.2c.2.1.4 0 .5-.1l.5-.6c.1-.2.3-.2.5-.1l1.6.8c.2.1.3.3.3.5v.5c0 .5-.4.9-.9 1a3 3 0 0 1-1.5 0 8.4 8.4 0 0 1-5.2-5c-.2-.6-.4-1.3-.3-1.9z"/></svg> WhatsApp</button>
    </div>
    <p class="u-t-xs u-zacht u-mt-sm">Of geef de teamcode mondeling door: <b>${esc(team.code)}</b></p>`);
  $('#mUitnodigKopieer').onclick = async () => {
    try { await navigator.clipboard.writeText(link); meld('Link gekopieerd'); }
    catch { meld('Link: ' + link); }
  };
  $('#mUitnodigWa').onclick = () => {
    const tekst = `Je bent uitgenodigd als coach voor ${team.naam}. Open deze link en log in met e-mail of Google:\n${link}`;
    window.open('https://wa.me/?text=' + encodeURIComponent(tekst), '_blank');
  };
}

function modalAlleLinks(teams){
  const link = t => location.origin + location.pathname + '?team=' + t.code;
  openModal(`
    <h2><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="17.8" cy="6" r="2.6"/><circle cx="6.2" cy="12" r="2.6"/><circle cx="17.8" cy="18" r="2.6"/><path d="M15.4 7.2 8.6 10.8"/><path d="M8.6 13.2 15.4 16.8"/></svg> Alle uitnodigingslinks</h2>
    <p class="u-t-sm u-zacht u-mb-md">Per team kun je hier snel de uitnodiging delen. Aantal gekoppelde coaches staat erbij.</p>
    <div class="u-mb-md" style="max-height:60vh;overflow-y:auto">
      ${teams.map(t => `
        <div class="link-rij">
          <div class="link-rij-kop">
            <div><div class="titel">${esc(t.naam)}</div>
              <div class="meta">${Object.keys(t.leden||{}).length} coach(es)<span class="sep" aria-hidden="true"></span>code ${esc(t.code)}</div></div>
          </div>
          <div class="uitnodig-link">${esc(link(t))}</div>
          <div class="link-actie u-mt-xs">
            <button data-kopieer="${esc(link(t))}">Kopieer</button>
            <button class="wa" data-wa="${t.id}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 20l1.3-3.9A7.5 7.5 0 1 1 8.1 18.7z"/><path d="M9 9.2c.2-.5.4-.5.7-.5h.5c.2 0 .4 0 .6.5l.7 1.6c.1.2 0 .4-.1.5l-.5.6c-.1.1-.2.3-.1.5a5 5 0 0 0 2.4 2.2c.2.1.4 0 .5-.1l.5-.6c.1-.2.3-.2.5-.1l1.6.8c.2.1.3.3.3.5v.5c0 .5-.4.9-.9 1a3 3 0 0 1-1.5 0 8.4 8.4 0 0 1-5.2-5c-.2-.6-.4-1.3-.3-1.9z"/></svg> WhatsApp</button>
          </div>
        </div>`).join('')}
    </div>
    <button class="knop vol" id="mLinksKopieerAlle"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="5" y="4.5" width="14" height="16" rx="2.2"/><path d="M9 3.2h6v3H9z"/><path d="M8.8 11.4h6.4"/><path d="M8.8 15.4h4"/></svg> Kopieer alles als lijst</button>`);
  $$('#modalInhoud [data-kopieer]').forEach(b => b.onclick = async () => {
    try { await navigator.clipboard.writeText(b.dataset.kopieer); meld('Link gekopieerd'); }
    catch { meld('Kon niet kopiëren'); }
  });
  $$('#modalInhoud [data-wa]').forEach(b => b.onclick = () => {
    const t = teams.find(x => x.id === b.dataset.wa);
    const tekst = `Je bent uitgenodigd als coach voor ${t.naam}. Open deze link en log in met e-mail of Google:\n${link(t)}`;
    window.open('https://wa.me/?text=' + encodeURIComponent(tekst), '_blank');
  });
  $('#mLinksKopieerAlle').onclick = async () => {
    const tekst = teams.map(t => `${t.naam}: ${link(t)}`).join('\n');
    try { await navigator.clipboard.writeText(tekst); meld('Alle links gekopieerd'); }
    catch { meld('Kon niet kopiëren'); }
  };
}

/* ==================== PDF-IMPORT TEAMS ==================== */
function detecteerCategorie(teamnaam){
  const m = teamnaam.toUpperCase().match(/^(JO|MO)(\d+)/);
  if (!m) return null;
  const cat = m[1] + m[2];
  return catInfo(cat) ? cat : null;
}
function voornaam(volledig){ return volledig.trim().split(/\s+/)[0]; }

async function parseTeamsUitPDF(file){
  const url = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.min.mjs';
  const workerUrl = 'https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.worker.min.mjs';
  const pdfjs = await import(url);
  pdfjs.GlobalWorkerOptions.workerSrc = workerUrl;
  const buf = await file.arrayBuffer();
  const pdf = await pdfjs.getDocument({data: buf}).promise;

  const teams = [];
  const teamRegex = /^(JO|MO)\d+(-\d+)?(JM)?$/i;
  const skipRegex = /^(UITLEG|COÖRDINATOREN|MINI'S|JEUGD|2025|2026)$/i;

  for (let p = 1; p <= pdf.numPages; p++){
    const page = await pdf.getPage(p);
    const tc = await page.getTextContent();
    const items = tc.items.filter(it => it.str.trim()).map(it => ({
      str: it.str, x: it.transform[4], y: it.transform[5], w: it.width || 0,
    }));
    const headers = items.filter(it => teamRegex.test(it.str.trim()));

    for (const h of headers){
      const kolom = items.filter(it => Math.abs(it.x - h.x) < 60 && it.y < h.y && it.y > 30);
      const perRegel = {};
      for (const it of kolom){
        const k = Math.round(it.y);
        (perRegel[k] ||= []).push(it);
      }
      const regels = Object.keys(perRegel).map(Number).sort((a,b) => b - a);
      const spelers = [];
      for (const y of regels){
        const stk = perRegel[y].sort((a,b) => a.x - b.x);
        let s = '';
        for (let i = 0; i < stk.length; i++){
          if (i > 0){
            const vorigEnd = stk[i-1].x + stk[i-1].w;
            const gap = stk[i].x - vorigEnd;
            s += gap > 1.5 ? ' ' : '';
          }
          s += stk[i].str;
        }
        s = s.trim();
        if (/BEGELEIDING|VACATURE/i.test(s)) break;
        if (teamRegex.test(s)) break;
        if (s.length < 2) continue;
        if (skipRegex.test(s)) continue;
        spelers.push(s);
      }
      if (spelers.length){
        teams.push({
          naam: h.str.trim().toUpperCase(),
          categorie: detecteerCategorie(h.str),
          spelers: spelers.map(voornaam),
        });
      }
    }
  }
  return teams;
}

function modalImporteerPDF(){
  openModal(`
    <h2><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg> Teams importeren uit PDF</h2>
    <p class="u-t-sm u-zacht u-mb-sm">Upload een PDF met de teamindeling. De app leest de teamnamen en spelersnamen uit, daarna kun je alles controleren voordat je de teams aanmaakt.</p>
    <label class="upload-knop" for="mPDFFile"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M6.6 3.4h7L18.6 8.4v12.2h-12z"/><path d="M13.6 3.4V8.4h5"/></svg> Kies PDF-bestand
      <input type="file" id="mPDFFile" accept="application/pdf" style="display:none"></label>
    <div id="mPDFStatus" class="u-t-sm u-zacht u-tc"></div>`);
  $('#mPDFFile').onchange = async e => {
    const file = e.target.files[0]; if (!file) return;
    $('#mPDFStatus').textContent = 'PDF wordt gelezen, even geduld...';
    try {
      const teams = await parseTeamsUitPDF(file);
      if (!teams.length){
        $('#mPDFStatus').textContent = 'Geen teams gevonden in deze PDF. Controleer of de teamnamen in de vorm JO11-1, MO13-1 e.d. erin staan.';
        return;
      }
      sluitModal();
      modalImportPreview(teams);
    } catch (err) {
      console.error(err);
      $('#mPDFStatus').textContent = 'Kon de PDF niet lezen: ' + err.message;
    }
  };
}

function modalImportPreview(geparseerd){
  const teams = geparseerd.map(t => ({...t, aan: true, spelers: [...t.spelers]}));
  const render = () => {
    const blokjes = teams.map((t, ti) => {
      const tellingen = {};
      t.spelers.forEach(s => tellingen[s.toLowerCase()] = (tellingen[s.toLowerCase()]||0) + 1);
      return `
        <div class="preview-team ${t.aan?'':'uit'}" data-ti="${ti}">
          <div class="preview-team-kop">
            <input type="checkbox" data-aan="${ti}" ${t.aan?'checked':''}>
            <span class="naam">${esc(t.naam)}</span>
            <span class="meta">${t.categorie ? esc(t.categorie) : 'GEEN CAT.'}</span>
            <span class="meta">${t.spelers.length}</span>
          </div>
          <div class="preview-spelers">
            ${t.spelers.map((s,si) => `
              <span class="speler ${tellingen[s.toLowerCase()]>1?'dubbel':''}" title="${tellingen[s.toLowerCase()]>1?'Dubbele voornaam, pas aan om uniek te maken':''}">
                <input data-ti="${ti}" data-si="${si}" value="${esc(s)}" size="${Math.max(s.length, 5)}">
                <button data-weg="${ti}-${si}" title="Verwijderen">✕</button>
              </span>`).join('')}
            <span class="speler toevoeg" data-toevoeg="${ti}">+ Speler</span>
          </div>
        </div>`;
    }).join('');
    $('#mPrevInhoud').innerHTML = blokjes;
    const aantalAan = teams.filter(t => t.aan).length;
    const aantalSp  = teams.filter(t => t.aan).reduce((a,t) => a + t.spelers.length, 0);
    $('#mPrevSamenvat').textContent = `${aantalAan} team${aantalAan===1?'':'s'}, ${aantalSp} speler${aantalSp===1?'':'s'} worden aangemaakt`;
    koppelPreview();
  };
  const koppelPreview = () => {
    $$('[data-aan]').forEach(c => c.onchange = () => { teams[Number(c.dataset.aan)].aan = c.checked; render(); });
    $$('.preview-spelers input').forEach(i => i.oninput = () => {
      teams[Number(i.dataset.ti)].spelers[Number(i.dataset.si)] = i.value;
    });
    $$('.preview-spelers input').forEach(i => i.onblur = () => { i.size = Math.max(i.value.length, 5); });
    $$('[data-weg]').forEach(b => b.onclick = () => {
      const [ti, si] = b.dataset.weg.split('-').map(Number);
      teams[ti].spelers.splice(si,1); render();
    });
    $$('[data-toevoeg]').forEach(b => b.onclick = () => {
      const ti = Number(b.dataset.toevoeg);
      const naam = prompt('Voornaam:');
      if (naam && naam.trim()){ teams[ti].spelers.push(naam.trim()); render(); }
    });
  };
  openModal(`
    <h2>Controleren & aanpassen</h2>
    <p class="u-t-sm u-zacht">Vink teams uit die je niet wilt aanmaken, klik op een naam om aan te passen, en let op de <span class="u-c-warn u-fw-6">rood gekleurde</span> dubbele voornamen.</p>
    <div id="mPrevSamenvat" class="u-t-sm u-fw-6 u-c-accent u-tc" style="margin:var(--space-sm) 0"></div>
    <div id="mPrevInhoud" class="u-mb-md" style="max-height:50vh;overflow-y:auto"></div>
    <button class="knop vol" id="mPrevOk">✓ Teams aanmaken</button>
    <button class="knop licht vol u-mt-xs" id="mPrevAnnuleer" >Annuleren</button>`);
  render();
  $('#mPrevAnnuleer').onclick = sluitModal;
  $('#mPrevOk').onclick = async () => {
    const teLijken = teams.filter(t => t.aan && t.spelers.length);
    if (!teLijken.length) return meld('Geen teams om aan te maken');
    $('#mPrevOk').disabled = true;
    $('#mPrevOk').textContent = 'Bezig...';
    let aangemaakt = 0;
    const afk = clubAfkorting(S.club.naam);
    const gebruikt = [...(S.clubTeams||[]).map(t => t.code)].filter(Boolean);
    for (const t of teLijken){
      const cat = t.categorie || 'JO11';
      const format = catInfo(cat).format;
      const geslacht = cat.startsWith('M') ? 'm' : 'j';
      const code = teamCode(t.naam, afk, gebruikt);
      gebruikt.push(code);
      const teamRef = await addDoc(collection(db,'teams'), {
        naam: t.naam, categorie: cat, geslacht, format, code,
        bouw: bouwVanCategorie(cat),
        club: S.clubId, clubNaam: S.club.naam,
        leden: {[S.user.uid]: true},
        ledenInfo: {[S.user.uid]: {naam: S.user.displayName || S.user.email}},
        gemaakt: serverTimestamp(),
      });
      await updateDoc(doc(db,'clubs',S.clubId), {['teams.'+teamRef.id]: true});
      for (let i = 0; i < t.spelers.length; i++){
        await addDoc(collection(db,'teams',teamRef.id,'spelers'), {naam: t.spelers[i], nummer: i+1});
      }
      aangemaakt++;
    }
    sluitModal();
    meld(`✓ ${aangemaakt} team${aangemaakt===1?'':'s'} aangemaakt`);
    renderClub();
  };
}

/* ==================== TRAININGEN ==================== */
function isoWeek(d){
  const date = new Date(d.getTime());
  date.setHours(0,0,0,0);
  date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
  const week1 = new Date(date.getFullYear(), 0, 4);
  return 1 + Math.round(((date - week1) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
}

/* [20261013a] Eén ingang voor alles wat op het uploadvlak landt. Een zip, of
   meerdere PDF's met blok-namen ("Blok 2 - Week 1 - Training 1"), gaat naar
   de blokplanning in training-plan.js; al het andere werkt precies als
   voorheen (één PDF → losse upload, meerdere → verdelen per groep). */
function blokCtx(teams, trainingen){
  return {
    teams, trainingen,
    groepen: trainingsGroepen(),
    bouwGroepen: bouwGroepen(teams),
    renderClub: () => renderClub(),
    oudeFlow: lijst => lijst.length === 1 ? modalNieuweTraining(lijst[0], teams) : modalMeerdereTrainingen(lijst, teams),
  };
}

/* "Groep D · 10 teams" als de selectie precies een trainingsgroep is, anders namen of aantal. */
function teamsTekstVan(ids, teams){
  const set = new Set(ids);
  const g = trainingsGroepen().find(x => {
    const gi = (x.teams || []).filter(id => teams.some(t => t.id === id));
    return gi.length && gi.length === set.size && gi.every(id => set.has(id));
  });
  if (g) return `${g.naam || ('Groep ' + g.id)}, ${ids.length} team${ids.length === 1 ? '' : 's'}`;
  if (ids.length <= 3) return ids.map(id => teams.find(t => t.id === id)?.naam || '?').join(', ');
  return `${ids.length} teams`;
}

function uploadGekozen(files, teams, trainingen){
  const pdfs = files.filter(f => f.type === 'application/pdf' || /\.pdf$/i.test(f.name));
  const oudeFlow = lijst => lijst.length === 1 ? modalNieuweTraining(lijst[0], teams) : modalMeerdereTrainingen(lijst, teams);
  if (isBlokUpload(files)) return startBlokUpload(files, blokCtx(teams, trainingen));
  if (!pdfs.length) return meld('Alleen PDF- of zip-bestanden kunnen hier worden toegevoegd');
  oudeFlow(pdfs);
}

/* ==================== MEERDERE TRAININGEN TEGELIJK ====================
   De club-admin krijgt wekelijks een setje PDF's binnen en wil ze in één keer
   verdelen. Dit scherm laat per bestand een trainingsgroep kiezen (met een gok
   op basis van de bestandsnaam, bv. "…-B.pdf" → groep B) en verwerkt ze daarna
   één voor één via de bestaande AI-pijplijn. Elk bestand krijgt zijn normale
   preview zodat de AI-controle behouden blijft; na delen (of overslaan) rolt
   het volgende bestand automatisch door. */
function modalMeerdereTrainingen(files, teams){
  const groepen = trainingsGroepen();
  const weekNr = isoWeek(new Date());
  // per bestand: gekozen groep-id (init = gok uit naam)
  const raad = (naam) => {
    const m = naam.match(/[-_ ]([a-zA-Z])(?:[-_. ]|$)/);
    if (!m) return '';
    const l = m[1].toUpperCase();
    return groepen.some(g => g.id === l) ? l : '';
  };
  const keuze = files.map(f => raad(f.name));
  let mmModel = 'standaard';                 // [20261013c] AI-model voor deze upload
  let mmZicht = '';                          // [20261013f] zichtbaar vanaf (leeg = meteen)

  if (!groepen.length){
    // zonder groepen heeft de multi-flow weinig zin: bied beheer aan, of val
    // terug op het één-voor-één verwerken.
    openModal(`
      <h2>${files.length} trainingen uploaden</h2>
      <p class="u-t-sm u-zacht u-lh-ruim u-mb-md">Je koos ${files.length} bestanden. Stel eerst trainingsgroepen in, dan kun je ze in één keer per groep verdelen. Zonder groepen loop je ze los langs.</p>
      <button class="knop vol" id="mmNaarGroepen">Trainingsgroepen instellen</button>
      <button class="knop licht u-mt-xs" id="mmLosLangs" >Toch één voor één (met teams aanvinken)</button>`);
    $('#mmNaarGroepen').onclick = () => { sluitModal(); modalTrainingsGroepen(teams); };
    $('#mmLosLangs').onclick = () => verwerkRij(0, /*zonderGroep*/true);
    return;
  }

  const teken = () => {
    const rijen = files.map((f,i) => {
      const opties = `<option value="">—</option>` + groepen.map(g =>
        `<option value="${esc(g.id)}" ${keuze[i]===g.id?'selected':''}>${esc(g.id)}<span class="sep" aria-hidden="true"></span>${esc(g.naam || ('Groep '+g.id))}</option>`).join('');
      const sub = keuze[i] ? `herkend als groep ${esc(keuze[i])}` : 'kies een groep';
      return `
        <div class="mm-rij">
          <div class="mm-ico">PDF</div>
          <div class="mm-info">
            <div class="mm-naam">${esc(f.name)}</div>
            <div class="mm-sub">${(f.size/1024).toFixed(0)} KB<span class="sep" aria-hidden="true"></span>${sub}</div>
          </div>
          <select class="mm-select" data-i="${i}">${opties}</select>
        </div>`;
    }).join('');
    const zonder = keuze.filter(k => !k).length;
    const teamsTotaal = new Set();
    keuze.forEach(k => { if (k) (groepen.find(g=>g.id===k)?.teams||[]).forEach(t => teamsTotaal.add(t)); });
    const samenv = zonder
      ? `<div class="mm-samenv warn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg> ${zonder} bestand${zonder===1?'':'en'} ${zonder===1?'heeft':'hebben'} nog geen groep</div>`
      : `<div class="mm-samenv ok">✓ ${files.length} trainingen → ${teamsTotaal.size} teams in totaal</div>`;

    openModal(`
      <h2>${files.length} trainingen verdelen</h2>
      <p class="u-t-sm u-zacht u-lh-ruim u-mb-sm">Kies per bestand de trainingsgroep. De app verwerkt ze daarna één voor één, je ziet van elke training nog de AI-preview.</p>
      <div class="veldgroep"><label>Week / periode (voor alle)</label>
        <input class="invoer" id="mmWeek" value="Week ${weekNr}" autocomplete="off"></div>
      <div class="mm-lijst">${rijen}</div>
      ${samenv}
      <div class="veldgroep"><label for="mmZicht">Zichtbaar voor het team vanaf</label>
      <input class="invoer" type="date" id="mmZicht" value="${esc(mmZicht)}">
      <p class="bp-hint">Leeg laten = meteen zichtbaar. Tot die datum zie jij hem wel in het beheer, coaches nog niet.</p></div>
      ${htmlModelKeuze('mmModel', mmModel)}
      <button class="knop vol" id="mmStart" ${zonder?'disabled':''}>Verwerken en verdelen</button>
      <button class="link" id="mmGroepen" style="display:block;margin:var(--space-sm) auto 0"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.1"/><path d="M12 3.2 13.6 5.4l2.6-.6 1 2.5 2.6.7-.5 2.6L21 12l-1.7 1.4.5 2.6-2.6.7-1 2.5-2.6-.6L12 20.8l-1.6-2.2-2.6.6-1-2.5-2.6-.7.5-2.6L3 12l1.7-1.4-.5-2.6 2.6-.7 1-2.5 2.6.6z"/></svg> Groepen beheren</button>`);

    $$('.mm-select').forEach(s => s.onchange = () => { keuze[+s.dataset.i] = s.value; teken(); });
    $('#mmModel').onchange = e => { mmModel = e.target.value; };
    $('#mmZicht').onchange = e => { mmZicht = e.target.value; };
    $('#mmGroepen').onclick = () => { sluitModal(); modalTrainingsGroepen(teams); };
    $('#mmStart').onclick = async () => {
      if (keuze.some(k => !k)) return meld('Kies voor elk bestand een groep');
      // [20261013b] alles in één keer naar de wachtrij; verwerken loopt op de achtergrond
      const wk = week();
      const items = [];
      files.forEach((f, i) => {
        const g = groepen.find(x => x.id === keuze[i]);
        const tms = (g?.teams || []).filter(id => teams.some(t => t.id === id));
        if (!tms.length){ meld(`Groep ${keuze[i]} heeft geen teams — ${f.name} overgeslagen`); return; }
        items.push({ file: f, titel: `Week ${weekNr} - ${f.name.replace(/\.pdf$/i,'')}`, week: wk, teams: tms, aiModel: mmModel,
          ...(mmZicht ? { extra: { zichtbaarVanaf: mmZicht } } : {}) });
      });
      if (!items.length) return;
      $('#mmStart').disabled = true;
      await voegToeAanWachtrij({ naam: `${items.length} training${items.length===1?'':'en'}, ${wk}`, teamsTxt: 'per trainingsgroep', items });
      sluitModal();
      meld(`${items.length} training${items.length===1?'':'en'} in de wachtrij, voortgang bovenaan Trainingen`);
      renderClub();
    };
  };

  // verwerk bestand i, ga daarna door naar i+1
  const week = () => ($('#mmWeek')?.value || `Week ${weekNr}`).trim();
  let vasteWeek = null;
  function verwerkRij(i, zonderGroep){
    if (vasteWeek === null) vasteWeek = week();   // vastleggen vóór de modal wisselt
    if (i >= files.length){
      sluitModal(); renderClub();
      meld(`${files.length} training${files.length===1?'':'en'} in de wachtrij, voortgang bovenaan Trainingen`);
      return;
    }
    const f = files[i];
    const volgende = () => verwerkRij(i+1, zonderGroep);
    const meta = {
      titel: `Week ${weekNr} - ${f.name.replace(/\.pdf$/i,'')}`,
      week: vasteWeek,
      onKlaar: volgende,
      batchInfo: { huidig: i+1, totaal: files.length },
    };
    if (zonderGroep){
      // los langs: normale team-picker per bestand (met chips), maar met
      // doorrol-callback zodra gedeeld is.
      modalNieuweTraining(f, teams, null, meta);
    } else {
      const g = groepen.find(x => x.id === keuze[i]);
      meta.teams = (g?.teams || []).filter(id => teams.some(t => t.id === id));
      if (!meta.teams.length){
        meld(`Groep ${keuze[i]} heeft geen teams, bestand overgeslagen`);
        return volgende();
      }
      startTrainingVerwerking(f, meta);
    }
  }

  teken();
}

function modalNieuweTraining(file, teams, voorBouw = null, batchMeta = null){
  const weekNr = isoWeek(new Date());
  const groepen = trainingsGroepen();
  // teams groeperen per bouw
  // [20260925d] per standaardbouw + eigen bouw (teams die alleen daar zitten)
  const groepHtml = bouwGroepen(teams).map(b => {
    const lijst = b.teams;
    if (!lijst.length) return '';
    return `
      <div class="u-t-xs u-fw-7 u-zacht" style="letter-spacing:.5px;text-transform:uppercase;margin:var(--space-sm) 0 var(--space-xs)">${esc(b.naam)}</div>
      <div class="team-chip-kies">
        ${lijst.map(t => {
          const aan = voorBouw ? b.id === voorBouw : false;
          return `<label data-pid="${t.id}" class="${aan?'aan':''}"><input type="checkbox" data-tid="${t.id}" ${aan?'checked':''}><span>${esc(t.naam)}</span></label>`;
        }).join('')}
      </div>`;
  }).join('');
  const batchBanner = batchMeta?.batchInfo
    ? `<div class="mm-samenv ok" style="margin:-2px 0 var(--space-sm)">Bestand ${batchMeta.batchInfo.huidig} van ${batchMeta.batchInfo.totaal}</div>` : '';
  const startTitel = batchMeta?.titel || `Week ${weekNr} - training 1`;
  const startWeek  = batchMeta?.week  || `Week ${weekNr}`;
  openModal(`
    <h2>Training uploaden</h2>
    ${batchBanner}
    <p class="u-t-sm u-zacht u-mb-sm">Bestand: <b>${esc(file.name)}</b> (${(file.size/1024).toFixed(0)} KB)</p>
    <div class="veldgroep"><label>Titel</label>
      <input class="invoer" id="mTrTitel" value="${esc(startTitel)}" autocomplete="off"></div>
    <div class="veldgroep"><label>Week / periode</label>
      <input class="invoer" id="mTrWeek" value="${esc(startWeek)}" autocomplete="off"></div>
    <div class="veldgroep"><label>Op welke trainingsdag?</label>
      <select class="invoer" id="mTrDag">
        <option value="">Automatisch (per team)</option>
        <option value="1">Maandag</option>
        <option value="2">Dinsdag</option>
        <option value="3">Woensdag</option>
        <option value="4">Donderdag</option>
        <option value="5">Vrijdag</option>
        <option value="6">Zaterdag</option>
        <option value="7">Zondag</option>
      </select>
      <p class="u-t-xs u-zacht u-mt-xs u-lh-ruim">Standaard neemt Cluppie de trainingsdagen van elk team (training 1 op de eerste dag, enz.). Kies je hier een vaste dag, dan geldt die voor álle teams die deze oefenstof krijgen.</p>
    </div>
    <div class="veldgroep"><label>Voor welke teams?</label>
      ${groepen.length ? `<div class="tr-groep-uitleg">Tik op een groep om alle teams in één keer te kiezen, of vink hieronder los aan.</div>${groepChipsHtml(groepen, teams)}` : ''}
      <div id="mTrTeams">
        ${teams.length ? groepHtml : '<p class="u-t-sm u-zacht">Maak eerst teams aan in deze club.</p>'}
      </div>
      <div class="rij u-mt-xs">
        <button class="knop licht klein" id="mTrAlle">Alle teams</button>
        <button class="knop licht klein" id="mTrGeen">Geen</button>
        ${groepen.length ? '<button class="knop licht klein" id="mTrGroepen"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.1"/><path d="M12 3.2 13.6 5.4l2.6-.6 1 2.5 2.6.7-.5 2.6L21 12l-1.7 1.4.5 2.6-2.6.7-1 2.5-2.6-.6L12 20.8l-1.6-2.2-2.6.6-1-2.5-2.6-.7.5-2.6L3 12l1.7-1.4-.5-2.6 2.6-.7 1-2.5 2.6.6z"/></svg> Groepen beheren</button>' : ''}
      </div>
    </div>
    <div class="veldgroep"><label for="mTrZicht">Zichtbaar voor het team vanaf</label>
      <input class="invoer" type="date" id="mTrZicht" value="">
      <p class="bp-hint">Leeg laten = meteen zichtbaar. Tot die datum zie jij hem wel in het beheer, coaches nog niet.</p></div>
    ${htmlModelKeuze('mTrModel', 'standaard')}
    <button class="knop vol" id="mTrOk">Uploaden en delen</button>`);
  const sync = () => $$('#mTrTeams label').forEach(l => l.classList.toggle('aan', l.querySelector('input').checked));
  $$('#mTrTeams input').forEach(c => c.onchange = sync);
  // Groep-chip: zet precies de teams van die groep aan (vervangt de selectie).
  $$('[data-groep]').forEach(chip => chip.onclick = () => {
    const g = groepen.find(x => x.id === chip.dataset.groep);
    if (!g) return;
    const wil = new Set(g.teams || []);
    $$('#mTrTeams input').forEach(c => c.checked = wil.has(c.dataset.tid));
    $$('.tr-groep-chip').forEach(x => x.classList.toggle('aan', x === chip));
    sync();
  });
  const mGrp = $('#mTrGroepen');
  if (mGrp) mGrp.onclick = () => { sluitModal(); modalTrainingsGroepen(teams); };
  $('#mTrAlle').onclick = () => { $$('#mTrTeams input').forEach(c => c.checked = true); $$('.tr-groep-chip').forEach(x => x.classList.remove('aan')); sync(); };
  $('#mTrGeen').onclick = () => { $$('#mTrTeams input').forEach(c => c.checked = false); $$('.tr-groep-chip').forEach(x => x.classList.remove('aan')); sync(); };
  $('#mTrOk').onclick = async () => {
    const gekozen = $$('#mTrTeams input').filter(c => c.checked).map(c => c.dataset.tid);
    if (!gekozen.length) return meld('Kies minstens één team');
    const titel = $('#mTrTitel').value.trim() || file.name;
    const week  = $('#mTrWeek').value.trim();
    const dagRaw = $('#mTrDag')?.value || '';
    const meta = { titel, week, teams: gekozen };
    if (dagRaw) meta.trainingsdag = parseInt(dagRaw, 10);        // vaste dag voor álle teams
    // [20261013b] naar de wachtrij: goedgekeurd door de AI-controle = meteen gedeeld,
    // afwijkers wachten bovenaan Trainingen. Het venster sluit meteen.
    // [20261013f] optionele zichtbaarheidsdatum (zelfde veld als de blokplanning)
    const zichtVanaf = ($('#mTrZicht')?.value || '').trim();
    const knop = $('#mTrOk'); if (knop){ knop.disabled = true; knop.textContent = 'In de wachtrij…'; }
    await voegToeAanWachtrij({ naam: titel, teamsTxt: teamsTekstVan(gekozen, teams), items: [{
      file, titel, week, teams: gekozen, ...(meta.trainingsdag ? { trainingsdag: meta.trainingsdag } : {}),
      aiModel: $('#mTrModel')?.value || 'standaard',
      ...(zichtVanaf ? { extra: { zichtbaarVanaf: zichtVanaf } } : {}),
    }] });
    if (batchMeta?.onKlaar){ batchMeta.onKlaar(); return; }   // doorrollen in batch (één voor één)
    sluitModal();
    meld('Training in de wachtrij, voortgang bovenaan Trainingen');
    renderClub();
  };
}

/* Schrijf inhoud in de training-modal met dezelfde vaste kopbalk + scrolbare
   body als openModal(). De losse schermen hieronder (verwerken, preview,
   alleen-PDF) vulden voorheen .modal rechtstreeks — maar .modal is een flex-
   kolom met overflow:hidden en verwacht een .modal-body die zelf scrolt. Zonder
   die wrapper liep de preview (diagrammen + oefeningtekst) buiten beeld en kon
   je niet scrollen. Deze helper zet de body altijd goed neer en geeft ook op
   deze schermen een sluitkruis. */
function zetTrainingModalInhoud(titel, bodyHtml){
  const mod = $('.modal'); if (!mod) return null;
  const kruis = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M6.5 6.5l11 11"/><path d="M17.5 6.5l-11 11"/></svg>';
  mod.innerHTML =
    '<div class="modal-kop"><h2>' + esc(titel) + '</h2>' +
    '<button type="button" class="modal-sluit" aria-label="Sluiten">' + kruis + '</button></div>' +
    '<div class="modal-body">' + bodyHtml + '</div>';
  const sl = mod.querySelector('.modal-sluit');
  if (sl) sl.onclick = () => sluitModal();
  return mod.querySelector('.modal-body');
}

/* ---------- AI-verwerking van een training-PDF ----------
   Draait binnen dezelfde modal: upload PDF + diagrammen naar Storage, laat de
   AI de tekst structureren, bereken de overeenkomst-score, en toon een preview
   met de keuze: zo delen / opnieuw genereren / alleen als PDF delen.
   De originele PDF wordt ALTIJD bewaard, ongeacht de keuze. */
async function startTrainingVerwerking(file, meta){
  const mod = $('.modal'); if (!mod) return;
  const ts = Date.now();
  const mapId = `${ts}-${Math.random().toString(36).slice(2, 8)}`;   // uniek, zie upload-wachtrij.js
  const veiligeNaam = file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
  const pdfPath = `clubs/${S.clubId}/trainingen/${mapId}/${veiligeNaam}`;

  const toonVerwerk = (stapjesHtml) => {
    zetTrainingModalInhoud('Training omzetten', `
      <div class="tr-verwerk">
        <div class="tr-spin"></div>
        <p>De app leest de PDF en maakt er een makkelijk leesbare weergave van voor je coaches.</p>
        <div class="tr-stapjes">${stapjesHtml}</div>
      </div>`);
  };
  const stap = (klaar, actief, rest) =>
    klaar.map(t=>`<div class="klaar">${t}</div>`).join('') +
    (actief?`<div class="actief">${actief}</div>`:'') +
    rest.map(t=>`<div>${t}</div>`).join('');

  try {
    const ai = await import('./training-ai.js?v=20261106h');

    toonVerwerk(stap([], 'PDF inlezen…', ['Diagrammen opslaan','Oefeningen structureren','Controleren']));
    const { paginas, diagramBlobs, bytes, aantalPaginas } = await ai.leesPdf(file);

    // originele PDF bewaren
    toonVerwerk(stap(['PDF ingelezen ('+aantalPaginas+' pagina’s)'], 'Origineel + diagrammen opslaan…', ['Oefeningen structureren','Controleren']));
    const pdfRef = sRef(storage, pdfPath);
    await uploadBytes(pdfRef, new Blob([bytes], {type:'application/pdf'}), {contentType:'application/pdf'});
    const pdfUrl = await getDownloadURL(pdfRef);
    const diagramUrls = await ai.uploadDiagrammen(S.clubId, mapId, diagramBlobs);

    // AI-structurering
    toonVerwerk(stap(['PDF ingelezen','Origineel + diagrammen opgeslagen'], 'Oefeningen structureren met AI…', ['Controleren']));
    let oefeningen, doelen;
    try {
      ({ oefeningen, doelen } = await ai.structureer(paginas));
      telGebruik('training_upload');
    } catch(e){
      console.error('[training-ai] structureren mislukt', e);
      return toonAlleenPdfKeuze(file, meta, { mapId, pdfPath, pdfUrl }, 'De automatische opmaak lukte niet. Je kunt de training wel gewoon als PDF delen.');
    }

    // overeenkomst-score (programmatisch)
    const origineleTekst = paginas.map(p=>p.tekst).join(' ');
    const score = ai.berekenScore(origineleTekst, oefeningen);

    toonPreview(file, meta, { mapId, pdfPath, pdfUrl, diagramUrls, oefeningen, doelen, score, paginas });
  } catch(e){
    console.error('[training-ai] verwerking mislukt', e);
    meld('Verwerking mislukt: staat Firebase Storage aan?');
    sluitModal();
  }
}

/* Preview-scherm met score + de drie keuzes. */
function toonPreview(file, meta, ctx){
  const mod = $('.modal'); if (!mod) return;
  const { score, oefeningen, diagramUrls } = ctx;
  const goed = score.dekkingPct >= 90 && score.verzonnenAantal <= 3;

  // Herkende trainingsdoelen (bewerkbaar). Los van de oefeningen; coaches krijgen
  // ze later als suggestie bij een wedstrijd in dezelfde week.
  const doelenNu = Array.isArray(ctx.doelen) ? ctx.doelen : [];
  const doelRij = (tekst) => `<div class="tr-doel-rij"><span class="stip"></span>`+
    `<input class="tr-doel-inp" value="${esc(tekst||'')}" placeholder="Trainingsdoel…" maxlength="80">`+
    `<span class="tr-doel-x" title="Verwijderen">✕</span></div>`;
  const doelenBlok = `
    <div class="tr-doelen" id="trDoelen">
      <div class="tr-doelen-kop"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.5"/><circle cx="12" cy="12" r="0.6" fill="currentColor" stroke="none"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3"/></svg> Herkende trainingsdoelen</div>
      <div class="tr-doelen-uitleg">Deze doelen zijn uit de oefenstof gehaald. Coaches zien ze als
        suggestie bij een wedstrijd in deze week. Kloppen ze niet? Pas ze aan of haal ze weg.</div>
      <div id="trDoelLijst">${doelenNu.map(doelRij).join('')}</div>
      <span class="tr-doel-toevoeg" id="trDoelAdd">＋ Doel toevoegen</span>
    </div>`;

  const scoreKaart = `
    <div class="tr-score ${goed?'goed':'fout'}">
      <div class="tr-score-kop">
        <span class="tr-badge ${goed?'goed-b':'fout-b'}">${goed?'✓':'!'}</span>
        <b>${goed?'Tekstcontrole geslaagd':'Tekstcontrole: let op'}</b>
      </div>
      <table class="tr-tabel">
        <tr><td>Tekst behouden uit PDF</td><td class="v ${goed?'goed-t':'fout-t'}">${score.dekkingPct}%</td></tr>
        <tr><td>Woorden door AI verzonnen</td><td class="v ${goed?'goed-t':'fout-t'}">${score.verzonnenAantal}</td></tr>
      </table>
      <p class="tr-score-uitleg">${goed
        ? 'De app heeft woord-voor-woord vergeleken: de AI paste alleen de <b>layout</b> aan, niet de tekst zelf.'
        : 'De AI week te veel af van de originele tekst. <b>Genereer opnieuw</b>, of deel de training alleen als PDF.'}</p>
      ${(!goed && score.verzonnenVoorbeelden.length)
        ? `<div class="tr-verzonnen"><span>Toegevoegde woorden:</span> ${esc(score.verzonnenVoorbeelden.join(', '))}…</div>` : ''}
    </div>`;

  const oefHtml = oefeningen.map((o,i)=>{
    // Zie training-weergave.js: index leidend (doorlopend genummerd), diagramPagina als terugval.
    const D = diagramUrls || {};
    const url = D[i+1] || D[String(i+1)] ||
      (o.diagramPagina != null ? (D[o.diagramPagina] || D[String(o.diagramPagina)]) : null);
    const diagram = url ? `<figure class="trw-diagram"><img src="${esc(url)}" alt=""></figure>` : '';
    const blokken = (o.blokken||[]).map(b=>{
      const kop = b.kop?`<h3>${esc(b.kop)}</h3>`:'';
      if (b.type==='lijst' && Array.isArray(b.items))
        return kop+'<ul>'+b.items.map(x=>`<li>${esc(x)}</li>`).join('')+'</ul>';
      return kop+`<p>${esc(b.tekst||'')}</p>`;
    }).join('');
    return `<div class="trw-oef"><div class="trw-oef-kop"><span class="trw-oef-nr">${i+1}</span><h2>${esc(o.titel||'Oefening '+(i+1))}</h2></div>${diagram}<div class="hl">${blokken}</div></div>`;
  }).join('');

  const acties = `
    <div class="tr-preview-acties"><button class="knop vol" id="trDeel">✓ Zo delen</button></div>
    <div class="tr-preview-acties2">
      <button class="knop licht" id="trTekst"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M15.4 4.8 19.2 8.6 9 18.8l-4 1.2 1.2-4z"/><path d="M13.4 6.8 17.2 10.6"/></svg> Tekst controleren/bewerken</button>
    </div>
    <div class="tr-preview-acties2">
      <button class="knop licht" id="trOpnieuw"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg> Opnieuw genereren</button>
      <button class="knop grijs" id="trPdfOnly">Alleen als PDF</button>
    </div>`;

  zetTrainingModalInhoud('Controleer', `
    ${scoreKaart}
    ${doelenBlok}
    <div class="u-t-sm u-zacht u-mb-sm u-lh-ruim">Zo zien je coaches de training straks.${goed?' Klopt de opmaak? Deel hem.':''}</div>
    ${acties}
    ${oefHtml}
    <p class="trw-bron">Training ontwikkeld door <b>Arnoud Jonker, Deurne, Netherlands</b></p>
    ${acties}`);

  // Doelen bewerken: rij verwijderen, rij toevoegen, actuele waarden uitlezen.
  const doelLijst = $('#trDoelLijst');
  const leesDoelen = () => $$('#trDoelLijst .tr-doel-inp')
    .map(i => (i.value || '').replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .slice(0, 4);
  if (doelLijst){
    doelLijst.addEventListener('click', (e) => {
      const x = e.target.closest('.tr-doel-x');
      if (x){ x.closest('.tr-doel-rij')?.remove(); ctx.doelen = leesDoelen(); }
    });
    const add = $('#trDoelAdd');
    if (add) add.onclick = () => {
      if ($$('#trDoelLijst .tr-doel-rij').length >= 4) return;
      doelLijst.insertAdjacentHTML('beforeend', doelRij(''));
      doelLijst.lastElementChild?.querySelector('.tr-doel-inp')?.focus();
    };
  }

  const deel = async () => {
    const b = $('#trDeel'); if (b){ b.disabled = true; b.textContent = 'Delen…'; }
    try {
      const doelen = leesDoelen();
      await addDoc(collection(db,'trainingen'), {
        club: S.clubId, clubNaam: S.club.naam,
        titel: meta.titel, week: meta.week, bestandsnaam: file.name,
        ...(meta.trainingsdag ? { trainingsdag: meta.trainingsdag } : {}),
        ...(meta.extra || {}),
        path: ctx.pdfPath, url: ctx.pdfUrl,
        mapId: ctx.mapId,
        oefeningen, diagramUrls, doelen,
        paginas: (ctx.paginas || []).map(p => ({ pagina: p.pagina, tekst: p.tekst })),
        aiScore: { dekking: score.dekkingPct, verzonnen: score.verzonnenAantal },
        teams: meta.teams,
        gemaakt: serverTimestamp(),
        door: S.user.displayName || S.user.email || '',
      });
      meld('Training gedeeld');
      if (meta.onKlaar){ meta.onKlaar(); } else { sluitModal(); renderClub(); }
    } catch(e){
      console.error(e); const bb = $('#trDeel'); if (bb){ bb.disabled = false; bb.textContent = '✓ Zo delen'; }
      meld('Delen mislukt');
    }
  };

  $$('#trDeel').forEach(b => b.onclick = deel);
  $$('#trPdfOnly').forEach(b => b.onclick = () => deelAlleenPdf(file, meta, ctx));
  $$('#trOpnieuw').forEach(b => b.onclick = () => startTrainingHerstructureer(file, meta, ctx));
  $$('#trTekst').forEach(b => b.onclick = async () => {
    ctx.doelen = leesDoelen();   // typwijzigingen bewaren over het herteken heen
    const { openTrainingBewerken } = await import('./training-bewerken.js?v=20261106h');
    openTrainingBewerken({
      titel: meta.titel || file.name,
      meta: meta.week || '',
      oefeningen: ctx.oefeningen,
      paginas: ctx.paginas || [],
      // In de preview is er nog geen Firestore-doc: sla lokaal op en herteken
      // de preview met de aangepaste tekst.
      opslaanLokaal: (nieuw) => {
        ctx.oefeningen = nieuw;
        const score = ctx.score;  // score herberekenen is niet nodig voor bewerkte tekst
        toonPreview(file, meta, ctx);
      },
    });
  });
}

/* Alleen de AI opnieuw draaien (PDF + diagrammen bestaan al in Storage). */
async function startTrainingHerstructureer(file, meta, ctx){
  const mod = $('.modal'); if (!mod) return;
  zetTrainingModalInhoud('Opnieuw genereren', `<div class="tr-verwerk"><div class="tr-spin"></div><p>De AI probeert de opmaak nog een keer.</p></div>`);
  try {
    const ai = await import('./training-ai.js?v=20261106h');
    // Ook de diagrammen opnieuw uitlezen én overschrijven: zo herstelt "opnieuw
    // genereren" ook een fout diagram (bv. een logo/avatar dat als veld doorkwam),
    // niet alleen de tekst-layout. uploadDiagrammen schrijft naar dezelfde paden
    // (diagram{n}.png onder ctx.mapId), dus de oude plaatjes worden vervangen.
    const { paginas, diagramBlobs } = await ai.leesPdf(file);
    let diagramUrls = ctx.diagramUrls;
    try {
      if (ctx.mapId) diagramUrls = await ai.uploadDiagrammen(S.clubId, ctx.mapId, diagramBlobs);
    } catch(e){ console.warn('[training-ai] diagrammen opnieuw opslaan faalde, oude blijven staan:', e); }
    const { oefeningen, doelen } = await ai.structureer(paginas);
    const origineleTekst = paginas.map(p=>p.tekst).join(' ');
    const score = ai.berekenScore(origineleTekst, oefeningen);
    toonPreview(file, meta, { ...ctx, diagramUrls, oefeningen, doelen, score });
  } catch(e){
    console.error('[training-ai] opnieuw mislukt', e);
    toonAlleenPdfKeuze(file, meta, ctx, 'Opnieuw genereren lukte niet. Je kunt de training als PDF delen.');
  }
}

/* Training opslaan zonder AI-layout — alleen als PDF (bestaand gedrag). */
async function deelAlleenPdf(file, meta, ctx){
  const btn = $('#trPdfOnly'); if (btn){ btn.disabled = true; btn.textContent = 'Delen…'; }
  try {
    await addDoc(collection(db,'trainingen'), {
      club: S.clubId, clubNaam: S.club.naam,
      titel: meta.titel, week: meta.week, bestandsnaam: file.name,
      ...(meta.trainingsdag ? { trainingsdag: meta.trainingsdag } : {}),
      ...(meta.extra || {}),
      path: ctx.pdfPath, url: ctx.pdfUrl,
      teams: meta.teams,
      gemaakt: serverTimestamp(),
      door: S.user.displayName || S.user.email || '',
    });
    meld('Training gedeeld (als PDF)');
    if (meta.onKlaar){ meta.onKlaar(); } else { sluitModal(); renderClub(); }
  } catch(e){
    console.error(e); meld('Delen mislukt');
    if (btn){ btn.disabled = false; btn.textContent = 'Alleen als PDF'; }
  }
}

/* Fallback-scherm als de AI helemaal niet lukte: alleen-PDF aanbieden. */
function toonAlleenPdfKeuze(file, meta, ctx, boodschap){
  const mod = $('.modal'); if (!mod) return;
  zetTrainingModalInhoud('Training delen', `
    <div class="tr-score fout u-mt-2xs">
      <div class="tr-score-kop"><span class="tr-badge fout-b">!</span><b>Automatische opmaak niet gelukt</b></div>
      <p class="tr-score-uitleg">${esc(boodschap||'')}</p>
    </div>
    <div class="tr-preview-acties"><button class="knop vol" id="trPdfOnly">Als PDF delen</button></div>
    <div class="tr-preview-acties2"><button class="knop grijs" id="trOpnieuw2"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg> Opnieuw proberen</button></div>`);
  $('#trPdfOnly').onclick = () => deelAlleenPdf(file, meta, ctx);
  $('#trOpnieuw2').onclick = () => startTrainingHerstructureer(file, meta, ctx);
}

/* Toewijzing (titel, week, teams) van een bestaande training achteraf aanpassen
   — zonder het PDF-bestand opnieuw te uploaden. */
function modalBewerkTraining(t, teams){
  const huidig = new Set(t.teams || []);
  openModal(`
    <h2>Training aanpassen</h2>
    <p class="u-t-sm u-zacht u-mb-sm">Bestand: <b>${esc(t.bestandsnaam || t.titel)}</b>${t.url ? `<span class="sep" aria-hidden="true"></span><a href="${esc(t.url)}" target="_blank" style="color:var(--grass);font-weight:600">openen ↗</a>` : ''}<br>Het PDF-bestand zelf blijft ongewijzigd.</p>
    <div class="veldgroep"><label>Titel</label>
      <input class="invoer" id="mTbTitel" value="${esc(t.titel || '')}" autocomplete="off"></div>
    <div class="veldgroep"><label>Week / periode</label>
      <input class="invoer" id="mTbWeek" value="${esc(t.week || '')}" autocomplete="off"></div>
    <div class="veldgroep"><label for="mTbZicht">Zichtbaar voor het team vanaf</label>
      <input class="invoer" type="date" id="mTbZicht" value="${esc(t.zichtbaarVanaf || '')}">
      <p class="bp-hint">Leeg = meteen zichtbaar.</p></div>
    <div class="veldgroep"><label>Trainingsdoelen <span class="u-zacht" style="font-weight:400;text-transform:none;letter-spacing:0">— getoond als suggestie bij wedstrijden in deze week</span></label>
      <div class="tr-doelen u-m-0">
        <div id="mTbDoelLijst">${(Array.isArray(t.doelen)?t.doelen:[]).map(d=>`<div class="tr-doel-rij"><span class="stip"></span><input class="tr-doel-inp mTbDoelInp" value="${esc(d||'')}" placeholder="Trainingsdoel…" maxlength="80"><span class="tr-doel-x" title="Verwijderen">✕</span></div>`).join('')}</div>
        <span class="tr-doel-toevoeg" id="mTbDoelAdd">＋ Doel toevoegen</span>
      </div></div>
    <div class="veldgroep"><label>Voor welke teams?</label>
      <div id="mTbTeams">
        ${teams.length ? bouwGroepen(teams).map(b => {
          const lijst = b.teams;
          if (!lijst.length) return '';
          return `
            <div class="u-t-xs u-fw-7 u-zacht" style="letter-spacing:.5px;text-transform:uppercase;margin:var(--space-sm) 0 var(--space-xs)">${esc(b.naam)}</div>
            <div class="team-chip-kies">
              ${lijst.map(team => `<label data-pid="${team.id}" class="${huidig.has(team.id)?'aan':''}"><input type="checkbox" data-tid="${team.id}" ${huidig.has(team.id)?'checked':''}><span>${esc(team.naam)}</span></label>`).join('')}
            </div>`;
        }).join('')
        : '<p class="u-t-sm u-zacht">Geen teams in deze club.</p>'}
      </div>
      <div class="rij u-mt-xs">
        <button class="knop licht klein" id="mTbAlle">Alle teams</button>
        <button class="knop licht klein" id="mTbGeen">Geen</button>
      </div>
    </div>
    <button class="knop vol" id="mTbOk">Wijzigingen opslaan</button>`);
  const sync = () => $$('#mTbTeams label').forEach(l => l.classList.toggle('aan', l.querySelector('input').checked));
  $$('#mTbTeams input').forEach(c => c.onchange = sync);
  $('#mTbAlle').onclick = () => { $$('#mTbTeams input').forEach(c => c.checked = true); sync(); };
  $('#mTbGeen').onclick = () => { $$('#mTbTeams input').forEach(c => c.checked = false); sync(); };
  const mTbLeesDoelen = () => $$('#mTbDoelLijst .mTbDoelInp')
    .map(i => (i.value || '').replace(/\s+/g, ' ').trim()).filter(Boolean).slice(0, 4);
  const mTbLijst = $('#mTbDoelLijst');
  if (mTbLijst){
    mTbLijst.addEventListener('click', (e) => {
      const x = e.target.closest('.tr-doel-x'); if (x) x.closest('.tr-doel-rij')?.remove();
    });
    $('#mTbDoelAdd').onclick = () => {
      if ($$('#mTbDoelLijst .tr-doel-rij').length >= 4) return;
      mTbLijst.insertAdjacentHTML('beforeend', `<div class="tr-doel-rij"><span class="stip"></span><input class="tr-doel-inp mTbDoelInp" placeholder="Trainingsdoel…" maxlength="80"><span class="tr-doel-x" title="Verwijderen">✕</span></div>`);
      mTbLijst.lastElementChild?.querySelector('.mTbDoelInp')?.focus();
    };
  }
  $('#mTbOk').onclick = async () => {
    const gekozen = $$('#mTbTeams input').filter(c => c.checked).map(c => c.dataset.tid);
    if (!gekozen.length) return meld('Kies minstens één team');
    const titel = $('#mTbTitel').value.trim() || t.bestandsnaam || 'Training';
    const week  = $('#mTbWeek').value.trim();
    const doelen = mTbLeesDoelen();   // lezen vóór sluitModal — daarna is de DOM weg
    // [20261013g] zichtbaarheidsdatum ook vóór sluitModal lezen (leeg = meteen)
    const zicht = ($('#mTbZicht')?.value || '').trim();
    sluitModal();
    try {
      await updateDoc(doc(db,'trainingen',t.id), {teams: gekozen, titel, week, doelen, zichtbaarVanaf: zicht || null});
      meld('Training bijgewerkt'); renderClub();
    } catch(e){
      console.error(e); meld('Opslaan mislukt: ' + (e.code || e.message));
    }
  };
}

/* ==================== VIDEO'S (YouTube-links) ==================== */
/* teams gegroepeerd per bouw als selecteerbare chips; voorvink = set met team-id's */
function teamKeuzePerBouw(teams, voorgevinkt){
  const vink = voorgevinkt instanceof Set ? voorgevinkt : new Set(voorgevinkt || []);
  return bouwGroepen(teams).map(b => {
    const lijst = b.teams;
    if (!lijst.length) return '';
    return `
      <div class="u-t-xs u-fw-7 u-zacht" style="letter-spacing:.5px;text-transform:uppercase;margin:var(--space-sm) 0 var(--space-xs)">${esc(b.naam)}</div>
      <div class="team-chip-kies">
        ${lijst.map(t => `<label data-pid="${t.id}" class="${vink.has(t.id)?'aan':''}"><input type="checkbox" data-tid="${t.id}" ${vink.has(t.id)?'checked':''}><span>${esc(t.naam)}</span></label>`).join('')}
      </div>`;
  }).join('');
}

/* ==================== TRAININGSGROEPEN ====================
   Vaste letter-groepen (A, B, C, …) die elk een set teams bundelen, zodat de
   club-admin bij het uploaden van de wekelijkse oefenstof niet elk team los
   hoeft aan te vinken maar één keer op de groep tikt. Opgeslagen als veld op
   het club-document (clubs/{clubId}.trainingsGroepen) — geen nieuwe collectie,
   geen extra listener: de bestaande onSnapshot op de club levert ze mee.
   Vorm: [{ id:'A', naam:'Groep A', teams:['<teamId>', …] }, …] */
function trainingsGroepen(){
  const g = S.club?.trainingsGroepen;
  return Array.isArray(g) ? g : [];
}
/* eerstvolgende vrije letter A..Z, daarna 'G' + nummer als backup */
function volgendeGroepId(){
  const bezet = new Set(trainingsGroepen().map(g => g.id));
  for (let i = 0; i < 26; i++){
    const l = String.fromCharCode(65 + i);
    if (!bezet.has(l)) return l;
  }
  let n = 1; while (bezet.has('G' + n)) n++; return 'G' + n;
}

/* Compacte rij groep-chips (voor bovenaan de upload-modal). Bij een klik roept
   hij onKies(groep) aan; de aanroeper regelt zelf het aan/uit-zetten van de
   team-checkboxes. Puur presentatie — geen eigen state. */
function groepChipsHtml(groepen, teams, actiefId = null){
  if (!groepen.length) return '';
  return `<div class="tr-groep-rij">
    ${groepen.map(g => {
      const n = (g.teams || []).filter(id => teams.some(t => t.id === id)).length;
      return `<button type="button" class="tr-groep-chip ${g.id===actiefId?'aan':''}" data-groep="${esc(g.id)}">
        <span class="letter">${esc(g.id)}</span><span class="telling">${n} team${n===1?'':'s'}</span>
      </button>`;
    }).join('')}
  </div>`;
}

/* Beheerscherm: groepen zien, teams per groep wijzigen, groep toevoegen/weg.
   Een team mag in meerdere groepen zitten (de app dwingt dat niet af) — maar de
   uitleg raadt aan het bij één te houden. Opslaan schrijft in één keer terug
   naar het club-doc; de onSnapshot ververst daarna de UI. */
function modalTrainingsGroepen(teams){
  const teken = () => {
    const groepen = trainingsGroepen();
    const rijen = groepen.length ? groepen.map(g => {
      const namen = (g.teams || [])
        .map(id => teams.find(t => t.id === id)?.naam)
        .filter(Boolean);
      const chips = namen.length
        ? namen.map(n => `<span class="team-chip">${esc(n)}</span>`).join('')
        : `<span class="team-chip leeg">nog geen teams</span>`;
      return `
        <div class="grp-beheer-rij">
          <div class="grp-badge">${esc(g.id)}</div>
          <div class="grp-body">
            <div class="grp-naam">${esc(g.naam || ('Groep ' + g.id))}<span class="sep" aria-hidden="true"></span>${namen.length} team${namen.length===1?'':'s'}</div>
            <div class="team-chips">${chips}</div>
            <div class="grp-acties">
              <button class="link" data-grp-teams="${esc(g.id)}">Teams wijzigen</button>
              <button class="link" data-grp-naam="${esc(g.id)}">Naam</button>
              <button class="link uit" data-grp-weg="${esc(g.id)}">Verwijderen</button>
            </div>
          </div>
        </div>`;
    }).join('') : `<div class="kaart leeg" style="margin:0 0 var(--space-sm)">Nog geen trainingsgroepen. Maak er één aan en koppel de teams die telkens dezelfde training krijgen.</div>`;

    openModal(`
      <h2>Trainingsgroepen</h2>
      <p class="u-t-sm u-zacht u-lh-ruim u-mb-md">Bundel teams die wekelijks dezelfde training krijgen. Bij het uploaden kies je dan alleen nog de letter, de teams worden automatisch gekoppeld.</p>
      <div id="grpLijst">${rijen}</div>
      <button class="knop licht u-w-100 u-mt-2xs" id="grpNieuw" >＋ Nieuwe groep</button>`);

    $('#grpNieuw').onclick = () => grpNaamModal(null);
    $$('#grpLijst [data-grp-teams]').forEach(b => b.onclick = () => grpTeamsModal(b.dataset.grpTeams));
    $$('#grpLijst [data-grp-naam]').forEach(b => b.onclick = () => grpNaamModal(b.dataset.grpNaam));
    $$('#grpLijst [data-grp-weg]').forEach(b => b.onclick = async () => {
      const g = trainingsGroepen().find(x => x.id === b.dataset.grpWeg);
      if (!g) return;
      if (!confirm(`Groep "${g.naam || g.id}" verwijderen? De trainingen die er al mee gedeeld zijn, blijven gewoon staan.`)) return;
      await bewaarGroepen(trainingsGroepen().filter(x => x.id !== g.id));
      teken();
    });
  };

  // naam bewerken of nieuwe groep aanmaken
  const grpNaamModal = (id) => {
    const bestaand = id ? trainingsGroepen().find(g => g.id === id) : null;
    const nieuwId = bestaand ? bestaand.id : volgendeGroepId();
    openModal(`
      <h2>${bestaand ? 'Groepsnaam' : 'Nieuwe groep ' + nieuwId}</h2>
      <div class="veldgroep"><label>Naam</label>
        <input class="invoer" id="grpNaamInp" value="${esc(bestaand?.naam || ('Groep ' + nieuwId))}" placeholder="Bijv. Groep ${nieuwId}" autocomplete="off"></div>
      <button class="knop vol" id="grpNaamOk">${bestaand ? 'Opslaan' : 'Aanmaken'}</button>
      <button class="knop licht u-mt-xs" id="grpNaamTerug" >Terug</button>`);
    $('#grpNaamTerug').onclick = teken;
    $('#grpNaamOk').onclick = async () => {
      const naam = $('#grpNaamInp').value.trim() || ('Groep ' + nieuwId);
      let g = trainingsGroepen().slice();
      if (bestaand){
        g = g.map(x => x.id === nieuwId ? { ...x, naam } : x);
      } else {
        g.push({ id: nieuwId, naam, teams: [] });
      }
      await bewaarGroepen(g);
      bestaand ? teken() : grpTeamsModal(nieuwId);   // na aanmaken meteen teams kiezen
    };
  };

  // teams van een groep kiezen (per-bouw picker hergebruikt)
  const grpTeamsModal = (id) => {
    const g = trainingsGroepen().find(x => x.id === id);
    if (!g) return teken();
    const huidig = new Set(g.teams || []);
    openModal(`
      <h2>Teams voor groep ${esc(g.id)}</h2>
      <div class="veldgroep"><label>Welke teams krijgen deze training?</label>
        <div id="grpTeamsKies">${teams.length ? teamKeuzePerBouw(teams, huidig) : '<p class="u-t-sm u-zacht">Maak eerst teams aan in deze club.</p>'}</div>
        <div class="rij u-mt-xs">
          <button class="knop licht klein" id="grpAlle">Alle teams</button>
          <button class="knop licht klein" id="grpGeen">Geen</button>
        </div>
      </div>
      <button class="knop vol" id="grpTeamsOk">Opslaan</button>
      <button class="knop licht u-mt-xs" id="grpTeamsTerug" >Terug</button>`);
    const sync = () => $$('#grpTeamsKies label').forEach(l => l.classList.toggle('aan', l.querySelector('input').checked));
    $$('#grpTeamsKies input').forEach(c => c.onchange = sync);
    $('#grpAlle').onclick = () => { $$('#grpTeamsKies input').forEach(c => c.checked = true); sync(); };
    $('#grpGeen').onclick = () => { $$('#grpTeamsKies input').forEach(c => c.checked = false); sync(); };
    $('#grpTeamsTerug').onclick = teken;
    $('#grpTeamsOk').onclick = async () => {
      const gekozen = $$('#grpTeamsKies input').filter(c => c.checked).map(c => c.dataset.tid);
      await bewaarGroepen(trainingsGroepen().map(x => x.id === id ? { ...x, teams: gekozen } : x));
      teken();
    };
  };

  teken();
}

async function bewaarGroepen(groepen){
  try {
    await updateDoc(doc(db,'clubs',S.clubId), { trainingsGroepen: groepen });
    // optimistisch bijwerken zodat vervolg-schermen meteen de nieuwe stand zien
    if (S.club) S.club.trainingsGroepen = groepen;
  } catch(e){
    console.error('[trainingsgroepen] opslaan mislukt', e);
    meld('Opslaan mislukt: ' + (e.code || e.message));
  }
}

function modalNieuweVideo(teams, voorBouw = null){
  const voor = voorBouw ? new Set(teams.filter(t => standaardBouwVoorStof(t) === voorBouw).map(t => t.id)) : new Set();
  openModal(`
    <h2>YouTube-video toevoegen</h2>
    <div class="veldgroep"><label>YouTube-link</label>
      <input class="invoer" id="mVdUrl" placeholder="https://www.youtube.com/watch?v=..." autocomplete="off"></div>
    <div class="veldgroep"><label>Titel</label>
      <input class="invoer" id="mVdTitel" placeholder="Bijv. Passing-oefening 3-hoek" autocomplete="off"></div>
    <div class="veldgroep"><label>Voor welke teams?</label>
      <div id="mVdTeams">${teams.length ? teamKeuzePerBouw(teams, voor) : '<p class="u-t-sm u-zacht">Maak eerst teams aan in deze club.</p>'}</div>
      <div class="rij u-mt-xs">
        <button class="knop licht klein" id="mVdAlle">Alle teams</button>
        <button class="knop licht klein" id="mVdGeen">Geen</button>
      </div>
    </div>
    <button class="knop vol" id="mVdOk">Toevoegen</button>`);
  const sync = () => $$('#mVdTeams label').forEach(l => l.classList.toggle('aan', l.querySelector('input').checked));
  $$('#mVdTeams input').forEach(c => c.onchange = sync);
  $('#mVdAlle').onclick = () => { $$('#mVdTeams input').forEach(c => c.checked = true); sync(); };
  $('#mVdGeen').onclick = () => { $$('#mVdTeams input').forEach(c => c.checked = false); sync(); };
  $('#mVdOk').onclick = async () => {
    const url = $('#mVdUrl').value.trim();
    if (!youtubeId(url)) return meld('Plak een geldige YouTube-link');
    const gekozen = $$('#mVdTeams input').filter(c => c.checked).map(c => c.dataset.tid);
    if (!gekozen.length) return meld('Kies minstens één team');
    const titel = $('#mVdTitel').value.trim() || 'Video';
    $('#mVdOk').disabled = true; $('#mVdOk').textContent = 'Bezig...';
    try {
      await addDoc(collection(db,'videos'), {
        club: S.clubId, clubNaam: S.club.naam,
        url, titel, teams: gekozen,
        gemaakt: serverTimestamp(),
        door: S.user.displayName || S.user.email || '',
      });
      sluitModal(); meld('Video toegevoegd'); renderClub();
    } catch(e){
      $('#mVdOk').disabled = false; $('#mVdOk').textContent = 'Toevoegen';
      meld('Opslaan mislukt: ' + (e.code || e.message));
    }
  };
}

function modalBewerkVideo(vid, teams){
  const huidig = new Set(vid.teams || []);
  const upload = vid.bron === 'upload';
  openModal(`
    <h2>Video aanpassen</h2>
    ${upload
      ? `<p class="u-t-sm u-zacht u-mb-sm">Geüploade video: <b>${esc(vid.bestandsnaam || vid.titel || 'clip.mp4')}</b>${vid.url ? `<span class="sep" aria-hidden="true"></span><a href="${esc(vid.url)}" target="_blank" style="color:var(--grass);font-weight:600">openen ↗</a>` : ''}<br>Het videobestand zelf blijft ongewijzigd.</p>`
      : `<div class="veldgroep"><label>YouTube-link</label>
      <input class="invoer" id="mVbUrl" value="${esc(vid.url || '')}" autocomplete="off"></div>`}
    <div class="veldgroep"><label>Titel</label>
      <input class="invoer" id="mVbTitel" value="${esc(vid.titel || '')}" autocomplete="off"></div>
    <div class="veldgroep"><label>Voor welke teams?</label>
      <div id="mVbTeams">${teams.length ? teamKeuzePerBouw(teams, huidig) : '<p class="u-t-sm u-zacht">Geen teams in deze club.</p>'}</div>
      <div class="rij u-mt-xs">
        <button class="knop licht klein" id="mVbAlle">Alle teams</button>
        <button class="knop licht klein" id="mVbGeen">Geen</button>
      </div>
    </div>
    <button class="knop vol" id="mVbOk">Wijzigingen opslaan</button>`);
  const sync = () => $$('#mVbTeams label').forEach(l => l.classList.toggle('aan', l.querySelector('input').checked));
  $$('#mVbTeams input').forEach(c => c.onchange = sync);
  $('#mVbAlle').onclick = () => { $$('#mVbTeams input').forEach(c => c.checked = true); sync(); };
  $('#mVbGeen').onclick = () => { $$('#mVbTeams input').forEach(c => c.checked = false); sync(); };
  $('#mVbOk').onclick = async () => {
    const gekozen = $$('#mVbTeams input').filter(c => c.checked).map(c => c.dataset.tid);
    if (!gekozen.length) return meld('Kies minstens één team');
    const titel = $('#mVbTitel').value.trim() || 'Video';
    const wijziging = {titel, teams: gekozen};
    if (!upload){
      const url = $('#mVbUrl').value.trim();
      if (!youtubeId(url)) return meld('Plak een geldige YouTube-link');
      wijziging.url = url;
    }
    sluitModal();
    try {
      await updateDoc(doc(db,'videos',vid.id), wijziging);
      meld('Video bijgewerkt'); renderClub();
    } catch(e){
      meld('Opslaan mislukt: ' + (e.code || e.message));
    }
  };
}

/* Eigen videobestand (mp4) uploaden naar Storage en delen — zelfde patroon als
   de document-/training-upload, maar naar clubs/{clubId}/videos/ en met
   bron:'upload' zodat de weergave 'm inline afspeelt i.p.v. via YouTube. */
const MAX_VIDEO_MB = 100;
function modalUploadVideo(file, teams, voorBouw = null){
  if (file.size > MAX_VIDEO_MB * 1024 * 1024)
    return meld(`Bestand is te groot (max ${MAX_VIDEO_MB} MB). Comprimeer de clip eerst.`);
  const voor = voorBouw ? new Set(teams.filter(t => standaardBouwVoorStof(t) === voorBouw).map(t => t.id)) : new Set();
  openModal(`
    <h2>Video uploaden</h2>
    <p class="u-t-sm u-zacht u-mb-sm">Bestand: <b>${esc(file.name)}</b> (${(file.size/1024/1024).toFixed(1)} MB)</p>
    <div class="veldgroep"><label>Titel</label>
      <input class="invoer" id="mVuTitel" value="${esc(file.name.replace(/\.[^.]+$/,''))}" autocomplete="off"></div>
    <div class="veldgroep"><label>Voor welke teams?</label>
      <div id="mVuTeams">${teams.length ? teamKeuzePerBouw(teams, voor) : '<p class="u-t-sm u-zacht">Maak eerst teams aan in deze club.</p>'}</div>
      <div class="rij u-mt-xs">
        <button class="knop licht klein" id="mVuAlle">Alle teams</button>
        <button class="knop licht klein" id="mVuGeen">Geen</button>
      </div>
    </div>
    <button class="knop vol" id="mVuOk">Uploaden en delen</button>`);
  const sync = () => $$('#mVuTeams label').forEach(l => l.classList.toggle('aan', l.querySelector('input').checked));
  $$('#mVuTeams input').forEach(c => c.onchange = sync);
  $('#mVuAlle').onclick = () => { $$('#mVuTeams input').forEach(c => c.checked = true); sync(); };
  $('#mVuGeen').onclick = () => { $$('#mVuTeams input').forEach(c => c.checked = false); sync(); };
  $('#mVuOk').onclick = async () => {
    const gekozen = $$('#mVuTeams input').filter(c => c.checked).map(c => c.dataset.tid);
    if (!gekozen.length) return meld('Kies minstens één team');
    const titel = $('#mVuTitel').value.trim() || file.name;
    const knop = $('.upload-knop');
    if (knop){ knop.classList.add('bezig'); knop.textContent = 'Uploaden...'; }
    sluitModal();
    try {
      const ts = Date.now();
      const veiligeNaam = file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
      const path = `clubs/${S.clubId}/videos/${ts}_${veiligeNaam}`;
      const r = sRef(storage, path);
      await uploadBytes(r, file, {contentType: file.type || 'video/mp4'});
      const url = await getDownloadURL(r);
      await addDoc(collection(db,'videos'), {
        club: S.clubId, clubNaam: S.club.naam,
        bron: 'upload', url, path,
        titel, bestandsnaam: file.name, grootte: file.size,
        teams: gekozen,
        gemaakt: serverTimestamp(),
        door: S.user.displayName || S.user.email || '',
      });
      meld('Video geüpload'); renderClub();
    } catch(e){
      console.error(e); meld('Upload mislukt: staat Firebase Storage aan?');
      if (knop){ knop.classList.remove('bezig'); knop.textContent = 'Eigen video uploaden (mp4) voor één of meer teams'; }
    }
  };
}

/* ==================== DOCUMENTEN (KNVB, beleid, overig) ====================
   Zelfde upload-patroon als trainingen (PDF naar Storage), maar met een
   categorie-veld i.p.v. week/periode. De teamkeuze hergebruikt bewust de
   bestaande per-bouw-indeling (teamKeuzePerBouw) — niet omdat een document
   leeftijdsgebonden is, maar omdat het gewoon de handigste manier is om snel
   teams terug te vinden in een lange lijst. */
function modalNieuwDocument(file, teams, voorCategorie = null){
  openModal(`
    <h2>Document uploaden</h2>
    <p class="u-t-sm u-zacht u-mb-sm">Bestand: <b>${esc(file.name)}</b> (${(file.size/1024).toFixed(0)} KB)</p>
    <div class="veldgroep"><label>Titel</label>
      <input class="invoer" id="mDoTitel" value="${esc(file.name.replace(/\.pdf$/i,''))}" autocomplete="off"></div>
    <div class="veldgroep"><label>Categorie</label>
      <select class="invoer" id="mDoCategorie">
        ${DOC_CATEGORIEN.map(c => `<option value="${c.id}" ${voorCategorie===c.id?'selected':''}>${c.naam}</option>`).join('')}
      </select></div>
    <div class="veldgroep"><label>Voor welke teams?</label>
      <div id="mDoTeams">${teams.length ? teamKeuzePerBouw(teams, new Set()) : '<p class="u-t-sm u-zacht">Maak eerst teams aan in deze club.</p>'}</div>
      <div class="rij u-mt-xs">
        <button class="knop licht klein" id="mDoAlle">Alle teams</button>
        <button class="knop licht klein" id="mDoGeen">Geen</button>
      </div>
    </div>
    <button class="knop vol" id="mDoOk">Uploaden en delen</button>`);
  const sync = () => $$('#mDoTeams label').forEach(l => l.classList.toggle('aan', l.querySelector('input').checked));
  $$('#mDoTeams input').forEach(c => c.onchange = sync);
  $('#mDoAlle').onclick = () => { $$('#mDoTeams input').forEach(c => c.checked = true); sync(); };
  $('#mDoGeen').onclick = () => { $$('#mDoTeams input').forEach(c => c.checked = false); sync(); };
  $('#mDoOk').onclick = async () => {
    const gekozen = $$('#mDoTeams input').filter(c => c.checked).map(c => c.dataset.tid);
    if (!gekozen.length) return meld('Kies minstens één team');
    const titel = $('#mDoTitel').value.trim() || file.name;
    const categorie = $('#mDoCategorie').value;
    const knop = $('.upload-knop');
    if (knop){ knop.classList.add('bezig'); knop.textContent = 'Uploaden...'; }
    sluitModal();
    try {
      const ts = Date.now();
      const veiligeNaam = file.name.replace(/[^a-zA-Z0-9._-]/g,'_');
      const path = `clubs/${S.clubId}/documenten/${ts}_${veiligeNaam}`;
      const r = sRef(storage, path);
      await uploadBytes(r, file, {contentType:'application/pdf'});
      const url = await getDownloadURL(r);
      await addDoc(collection(db,'documenten'), {
        club: S.clubId, clubNaam: S.club.naam,
        titel, categorie, bestandsnaam: file.name, path, url,
        teams: gekozen,
        gemaakt: serverTimestamp(),
        door: S.user.displayName || S.user.email || '',
      });
      meld('Document geüpload'); renderClub();
    } catch(e){
      console.error(e); meld('Upload mislukt: staat Firebase Storage aan?');
      if (knop){ knop.classList.remove('bezig'); knop.textContent = 'Document toevoegen voor één of meer teams'; }
    }
  };
}

/* Toewijzing (titel, categorie, teams) van een bestaand document achteraf
   aanpassen — zonder het PDF-bestand opnieuw te uploaden. */
function modalBewerkDocument(d, teams){
  const huidig = new Set(d.teams || []);
  openModal(`
    <h2>Document aanpassen</h2>
    <p class="u-t-sm u-zacht u-mb-sm">Bestand: <b>${esc(d.bestandsnaam || d.titel)}</b>${d.url ? `<span class="sep" aria-hidden="true"></span><a href="${esc(d.url)}" target="_blank" style="color:var(--grass);font-weight:600">openen ↗</a>` : ''}<br>Het PDF-bestand zelf blijft ongewijzigd.</p>
    <div class="veldgroep"><label>Titel</label>
      <input class="invoer" id="mDbTitel" value="${esc(d.titel || '')}" autocomplete="off"></div>
    <div class="veldgroep"><label>Categorie</label>
      <select class="invoer" id="mDbCategorie">
        ${DOC_CATEGORIEN.map(c => `<option value="${c.id}" ${d.categorie===c.id?'selected':''}>${c.naam}</option>`).join('')}
      </select></div>
    <div class="veldgroep"><label>Voor welke teams?</label>
      <div id="mDbTeams">${teams.length ? teamKeuzePerBouw(teams, huidig) : '<p class="u-t-sm u-zacht">Geen teams in deze club.</p>'}</div>
      <div class="rij u-mt-xs">
        <button class="knop licht klein" id="mDbAlle">Alle teams</button>
        <button class="knop licht klein" id="mDbGeen">Geen</button>
      </div>
    </div>
    <button class="knop vol" id="mDbOk">Wijzigingen opslaan</button>`);
  const sync = () => $$('#mDbTeams label').forEach(l => l.classList.toggle('aan', l.querySelector('input').checked));
  $$('#mDbTeams input').forEach(c => c.onchange = sync);
  $('#mDbAlle').onclick = () => { $$('#mDbTeams input').forEach(c => c.checked = true); sync(); };
  $('#mDbGeen').onclick = () => { $$('#mDbTeams input').forEach(c => c.checked = false); sync(); };
  $('#mDbOk').onclick = async () => {
    const gekozen = $$('#mDbTeams input').filter(c => c.checked).map(c => c.dataset.tid);
    if (!gekozen.length) return meld('Kies minstens één team');
    const titel = $('#mDbTitel').value.trim() || d.bestandsnaam || 'Document';
    const categorie = $('#mDbCategorie').value;
    sluitModal();
    try {
      await updateDoc(doc(db,'documenten',d.id), {teams: gekozen, titel, categorie});
      meld('Document bijgewerkt'); renderClub();
    } catch(e){
      console.error(e); meld('Opslaan mislukt: ' + (e.code || e.message));
    }
  };
}
