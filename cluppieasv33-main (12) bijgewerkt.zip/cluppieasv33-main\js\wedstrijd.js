import {
  db, collection, doc, addDoc, setDoc, updateDoc, deleteDoc, onSnapshot, serverTimestamp,
  functions, httpsCallable, query, where, getDocs
} from './firebase.js?v=20261106h';
import {
  S, $, $$, esc, meld, mmss, uurMin, datumNL, speler, spelerNaam, spelerNr,
  openModal, sluitModal, toon, stopUnsubs, modAan, bewaarPositie
} from './state.js?v=20261106h';
import {
  FORMATIES, LIJN_NAAM, bouwSlots, slotLijn, catInfo, isToernooi,
  parseFormatie, formatieBestaat, formatieNamen, aantalVeldspelers,
  tijdstrafSec, KAART_ICOON, KAART_NAAM,
  periodeNaam, periodeNrs, periodeLabel, toernooiWnr, periodeOmschrijving,
  CLUB_FORMATIE_11, doelSuggesties, isoWeek, SEIZOEN_FALLBACK,
  WISSEL_REDENEN, wisselReden, AFWEZIG_REDENEN, afwezigRedenInfo, slotPositieNaam
} from './config.js?v=20261106h';
import { kwartGespeeld, effectieveLineup, analyseKwart, analyseWedstrijd, speeltijdReserve, disciplinaireTijd,
  analyseKwartVerwacht, analyseWedstrijdVerwacht, WISSEL_BEURT } from './analyse.js?v=20261106h';
import { ico } from './icons.js?v=20261106h';

import { telGebruik, telNav } from './tracker.js?v=20261106h';
import { opkomstVoor, teltMee, MIN_OPKOMST_TRAININGEN } from './opkomst.js?v=20261106h';
import { openInvoegSheet, bewaarWedstrijdAlsSjabloon, zetNaToepassenCallback } from './opstelling-sjabloon.js?v=20261106h';
import { heeftElftallen, elftalWedstrijd, elftalNaam, hoortBijElftal, spelersVoorElftal, filterOpElftal,
  elftalFilter, elftalFilterHtml } from './elftallen.js?v=20261106h';

/* ==================== AANMAKEN ==================== */
function leegKwart(){ return {lineup:{}, events:[], plan:[], correcties:{}, klok:{base:0, running:false, start:0}}; }

/* Aanvoerder van één periode. Nieuw model: w.aanvoerders is een object
   gekeyd zoals w.kwarten ('1','2',…), zodat het aantal aanvoerders vanzelf
   meebeweegt met w.periodes. Valt terug op het oude wedstrijd-brede
   w.aanvoerder-veld zolang een wedstrijd nog niet gemigreerd is, zodat oude
   wedstrijden hun aanvoerder blijven tonen. */
function aanvoerderVan(w, nr){
  const k = String(nr);
  if (w.aanvoerders && Object.prototype.hasOwnProperty.call(w.aanvoerders, k))
    return w.aanvoerders[k] || null;
  return w.aanvoerder || null;
}
/* Zet (of wist met pid=null) de aanvoerder van één periode. Houdt het oude
   w.aanvoerder-veld gelijk aan periode 1, zodat exports/plekken die dat veld
   nog lezen kloppend blijven tot alles is omgezet. */
function zetAanvoerder(w, nr, pid){
  (w.aanvoerders ||= {})[String(nr)] = pid || null;
  if (String(nr) === '1') w.aanvoerder = pid || null;
}
/* Unieke aanvoerdersbeurten binnen één wedstrijd, als lijst pids. Eén speler
   die twee kwarten de band draagt telt hier als één beurt in de wedstrijd —
   voor de seizoenstatistiek (kolom C) tellen we per wedstrijd, niet per kwart. */
function aanvoerdersInWedstrijd(w){
  const uit = new Set();
  const n = w.periodes || Object.keys(w.kwarten||{}).length || 4;
  for (let i = 1; i <= n; i++){ const p = aanvoerderVan(w, i); if (p) uit.add(p); }
  if (!uit.size && w.aanvoerder) uit.add(w.aanvoerder);
  return [...uit];
}

/* Formatie die dit specifieke kwart hanteert. Valt terug op de
   wedstrijd-brede startformatie (w.formatie) zolang het kwart zelf
   nog geen eigen formatie heeft — zo blijven oude wedstrijden en
   nog-lege kwarten gewoon werken. */
function kwartFormatie(w, k){
  const f = k && k.formatie;
  return (f && (formatieBestaat(w.format, f, eigenFormatiesVanTeam()) || parseFormatie(f, w.format))) ? f : w.formatie;
}

/* Eigen formaties van het huidige team ({ '11': ['4-2-1-3'], ... }), veilig als
   er nog geen zijn. */
function eigenFormatiesVanTeam(){
  return (S.team && S.team.eigenFormaties) || {};
}

/* Sla een zelfgemaakte formatie op bij het team, zodat hij voortaan als knop
   naast de vaste formaties verschijnt. Retourneert de genormaliseerde naam of
   null als de invoer niet klopt. De live team-subscription (teams.js) werkt
   S.team daarna vanzelf bij. */
async function bewaarEigenFormatie(format, ruweNaam){
  const coords = parseFormatie(ruweNaam, format);
  if (!coords) return null;
  const naam = ruweNaam.trim().split(/[-\s.]+/).filter(Boolean).join('-');
  if (formatieBestaat(format, naam, eigenFormatiesVanTeam())) return naam; // bestaat al
  const eigen = { ...(eigenFormatiesVanTeam()) };
  eigen[format] = (eigen[format] || []).concat(naam);
  try {
    await updateDoc(doc(db,'teams',S.teamId), { eigenFormaties: eigen });
    if (S.team) S.team.eigenFormaties = eigen; // direct lokaal, vóór snapshot
    telGebruik('eigen_formatie');
  } catch(e){ console.warn('[Cluppie] eigen formatie opslaan mislukt', e); return null; }
  return naam;
}

/* Herbruikbare "+ Eigen"-invoer voor de formatiekiezers (wizard én wijzig-opzet).
   Rendert een knoppenrij (vaste + eigen formaties) plus een uitklapbaar
   invoerveld. onKies(naam) wordt aangeroepen bij elke keuze; herteken() vult de
   knoppenrij opnieuw (na opslaan van een nieuwe eigen formatie).
   knopHtml(naam, actief) en actiefNaam() maken het geschikt voor zowel de
   tegel-stijl (wizard) als de knop-stijl (wijzig-opzet). */
function eigenFormatieInvoerHtml(){
  return `
    <div class="ef-invoer" hidden>
      <div class="ef-rij">
        <input class="invoer ef-veld" inputmode="numeric" placeholder="bijv. 4-2-1-3" autocomplete="off" maxlength="15">
        <button class="knop ef-bewaar" disabled>Toevoegen</button>
      </div>
      <div class="ef-status"></div>
    </div>`;
}
/* Koppelt de invoer-interactie. container = element dat de .ef-invoer,
   .ef-veld, .ef-bewaar, .ef-status bevat. getFormat() geeft het huidige format.
   onToegevoegd(naam) na succesvol opslaan. */
function koppelEigenFormatieInvoer(container, getFormat, onToegevoegd){
  const wrap = container.querySelector('.ef-invoer');
  const veld = container.querySelector('.ef-veld');
  const knop = container.querySelector('.ef-bewaar');
  const status = container.querySelector('.ef-status');
  if (!wrap || !veld || !knop) return { toon(){}, };
  const check = () => {
    const fmt = getFormat();
    const coords = parseFormatie(veld.value, fmt);
    if (!veld.value.trim()){ status.textContent=''; status.className='ef-status'; knop.disabled=true; return; }
    if (coords){
      const naam = veld.value.trim().split(/[-\s.]+/).filter(Boolean).join('-');
      status.textContent = `✓ ${naam} — ${aantalVeldspelers(fmt)} veldspelers${fmt!=='4'?' + keeper':''}`;
      status.className = 'ef-status ok'; knop.disabled = false;
    } else {
      status.textContent = `Samen ${aantalVeldspelers(fmt)} veldspelers, elke linie 1–6`;
      status.className = 'ef-status fout'; knop.disabled = true;
    }
  };
  veld.oninput = check;
  knop.onclick = async () => {
    const fmt = getFormat();
    knop.disabled = true;
    const naam = await bewaarEigenFormatie(fmt, veld.value);
    if (naam){ veld.value=''; status.textContent=''; status.className='ef-status'; wrap.hidden=true; onToegevoegd(naam); }
    else { status.textContent='Opslaan lukte niet: probeer opnieuw'; status.className='ef-status fout'; }
  };
  return { toonInvoer(){ wrap.hidden = !wrap.hidden; if (!wrap.hidden){ veld.focus(); check(); } } };
}

/* Herplaats de opstelling van één kwart naar een nieuwe formatie en houd
   spelers zoveel mogelijk op hun plek: per linie (K/V/M/A) op slotvolgorde
   overzetten. Spelers uit een krimpende linie schuiven door naar een vrije
   plek in een andere linie; blijft er niets vrij, dan gaan ze naar de bank.
   Events die verwijzen naar een slot dat in de nieuwe formatie niet meer
   bestaat, laten we vallen (net als bij een format-wijziging). */
function herplaatsKwart(w, k, nieuweFormatie){
  const oudeSlots   = bouwSlots(w.format, kwartFormatie(w, k));
  const nieuweSlots = bouwSlots(w.format, nieuweFormatie);
  const perLinie = {K:[], V:[], M:[], A:[]};
  for (const sl of oudeSlots){
    const pid = k.lineup[sl.id];
    if (pid) (perLinie[sl.lijn] ||= []).push(pid);
  }
  const nieuw = {};
  const teller = {K:0, V:0, M:0, A:0};
  for (const sl of nieuweSlots){
    const rij = perLinie[sl.lijn] || [];
    if (teller[sl.lijn] < rij.length) nieuw[sl.id] = rij[teller[sl.lijn]++];
  }
  const overschot = [];
  for (const l of ['K','V','M','A'])
    for (let i = teller[l]; i < (perLinie[l]||[]).length; i++) overschot.push(perLinie[l][i]);
  for (const sl of nieuweSlots)
    if (!nieuw[sl.id] && overschot.length) nieuw[sl.id] = overschot.shift();
  k.lineup = nieuw;
  const geldig = new Set(nieuweSlots.map(sl => sl.id));
  k.events = (k.events || []).filter(e => geldig.has(e.slot));
  k.formatie = nieuweFormatie;
}


/* startopstelling van de laatste gespeelde wedstrijd met hetzelfde format */
function laatsteOpstelling(format, elftal = null){
  for (const w of S.wedstrijden){            // gesorteerd nieuw → oud
    if (w.format !== format) continue;
    // [20260928e] team met 1e + 2e elftal: alleen een opstelling van hetzelfde elftal
    if (elftal && heeftElftallen() && elftalWedstrijd(w) !== elftal) continue;
    const k1 = w.kwarten?.['1'];
    if (k1 && Object.keys(k1.lineup||{}).length){
      const lineup = {};
      for (const [slot, pid] of Object.entries(k1.lineup)) if (speler(pid)) lineup[slot] = pid;
      if (Object.keys(lineup).length) return {lineup, formatie: w.formatie, bron: w};
    }
  }
  return null;
}

/* ---- Vorige confrontatie tegen dezelfde tegenstander ----
   Genormaliseerde naamvergelijking: negeert hoofdletters, spaties, leestekens
   en het eigen clubvoorvoegsel (ASV'33), zodat "ASV'33 JO11-2" en "jo11 2"
   als dezelfde tegenstander gelden. */
function normTegenstander(naam){
  if (!naam) return '';
  let s = String(naam).toLowerCase();
  s = s.replace(/asv['’`]?\s*33/g, ' ');     // eigen club weglaten
  s = s.replace(/[^a-z0-9]+/g, '');          // alleen letters/cijfers
  return s;
}

/* Telt een wedstrijd als "gespeeld"? Uitslag (goals) of een ingevulde
   startopstelling. Lege/toekomstige (geïmporteerde) wedstrijden tellen niet. */
function isGespeeld(w){
  if (Array.isArray(w.goals) && w.goals.length) return true;
  for (const k of Object.values(w.kwarten || {}))
    if (Object.keys(k.lineup || {}).length) return true;
  return false;
}

/* Zoekt de meest recente gespeelde wedstrijd tegen dezelfde tegenstander,
   exclusief de huidige wedstrijd. Toernooien slaan we over (geen vaste
   tegenstander op wedstrijdniveau). Geeft het bron-wedstrijddocument terug. */
function vorigeConfrontatie(huidige){
  if (!huidige || isToernooi(huidige)) return null;
  const doel = normTegenstander(huidige.tegenstander);
  if (!doel) return null;
  for (const w of S.wedstrijden){            // gesorteerd nieuw → oud
    if (w.id === S.wedstrijdId) continue;
    if (isToernooi(w)) continue;
    if (normTegenstander(w.tegenstander) !== doel) continue;
    if (!isGespeeld(w)) continue;
    return w;
  }
  return null;
}

/* Startopstelling (kwart 1) van een bronwedstrijd als [{pid,slot,keeper}]. */
/* Bouwt het kleine regeltje + uitklappaneel voor de vorige confrontatie.
   Geeft '' terug als er geen eerdere ontmoeting is. Open/dicht-stand wordt
   bewaard in S._confroOpen zodat het paneel niet dichtklapt bij elke rerender. */
function bouwConfrontatie(w){
  const v = vorigeConfrontatie(w);
  if (!v) return '';

  const voor  = (v.goals||[]).filter(g => g.type==='voor').length;
  const tegen = (v.goals||[]).filter(g => g.type==='tegen').length;
  const heeftUitslag = (v.goals||[]).length > 0;

  /* Uitslag vanuit óns perspectief; klasse stuurt de kleur. */
  let kl = 'g', uitslagTekst = '—';
  if (heeftUitslag){
    uitslagTekst = `${voor}–${tegen}`;
    kl = voor > tegen ? 'w' : voor < tegen ? 'v' : 'g';
  }
  const thuisuit = v.thuis ? 'thuis' : 'uit';
  const open = S._confroOpen ? ' open' : '';

  /* --- paneel-inhoud --- */
  const teamNaam = esc(S.team.naam);
  const tegenN   = esc(v.tegenstander);
  const linksNaam  = v.thuis ? teamNaam : tegenN;
  const rechtsNaam = v.thuis ? tegenN : teamNaam;
  const scoreMid = heeftUitslag ? `${v.thuis ? voor : tegen} – ${v.thuis ? tegen : voor}` : '–';

  const doelHtml = v.doel
    ? `<div class="confro-rij doel"><div class="lbl"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.5"/><circle cx="12" cy="12" r="0.6" fill="currentColor" stroke="none"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3"/></svg> Wedstrijddoel</div><div class="val">${esc(v.doel)}</div></div>`
    : '';
  const notitieHtml = v.notitie
    ? `<div class="confro-rij"><div class="lbl"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M15.4 4.8 19.2 8.6 9 18.8l-4 1.2 1.2-4z"/><path d="M13.4 6.8 17.2 10.6"/></svg> Notitie</div><div class="val">${esc(v.notitie)}</div></div>`
    : '';

  /* Directe link naar de betreffende wedstrijd (daar staat de opstelling). */
  const linkHtml = `<button class="confro-link" id="confroOpen" data-wid="${esc(v.id)}">→ Bekijk deze wedstrijd</button>`;

  return `
    <button class="confro-regel${open}" id="confroRegel">
      <span class="ico">↩︎</span>
      <span class="confro-tekst"><b>Vorige keer:</b> ${esc(datumNL(v.datum))}<span class="sep" aria-hidden="true"></span>${thuisuit}</span>
      ${heeftUitslag ? `<span class="confro-uitslag ${kl}">${esc(uitslagTekst)}</span>` : ''}
      <span class="confro-chev">▾</span>
    </button>
    <div class="confro-paneel${open}" id="confroPaneel">
      <div class="confro-card">
        <div class="confro-titel">↩︎ Vorige confrontatie<span class="sep" aria-hidden="true"></span>${tegenN}</div>
        <div class="confro-uitslagblok">
          <div class="partij">${linksNaam}</div>
          <div class="score">${scoreMid}</div>
          <div class="partij r">${rechtsNaam}<span class="datum">${esc(datumNL(v.datum))}<span class="sep" aria-hidden="true"></span>${thuisuit}</span></div>
        </div>
        ${doelHtml}${notitieHtml}${linkHtml}
      </div>
    </div>`;
}

export function modalNieuweWedstrijd(){
  if (!S.spelers.length) return meld('Voeg eerst spelers toe onder het tabblad Spelers');
  const vandaag = new Date().toISOString().slice(0,10);
  const cat = catInfo(S.team.categorie) || null;
  let type = 'normaal';
  let periodes = cat ? cat.periodes : 4;
  let format = cat ? cat.format : S.team.format;
  let toernooiHelften = 1;
  const stdDuur = cat ? cat.duur : 15;
  /* [20260928e] Selectie met een 1e + 2e elftal: eerst kiezen voor welk
     elftal. Bepaalt de voorselectie en welke vorige opstelling je overneemt. */
  const tweeElftallen = heeftElftallen();
  let elftal = '1';

  openModal(`
    <h2>Nieuwe wedstrijd</h2>
    ${tweeElftallen ? `<div class="veldgroep"><label>Elftal</label>
      <div class="segment" id="mWElftal">
        <button data-el="1" class="actief">1e elftal</button>
        <button data-el="2">2e elftal</button>
      </div>
      <p id="mWElftalInfo" class="u-t-xs u-zacht u-mt-xs"></p></div>` : ''}
    <div class="veldgroep"><label>Type</label>
      <div class="segment" id="mWType">
        <button data-ty="normaal" class="actief">Competitie</button>
        <button data-ty="toernooi"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M8.4 4h7.2v3.6a3.6 3.6 0 0 1-7.2 0z"/><path d="M8.4 5.4H5.8a2.4 2.4 0 0 0 2.6 3.2"/><path d="M15.6 5.4h2.6a2.4 2.4 0 0 1-2.6 3.2"/><path d="M12 11.2v3"/><path d="M9.2 19.8h5.6l-.7-3.6h-4.2z"/></svg> Toernooi</button>
      </div></div>
    ${cat ? `<p class="u-t-sm u-zacht u-mb-sm">KNVB ${esc(S.team.categorie)}: ${esc(cat.knvb)} — standaarden zijn ingevuld.</p>` : ''}

    <div id="mWNormaal">
      <div class="veldgroep"><label>Tegenstander</label>
        <input class="invoer" id="mWTegen" placeholder="Bijv. ASV'33 ${esc(S.team.categorie || 'JO11')}-2" autocomplete="off"></div>
      <div class="veldgroep"><label>Periodes</label>
        <div class="segment" id="mWPeriodes">
          <button data-p="2" class="${periodes===2?'actief':''}">2 helften</button>
          <button data-p="4" class="${periodes===4?'actief':''}">4 kwarten</button>
        </div></div>
    </div>

    <div id="mWToernooi" style="display:none">
      <div class="veldgroep"><label>Naam toernooi</label>
        <input class="invoer" id="mWToernooiNaam" placeholder="Bijv. Pinkstertoernooi Mifano" autocomplete="off"></div>
      <div class="rij">
        <div class="veldgroep"><label>Aantal wedstrijden</label>
          <select class="invoer" id="mWAantal">${Array.from({length:9},(_,i)=>`<option value="${i+2}" ${i+2===4?'selected':''}>${i+2}</option>`).join('')}</select></div>
        <div class="veldgroep"><label>Helften per wedstrijd</label>
          <div class="segment" id="mWHelften">
            <button data-h="1" class="actief">1</button><button data-h="2">2</button>
          </div></div>
      </div>
    </div>

    <div class="rij">
      <div class="veldgroep"><label>Datum</label><input class="invoer" type="date" id="mWDatum" value="${vandaag}"></div>
      <div class="veldgroep"><label id="mWDuurLabel">Minuten per ${periodes===2?'helft':'kwart'}</label><input class="invoer" id="mWDuur" inputmode="decimal" value="${String(stdDuur).replace('.',',')}"></div>
    </div>
    <div class="rij">
      <div class="veldgroep" id="mWThuisWrap"><label>Thuis of uit</label>
        <div class="segment" id="mWThuis"><button data-t="1" class="actief">Thuis</button><button data-t="0">Uit</button></div></div>
      <div class="veldgroep"><label>Aantal spelers</label>
        <div class="segment" id="mWFormat">${['4','5','6','7','8','9','10','11'].map(f =>
          `<button data-f="${f}" class="${format===f?'actief':''}">${f}</button>`).join('')}</div></div>
    </div>

    <label class="lid-rij" id="mWOvernemenWrap" style="cursor:pointer;display:none">
      <input type="checkbox" id="mWOvernemen" style="width:19px;height:19px;accent-color:var(--grass)">
      <div class="lid-naam" style="font-weight:500">Begin met opstelling van vorige wedstrijd
        <span class="u-t-xs u-zacht" style="display:block;font-weight:400" id="mWOvernemenInfo"></span></div>
    </label>

    <button class="knop vol u-mt-xs" id="mWOk" >Aanmaken</button>`);

  let thuis = true;
  const duurLabel = () => {
    $('#mWDuurLabel').textContent = type === 'toernooi'
      ? (toernooiHelften === 1 ? 'Minuten per wedstrijd' : 'Minuten per helft')
      : 'Minuten per ' + (periodes===2?'helft':'kwart');
  };
  const werkElftalInfo = () => {
    const info = $('#mWElftalInfo'); if (!info) return;
    const { eigen } = spelersVoorElftal(S.spelers, elftal);
    info.textContent = `${eigen.length} spelers van het ${elftalNaam(elftal)} staan vooraf in de selectie. De rest kun je erbij zetten.`;
  };
  $$('#mWElftal button').forEach(b => b.onclick = () => {
    $$('#mWElftal button').forEach(x => x.classList.remove('actief')); b.classList.add('actief');
    elftal = b.dataset.el; werkElftalInfo(); werkOvernemenBij();
  });
  werkElftalInfo();
  const werkOvernemenBij = () => {
    const vorige = laatsteOpstelling(format, tweeElftallen ? elftal : null);
    const wrap = $('#mWOvernemenWrap');
    if (vorige && type === 'normaal'){
      wrap.style.display = '';
      const aantal = Object.keys(vorige.lineup).length;
      $('#mWOvernemenInfo').textContent =
        `${vorige.bron.tegenstander ? 'tegen '+vorige.bron.tegenstander+', ' : ''}${aantal} spelers, ${vorige.formatie}`;
    } else {
      wrap.style.display = 'none';
      $('#mWOvernemen').checked = false;
    }
  };
  $$('#mWType button').forEach(b => b.onclick = () => {
    $$('#mWType button').forEach(x=>x.classList.remove('actief')); b.classList.add('actief');
    type = b.dataset.ty;
    $('#mWNormaal').style.display = type === 'normaal' ? '' : 'none';
    $('#mWToernooi').style.display = type === 'toernooi' ? '' : 'none';
    $('#mWThuisWrap').style.display = type === 'normaal' ? '' : 'none';
    $('#mWDuur').value = type === 'toernooi' ? '15' : String(stdDuur).replace('.',',');
    duurLabel(); werkOvernemenBij();
  });
  $$('#mWThuis button').forEach(b => b.onclick = () => { $$('#mWThuis button').forEach(x=>x.classList.remove('actief')); b.classList.add('actief'); thuis = b.dataset.t==='1'; });
  $$('#mWFormat button').forEach(b => b.onclick = () => { $$('#mWFormat button').forEach(x=>x.classList.remove('actief')); b.classList.add('actief'); format = b.dataset.f; werkOvernemenBij(); });
  $$('#mWHelften button').forEach(b => b.onclick = () => { $$('#mWHelften button').forEach(x=>x.classList.remove('actief')); b.classList.add('actief'); toernooiHelften = Number(b.dataset.h); duurLabel(); });
  $$('#mWPeriodes button').forEach(b => b.onclick = () => {
    $$('#mWPeriodes button').forEach(x=>x.classList.remove('actief')); b.classList.add('actief');
    periodes = Number(b.dataset.p);
    duurLabel();
    const huidig = parseFloat(($('#mWDuur').value||'').replace(',','.'));
    if (huidig) $('#mWDuur').value = String(periodes===2 ? huidig*2 : huidig/2).replace('.',',');
  });
  werkOvernemenBij();

  $('#mWOk').onclick = async () => {
    const duur = parseFloat(($('#mWDuur').value||String(stdDuur)).replace(',','.')) || stdDuur;
    const overnemen = $('#mWOvernemen').checked && type === 'normaal';
    let w, overTeNemen = null, formatie = Object.keys(FORMATIES[format])[0];
    if (overnemen){
      const vorige = laatsteOpstelling(format, tweeElftallen ? elftal : null);
      if (vorige){
        overTeNemen = {...vorige.lineup};
        if (formatieBestaat(format, vorige.formatie, eigenFormatiesVanTeam()) || parseFormatie(vorige.formatie, format)) formatie = vorige.formatie;
      }
    }
    if (type === 'toernooi'){
      const aantal = Number($('#mWAantal').value);
      w = {
        type: 'toernooi',
        tegenstander: $('#mWToernooiNaam').value.trim() || 'Toernooi',
        thuis: true, format,
        toernooi: {wedstrijden: aantal, helften: toernooiHelften},
        tegenstanders: {},
        periodes: aantal * toernooiHelften,
      };
    } else {
      w = {
        type: 'normaal',
        tegenstander: $('#mWTegen').value.trim() || 'Tegenstander',
        thuis, format, periodes,
      };
    }
    const kwarten = {};
    for (let i = 1; i <= w.periodes; i++) kwarten[i] = leegKwart();
    if (overTeNemen) kwarten[1].lineup = {...overTeNemen};
    Object.assign(w, {
      formatie,
      datum: $('#mWDatum').value || vandaag,
      kwartduur: duur,
      selectie: tweeElftallen ? (() => { const e = spelersVoorElftal(S.spelers, elftal).eigen; return (e.length ? e : S.spelers).map(p => p.id); })() : S.spelers.map(p => p.id),
      ...(tweeElftallen ? { elftal } : {}),
      goals: [],
      kaarten: [],
      kwarten,
      seizoen: S.huidigSeizoen || SEIZOEN_FALLBACK,
      gemaakt: serverTimestamp(),
      opzetGedaan: false,
    });
    /* Overgenomen opstelling: spelers die niet in de voorselectie van dit
       elftal zitten, zetten we er alsnog bij (anders staan ze op het veld
       maar gelden ze als afwezig). */
    if (tweeElftallen && overTeNemen){
      for (const pid of Object.values(overTeNemen)) if (!w.selectie.includes(pid)) w.selectie.push(pid);
    }
    const ref = await addDoc(collection(db,'teams',S.teamId,'wedstrijden'), w);
    telGebruik('wedstrijd_start');
    sluitModal();
    if (overTeNemen) meld('Opstelling van vorige wedstrijd overgenomen, pas aan waar nodig');
    openWedstrijd(ref.id);
  };
}

/* ==================== OPENEN & OPSLAAN ==================== */

/* Vult ontbrekende wedstrijdvelden aan (bv. geïmporteerde voetbal.nl-wedstrijden
   hebben geen format/periodes/formatie/kwartduur/kwarten). Geeft true terug als
   er iets is aangevuld, zodat we het document één keer kunnen wegschrijven. */
function normaliseerWedstrijd(w){
  const cat = catInfo(S.team.categorie) || null;
  let veranderd = false;
  if (w.type !== 'toernooi' && w.type !== 'normaal'){ w.type = 'normaal'; veranderd = true; }
  if (!w.format){ w.format = (cat ? cat.format : S.team.format) || '8'; veranderd = true; }
  if (typeof w.thuis !== 'boolean'){ w.thuis = true; veranderd = true; }
  if (!w.periodes){ w.periodes = cat ? cat.periodes : 4; veranderd = true; }
  if (!w.kwartduur){ w.kwartduur = cat ? cat.duur : 15; veranderd = true; }
  if (!FORMATIES[w.format]){ w.format = '8'; veranderd = true; }
  if (!w.formatie || !(FORMATIES[w.format][w.formatie] || parseFormatie(w.formatie, w.format))){
    w.formatie = Object.keys(FORMATIES[w.format])[0]; veranderd = true;
  }
  if (!w.kwarten || typeof w.kwarten !== 'object' || !Object.keys(w.kwarten).length){
    const kwarten = {};
    for (let i = 1; i <= w.periodes; i++) kwarten[i] = leegKwart();
    w.kwarten = kwarten; veranderd = true;
  }
  /* Per-kwart formatie: bestaande wedstrijden hebben alleen w.formatie.
     We zetten die als startwaarde op elk kwart, zodat elk kwart voortaan
     zijn eigen speelwijze kan onthouden. Ongeldige waarden corrigeren we. */
  for (const kk of Object.values(w.kwarten)){
    if (!kk || typeof kk !== 'object') continue;
    if (!kk.formatie || !(FORMATIES[w.format][kk.formatie] || parseFormatie(kk.formatie, w.format))){
      kk.formatie = w.formatie; veranderd = true;
    }
  }
  /* Aanvoerder per periode: oude wedstrijden hebben alleen het brede
     w.aanvoerder-veld. We zetten dat één keer om naar w.aanvoerders (met de
     bestaande aanvoerder op periode 1), zodat elke periode voortaan zijn eigen
     aanvoerder kan onthouden. Het oude veld laten we staan voor plekken die het
     nog lezen. */
  if (!w.aanvoerders || typeof w.aanvoerders !== 'object'){
    w.aanvoerders = w.aanvoerder ? { '1': w.aanvoerder } : {};
    veranderd = true;
  }
  if (!Array.isArray(w.goals)){ w.goals = []; veranderd = true; }
  if (!Array.isArray(w.kaarten)){ w.kaarten = []; veranderd = true; }
  if (!Array.isArray(w.selectie) || !w.selectie.length){
    // [20260928e] 1e + 2e elftal: standaard alleen de spelers van dit elftal
    const eigen = heeftElftallen() && w.type !== 'toernooi' ? spelersVoorElftal(S.spelers, elftalWedstrijd(w)).eigen : [];
    w.selectie = (eigen.length ? eigen : S.spelers).map(p => p.id); veranderd = true;
  }
  /* Ingeleende spelers die pas ná het aanmaken van deze wedstrijd binnenkwamen,
     staan niet in w.selectie en verschijnen daardoor als afwezig — terwijl je
     iemand juist leent om hem te laten spelen. Zet ze er één keer bij, zodat
     een geleende speler meteen op de bank staat. w.leenErbij onthoudt wie we
     al hebben aangevuld, zodat een speler die de coach er daarna bewust
     uithaalt niet bij elke render terugkeert. Alleen zolang er in deze
     wedstrijd nog niet gespeeld is: een afgeronde wedstrijd laten we met rust. */
  else if (!Object.values(w.kwarten || {}).some(kwartGespeeld)){
    const alGehad = Array.isArray(w.leenErbij) ? w.leenErbij : [];
    const nieuw = S.spelers
      .filter(p => p._ingeleend && !w.selectie.includes(p.id) && !alGehad.includes(p.id))
      .map(p => p.id);
    if (nieuw.length){
      w.selectie  = [...w.selectie, ...nieuw];
      w.leenErbij = [...alGehad, ...nieuw];
      veranderd = true;
    }
  }
  if (typeof w.opzetGedaan !== 'boolean'){ w.opzetGedaan = true; veranderd = true; }
  return veranderd;
}

export function openWedstrijd(wid){
  // Vangnet: als teamId (of wid) ontbreekt — bv. na een tijdelijke lege
  // team-snapshot die de teamstaat leegde terwijl de lijst nog op het scherm
  // stond — bouw dan géén Firestore-pad met null (dat crasht op path.indexOf).
  // Val stil terug naar de teamweergave i.p.v. de app te laten omvallen.
  if (!S.teamId || !wid){
    console.warn('[Cluppie] openWedstrijd afgebroken: ontbrekende teamId of wid', {teamId:S.teamId, wid});
    S.wedstrijdId = null;
    if (S.teamId) import('./teams.js?v=20261106h').then(m => m.renderTeam?.());
    return;
  }
  S.wedstrijdId = wid; S.kwart = '1'; S.geselecteerd = null; S._confroOpen = false; S._wizardActief = false;
  bewaarPositie();
  stopUnsubs('wedstrijd');
  S.unsub.wedstrijd = onSnapshot(doc(db,'teams',S.teamId,'wedstrijden',wid), snap => {
    if (!snap.exists()){ sluitWedstrijd(); return; }
    if (snap.metadata.hasPendingWrites) return;
    const data = snap.data();
    // De opzet-wizard-check mag NIET achter de lokaalTot-throttle vallen: anders
    // mist een nieuwe wedstrijd (net aangemaakt) zijn enige schone snapshot en
    // verschijnt de wizard nooit. Daarom eerst normaliseren + wizard beslissen,
    // en pas daarna de throttle voor het overschrijven van de lokale staat.
    const moetWizard = data.opzetGedaan === false && !S._wizardActief;
    if (Date.now() - S.lokaalTot < 1800){
      // In het throttle-venster niet de lokale staat overschrijven, maar de
      // wizard mag wel: zorg dat S.wedstrijd bestaat zodat de wizard data heeft.
      if (moetWizard){ S.wedstrijd ||= data; S._wizardActief = true; toonWedstrijdWizard(); }
      return;
    }
    const aangevuld = normaliseerWedstrijd(data);
    S.wedstrijd = data;
    // Wizard-beslissing vóór renderWedstrijd(), zodat een eventuele render-fout
    // de wizard niet kan tegenhouden bij een gloednieuwe wedstrijd.
    if (data.opzetGedaan === false && !S._wizardActief){
      S._wizardActief = true;
      toonWedstrijdWizard();
    }
    renderWedstrijd();
    if (aangevuld) bewaarWedstrijd();
  }, (err) => {
    console.error(`[Cluppie] Listener "wedstrijd" kon niet lezen (teamId=${S.teamId}, wid=${wid}):`, err.code, err.message);
    if (err.code === 'permission-denied') meld('Geen toegang tot deze wedstrijd, controleer de Firestore-rules');
  });
  toon('wedstrijd');
  telNav('wedstrijd:opstelling', 'open');
}
export function sluitWedstrijd(naarTab){
  stopUnsubs('wedstrijd');
  clearInterval(S.klokInterval); S.klokInterval = null;
  S.wedstrijd = null; S.wedstrijdId = null;
  verbergWedstrijdWizard();
  verbergWijzigOpzet();
  if (typeof naarTab === 'string') S.teamTab = naarTab;
  bewaarPositie();
  import('./teams.js?v=20261106h').then(m => { m.renderTeam(); toon('team'); });
}
/* Speeltijd van INGELEENDE spelers in déze wedstrijd wegschrijven op het
   leen-record zelf (clubs/{clubId}/uitleningen/{leenId}), zodat het
   bronteam — dat geen leesrecht heeft op onze wedstrijddata — toch kan zien
   hoeveel de speler elders speelde. Per-wedstrijd-key (i.p.v. optellen) zodat
   herhaald opslaan van dezelfde wedstrijd niet dubbel telt en correcties
   gewoon overschrijven. Alleen actief zolang de uitlening bestaat; bij
   terughalen verdwijnt dit totaal mee met het leen-record (bekende
   beperking — geen seizoenslange archivering van uitgeleende speeltijd). */
function bijwerkLeenSpeeltijd(){
  const clubId = S.team?.club;
  if (!clubId || !S.wedstrijdId || !S.wedstrijd) return;
  const ingeleend = (S.spelers||[]).filter(p => p._ingeleend && p._leenId);
  if (!ingeleend.length) return;
  const a = analyseWedstrijd(S.wedstrijd);
  for (const p of ingeleend){
    const sec = a.tijd[p.id] || 0;
    updateDoc(doc(db,'clubs',clubId,'uitleningen',p._leenId), {
      [`speeltijdPerWedstrijd.${S.wedstrijdId}`]: sec,
    }).catch(() => {}); // uitlening kan net teruggezet zijn — stil negeren
  }
}

function bewaarWedstrijd(){
  S.lokaalTot = Date.now();
  clearTimeout(S.saveTimer);
  S.saveTimer = setTimeout(() => {
    setDoc(doc(db,'teams',S.teamId,'wedstrijden',S.wedstrijdId), S.wedstrijd)
      .then(bijwerkLeenSpeeltijd)
      .catch(e => meld('Opslaan mislukt: ' + e.code));
  }, 600);
}

/* ==================== WEDSTRIJD-WIZARD (eerste keer opzetten) ====================
   Volledig scherm, verschijnt automatisch bij een gloednieuwe wedstrijd (opzetGedaan
   === false). Vier korte stappen: aanvoerder, aantal spelers, speelwijze, doel.
   Overslaan kan altijd, met een korte waarschuwing dat alles later nog aan te passen
   is via "Wijzig opzet" rechtsboven. Oude wedstrijden (voor deze feature) krijgen via
   normaliseerWedstrijd() al opzetGedaan=true en zien deze wizard dus nooit. */
const WIZARD_STAPPEN = 4;

/* Haalt trainingsdoelen op uit de oefenstof van DEZELFDE week als de wedstrijd
   en toont ze als suggestietegels boven de algemene doel-chips. "Dezelfde week"
   = zelfde jaar + ISO-weeknummer, gemeten op het moment waarop de training werd
   gedeeld (gemaakt). Doelen van meerdere trainingen in die week worden
   samengevoegd en ontdubbeld. Faalt stil: geen tegels als er niets is. */
async function laadTrainingsdoelTegels(w, kiesDoel, houderId = 'wzTrainDoelen'){
  const houder = document.getElementById(houderId);
  if (!houder) return;
  const clubId = S.team?.club;
  if (!clubId || !w?.datum) return;                    // los team of geen datum: geen tegels

  // ISO-week + jaar van de wedstrijddatum ("YYYY-MM-DD").
  const wDatum = new Date(w.datum + 'T12:00');
  if (isNaN(wDatum)) return;
  const wWeek = isoWeek(wDatum);
  const wJaar = wDatum.getFullYear();

  let snap;
  try {
    snap = await getDocs(query(collection(db, 'trainingen'), where('club', '==', clubId)));
  } catch(e){ console.warn('[wz] trainingen ophalen faalde', e); return; }

  // Weeknummer uit het (bewerkbare) tekstveld "Week / periode" halen, bv.
  // "Week 35" of "week35" → 35. Geen getal erin: dan geen tekstveld-match.
  const weekUitVeld = (tekst) => {
    const m = String(tekst || '').match(/\d{1,2}/);
    if (!m) return null;
    const n = parseInt(m[0], 10);
    return (n >= 1 && n <= 53) ? n : null;
  };

  const gezien = new Set();
  const doelen = [];
  snap.forEach(docSnap => {
    const t = docSnap.data();
    if (!Array.isArray(t.doelen) || !t.doelen.length) return;
    // Alleen trainingen die (ook) voor dit team bedoeld zijn; zonder teams-veld: meenemen.
    if (Array.isArray(t.teams) && t.teams.length && S.teamId && !t.teams.includes(S.teamId)) return;
    // Weekmatch: eerst op het bewerkbare "Week / periode"-veld (dat is wat de
    // coach bedoelt). Bevat dat geen weeknummer, dan terugvallen op de
    // uploaddatum 'gemaakt', zodat oude trainingen zonder ingevuld weekveld
    // blijven werken zoals voorheen.
    const veldWeek = weekUitVeld(t.week);
    if (veldWeek !== null){
      if (veldWeek !== wWeek) return;
      // Zacht jaarguard: kennen we de uploaddatum, dan mag die hooguit één jaar
      // afwijken (dekt de dec/jan-grens van ISO-week 1, blokkeert een label van
      // een heel seizoen terug). Onbekende datum → toch tonen.
      const g = t.gemaakt && typeof t.gemaakt.toDate === 'function' ? t.gemaakt.toDate() : null;
      if (g && Math.abs(g.getFullYear() - wJaar) > 1) return;
    } else {
      const g = t.gemaakt && typeof t.gemaakt.toDate === 'function' ? t.gemaakt.toDate() : null;
      if (!g) return;
      if (isoWeek(g) !== wWeek || g.getFullYear() !== wJaar) return;
    }
    for (const d of t.doelen){
      const tekst = String(d || '').replace(/\s+/g, ' ').trim();
      if (!tekst) continue;
      const sleutel = tekst.toLowerCase();
      if (gezien.has(sleutel)) continue;
      gezien.add(sleutel);
      doelen.push(tekst);
    }
  });

  if (!doelen.length) return;                          // niets deze week: laat de container leeg

  houder.innerHTML = `
    <div class="wz-doel-sug-kop">Uit de training van deze week
      <span class="wz-doel-badge">week ${wWeek}</span></div>
    <div class="wz-doel-tegels">
      ${doelen.map(d => `<div class="wz-doel-tegel" data-doel="${esc(d)}">
        <span class="wz-doel-ico">\u{1F3AF}</span><span class="wz-doel-t">${esc(d)}</span>
        <span class="wz-doel-vink">\u2713</span></div>`).join('')}
    </div>`;

  const huidig = ($('#wzDoelInvoer')?.value || '').trim().toLowerCase();
  houder.querySelectorAll('.wz-doel-tegel').forEach(tegel => {
    if (tegel.dataset.doel.toLowerCase() === huidig) tegel.classList.add('wz-actief');
    tegel.onclick = () => {
      kiesDoel(tegel.dataset.doel);
      tegel.classList.add('wz-actief');
    };
  });
}

function toonWedstrijdWizard(){
  const w = S.wedstrijd;
  const spelersInSelectie = (w.selectie||[]).map(pid => speler(pid)).filter(Boolean);

  let stap = 0;
  let gekAanvoerder = w.aanvoerder || null;
  let gekFormat = w.format;
  let gekFormatie = w.formatie;

  const stapHtml = [
    `<div class="wz-icoon"></div>
     <h2>Wie is aanvoerder?</h2>
     <p class="wz-uitleg">Kies de aanvoerder voor deze wedstrijd. Je kunt dit later altijd wijzigen.</p>
     <div class="wz-keuzelijst" id="wzAanvoerderLijst">
       <div class="wz-keuze ${!gekAanvoerder?'wz-actief':''}" data-pid="">
         <div class="wz-shirt">—</div><div class="wz-naam">Nog geen keuze</div><div class="wz-check"></div>
       </div>
       ${spelersInSelectie.map(p => `
         <div class="wz-keuze ${gekAanvoerder===p.id?'wz-actief':''}" data-pid="${p.id}">
           <div class="wz-shirt">${esc(spelerNr(p.id))}</div>
           <div class="wz-naam">${esc(p.naam)}</div><div class="wz-check"></div>
         </div>`).join('')}
     </div>`,
    `<div class="wz-icoon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="9" cy="8" r="2.8"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0"/><circle cx="17" cy="8.5" r="2.3"/><path d="M15.5 13.4A4.8 4.8 0 0 1 20.5 18"/></svg></div>
     <h2>Hoeveel spelers per team?</h2>
     <p class="wz-uitleg">Dit bepaalt het speelformat van de wedstrijd.</p>
     <div class="wz-tegels" id="wzFormatTegels">
       ${['4','5','6','7','8','9','10','11'].map(f => `<div class="wz-tegel ${gekFormat===f?'wz-actief':''}" data-f="${f}"><span class="wz-cijfer">${f}×${f}</span></div>`).join('')}
     </div>`,
    `<div class="wz-icoon"></div>
     <h2>Welke speelwijze?</h2>
     <p class="wz-uitleg" id="wzFormatieUitleg">Kies de formatie voor ${gekFormat}×${gekFormat}.</p>
     <div class="wz-tegels wz-tegels-drie" id="wzFormatieTegels"></div>
     <div id="wzEigen">${eigenFormatieInvoerHtml()}</div>`,
    `<div class="wz-icoon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.5"/><circle cx="12" cy="12" r="0.6" fill="currentColor" stroke="none"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3"/></svg></div>
     <h2>Wat is het wedstrijddoel?</h2>
     <p class="wz-uitleg">Waar wil je dit team vandaag op laten letten?</p>
     <input class="invoer" id="wzDoelInvoer" value="${esc(w.doel||'')}" placeholder="Bijv. opbouw van achteruit, durven schieten">
     <div id="wzTrainDoelen"></div>
     <div class="wz-chips-kop u-mt-md">Of kies een algemeen doel</div>
     <div class="wz-chips">
       ${doelSuggesties(S.team?.categorie).slice(0,4).map(s => `<div class="wz-chip" data-doelsug="${esc(s)}">${esc(s)}</div>`).join('')}
     </div>`,
  ];

  $('#wizardAchter').innerHTML = `
    <div class="wz-scherm">
      <div class="wz-topbar">
        <span class="wz-titel-mini">Wedstrijd opzetten</span>
        <div class="wz-dots" id="wzDots">${Array.from({length:WIZARD_STAPPEN},(_,i) =>
          `<span class="wz-dot ${i===0?'wz-actief':''}" data-d="${i}"></span>`).join('')}</div>
      </div>
      <div class="wz-body" id="wzBody">${stapHtml.map((html,i) =>
        `<div class="wz-stap ${i===0?'wz-actief':''}" data-stap="${i}">${html}</div>`).join('')}</div>
      <div class="wz-klaar" id="wzKlaar">
        <div class="wz-klaar-icoon">✓</div>
        <h2>Helemaal klaar!</h2>
        <p>De opzet staat. Veel plezier vandaag: je past dit altijd aan via <b>Wijzig opzet</b> rechtsboven.</p>
      </div>
      <div class="wz-bottom" id="wzBottom">
        <div class="wz-skipwarn" id="wzSkipWarn">
          <span class="wz-skipwarn-ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.2"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2M6.3 6.3l1.5 1.5M16.2 16.2l1.5 1.5M17.7 6.3l-1.5 1.5M7.8 16.2l-1.5 1.5"/></svg></span>
          <div class="wz-skipwarn-tekst">
            <b>Weet je het zeker?</b> Je kunt aanvoerder, speelwijze, aantal spelers en wedstrijddoel altijd nog aanpassen via <b>Wijzig opzet</b> rechtsboven in het wedstrijdscherm.
            <div class="wz-skipwarn-btns">
              <button class="knop licht" id="wzSkipTerug">Toch instellen</button>
              <button class="knop fluo" id="wzSkipDoor">Ja, overslaan</button>
            </div>
          </div>
        </div>
        <div class="wz-btnrij" id="wzBtnRij">
          <button class="wz-terug" id="wzTerug" style="visibility:hidden">←</button>
          <button class="knop vol fluo" id="wzVolgende">Volgende</button>
        </div>
        <button class="wz-skiplink" id="wzSkipLink">Overslaan</button>
      </div>
    </div>`;
  $('#wizardAchter').classList.add('open');

  const efWizard = koppelEigenFormatieInvoer($('#wzEigen'), () => gekFormat, (naam) => {
    gekFormatie = naam; vulFormatieTegels();
  });
  const vulFormatieTegels = () => {
    if (!formatieBestaat(gekFormat, gekFormatie, eigenFormatiesVanTeam())) gekFormatie = Object.keys(FORMATIES[gekFormat])[0];
    $('#wzFormatieUitleg').textContent = `Kies de formatie voor ${gekFormat}×${gekFormat}.`;
    const namen = formatieNamen(gekFormat, eigenFormatiesVanTeam());
    $('#wzFormatieTegels').innerHTML = namen.map(fm =>
      `<div class="wz-tegel ${gekFormatie===fm?'wz-actief':''}" data-fm="${fm}"><span class="wz-cijfer wz-cijfer-klein">${fm}</span></div>`).join('') +
      `<div class="wz-tegel wz-tegel-eigen" data-eigen="1"><span class="wz-cijfer wz-cijfer-klein">+ Eigen</span></div>`;
    $$('#wzFormatieTegels .wz-tegel[data-fm]').forEach(el => el.onclick = () => {
      $$('#wzFormatieTegels .wz-tegel').forEach(x => x.classList.remove('wz-actief'));
      el.classList.add('wz-actief');
      gekFormatie = el.dataset.fm;
    });
    const et = $('#wzFormatieTegels .wz-tegel[data-eigen]');
    if (et) et.onclick = () => efWizard.toonInvoer();
  };
  vulFormatieTegels();

  const koppelAanvoerderKliks = () => $$('#wzAanvoerderLijst .wz-keuze').forEach(el => el.onclick = () => {
    $$('#wzAanvoerderLijst .wz-keuze').forEach(x => x.classList.remove('wz-actief'));
    el.classList.add('wz-actief');
    gekAanvoerder = el.dataset.pid || null;
  });
  koppelAanvoerderKliks();

  $$('#wzFormatTegels .wz-tegel').forEach(el => el.onclick = () => {
    $$('#wzFormatTegels .wz-tegel').forEach(x => x.classList.remove('wz-actief'));
    el.classList.add('wz-actief');
    gekFormat = el.dataset.f;
    vulFormatieTegels();
  });

  const kiesDoel = (tekst) => {
    const inp = $('#wzDoelInvoer'); if (inp) inp.value = tekst;
    $$('#wzBody [data-doelsug], #wzTrainDoelen .wz-doel-tegel').forEach(x => x.classList.remove('wz-actief'));
  };
  $$('#wzBody [data-doelsug]').forEach(b => b.onclick = () => {
    kiesDoel(b.dataset.doelsug); b.classList.add('wz-actief');
  });

  // Suggestietegels uit de oefenstof van dezelfde week (fire-and-forget; vult de
  // container zodra de data binnen is, blokkeert het openen van de wizard niet).
  laadTrainingsdoelTegels(w, kiesDoel).catch(e => console.warn('[wz] trainingsdoelen laden faalde', e));

  const toonStap = i => {
    $$('.wz-stap').forEach(s => s.classList.remove('wz-actief'));
    $(`.wz-stap[data-stap="${i}"]`).classList.add('wz-actief');
    $$('.wz-dot').forEach((d,di) => d.classList.toggle('wz-actief', di===i));
    $('#wzTerug').style.visibility = i===0 ? 'hidden' : 'visible';
    $('#wzVolgende').textContent = i===WIZARD_STAPPEN-1 ? 'Klaar' : 'Volgende';
  };

  const opslaanEnSluiten = () => {
    const formatVeranderd = gekFormat !== w.format || gekFormatie !== w.formatie;
    if (formatVeranderd){
      const nieuweIds = new Set(bouwSlots(gekFormat, gekFormatie).map(s => s.id));
      for (const kk of Object.values(w.kwarten)){
        for (const slot of Object.keys(kk.lineup)) if (!nieuweIds.has(slot)) delete kk.lineup[slot];
        kk.events = kk.events.filter(e => nieuweIds.has(e.slot));
      }
      w.format = gekFormat; w.formatie = gekFormatie;
    }
    // Wizard = eerste opzet: één keuze zetten we op elke periode als
    // startpunt. Fijnmazig per kwart bijstellen kan later via Wijzig opzet.
    w.aanvoerders = {};
    const nP = w.periodes || Object.keys(w.kwarten||{}).length || 4;
    for (let i = 1; i <= nP; i++) w.aanvoerders[String(i)] = gekAanvoerder || null;
    w.aanvoerder = gekAanvoerder || null;
    w.doel = ($('#wzDoelInvoer')?.value || '').trim();
    w.opzetGedaan = true;
    bewaarWedstrijd();
    renderWedstrijd();
    $('#wzBody').style.display = 'none';
    $('#wzBottom').style.display = 'none';
    $('#wzKlaar').classList.add('wz-actief');
    setTimeout(verbergWedstrijdWizard, 1800);
  };

  $('#wzVolgende').onclick = () => {
    if (stap < WIZARD_STAPPEN-1){ stap++; toonStap(stap); }
    else opslaanEnSluiten();
  };
  $('#wzTerug').onclick = () => { if (stap > 0){ stap--; toonStap(stap); } };
  $('#wzSkipLink').onclick = () => {
    $('#wzSkipWarn').classList.add('wz-actief');
    $('#wzBtnRij').style.display = 'none';
    $('#wzSkipLink').style.display = 'none';
  };
  $('#wzSkipTerug').onclick = () => {
    $('#wzSkipWarn').classList.remove('wz-actief');
    $('#wzBtnRij').style.display = 'flex';
    $('#wzSkipLink').style.display = 'block';
  };
  $('#wzSkipDoor').onclick = opslaanEnSluiten;
}

function verbergWedstrijdWizard(){
  const el = $('#wizardAchter');
  if (!el) return;
  el.classList.remove('open');
  el.innerHTML = '';
  S._wizardActief = false;
}


/* ==================== KLOK ==================== */
const huidigKwart = () => S.wedstrijd.kwarten[S.kwart];
function klokSec(k){ return k.klok.base + (k.klok.running ? (Date.now() - k.klok.start)/1000 : 0); }
function kwartLive(k){ return k.klok.running || k.klok.base > 0; }

function klokStartPauze(){
  const k = huidigKwart();
  if (k.klok.running){ k.klok.base = klokSec(k); k.klok.running = false; }
  else { k.klok.start = Date.now(); k.klok.running = true; }
  bewaarWedstrijd(); renderWedstrijd();
}
function klokReset(){
  const k = huidigKwart();
  if (!confirm('Klok van deze periode op nul zetten?' + (k.events.length ? '\nGeregistreerde wissels blijven staan.' : ''))) return;
  k.klok = {base:0, running:false, start:0};
  bewaarWedstrijd(); renderWedstrijd();
}
function klokNaarEinde(){
  const w = S.wedstrijd, k = huidigKwart();
  const eind = Math.round(w.kwartduur*60);
  if (!confirm(`Klok direct op eindtijd (${mmss(eind)}) zetten voor ${periodeOmschrijving(w)}?`)) return;
  k.klok = {base:eind, running:false, start:0};
  bewaarWedstrijd(); renderWedstrijd();
  if (navigator.vibrate) navigator.vibrate([300,120,300,120,300]);
  meld(`Klok gezet op einde ${periodeOmschrijving(w)} (${mmss(eind)})`);
}

/* Klok handmatig op een exacte tijd zetten — bedoeld voor als de coach de klok
   te laat startte. Begrensd op 0 … kwartduur zodat de speeltijdberekening niet
   boven de maximale periodeduur uitkomt. Behoudt lopend/gepauzeerd: liep de
   klok, dan telt hij vanaf de nieuwe tijd verder door. */
function modalKlokInstellen(){
  const w = S.wedstrijd, k = huidigKwart();
  const nu = Math.round(klokSec(k));
  openModal(`
    <h2>Wedstrijdtijd instellen</h2>
    <p class="u-t-sm u-zacht u-mb-md u-lh-ruim">${esc(periodeOmschrijving(w))}<span class="sep" aria-hidden="true"></span>handig als je de klok te laat startte. De speeltijd loopt vanaf deze tijd verder.</p>
    <div class="veldgroep"><label>Klok zetten op</label>
      <div style="display:flex;align-items:center;gap:var(--space-sm)">
        <input class="invoer" id="mKiMin" inputmode="numeric" style="max-width:88px;text-align:center;font-family:'Barlow Condensed';font-weight:700;font-size:var(--t-3xl)" value="${Math.floor(nu/60)}">
        <span class="u-t-sm u-zacht">min</span>
        <input class="invoer" id="mKiSec" inputmode="numeric" style="max-width:88px;text-align:center;font-family:'Barlow Condensed';font-weight:700;font-size:var(--t-3xl)" value="${String(nu%60).padStart(2,'0')}">
        <span class="u-t-sm u-zacht">sec</span>
      </div>
      <p class="u-t-xs u-zacht u-mt-xs u-lh-ruim">Nu op <b>${mmss(nu)}</b><span class="sep" aria-hidden="true"></span>periode duurt ${String(w.kwartduur).replace('.',',')} min (blessuretijd mag hoger).</p></div>
    <button class="knop vol" id="mKiOk">Klok instellen</button>`);
  $('#mKiOk').onclick = () => {
    const min = parseInt(($('#mKiMin').value||'0').replace(/\D/g,''),10) || 0;
    const sec = parseInt(($('#mKiSec').value||'0').replace(/\D/g,''),10) || 0;
    let doel = Math.max(0, min*60 + sec);
    if (k.klok.running){ k.klok.start = Date.now() - doel*1000; }
    else { k.klok.base = doel; }
    telGebruik('klok_instellen');
    sluitModal(); bewaarWedstrijd(); renderWedstrijd();
    meld(`Klok gezet op ${mmss(doel)}`);
  };
}
function tikKlok(){
  const w = S.wedstrijd; if (!w) return;
  const k = huidigKwart();
  if (k.klok.running && klokSec(k) >= w.kwartduur*60){
    k.klok.base = Math.round(w.kwartduur*60);
    k.klok.running = false;
    bewaarWedstrijd();
    if (navigator.vibrate) navigator.vibrate([300,120,300,120,300]);
    meld(`Einde ${periodeOmschrijving(w)} — klok gestopt op ${mmss(w.kwartduur*60)}`);
    renderWedstrijd();
    return;
  }
  const el = $('#klokTijd'); if (el) el.textContent = mmss(klokSec(k));
  const sec = klokSec(k);
  (k.plan||[]).forEach((p,i) => {
    const item = $(`[data-plan-i="${i}"]`);
    if (!item) return;
    if (sec >= p.min*60 && !item.classList.contains('nu')){
      item.classList.add('nu');
      if (navigator.vibrate) navigator.vibrate([180,90,180]);
      const inNaam = p.in === WISSEL_BEURT ? (spelerNaam(beurtSpeler(k)) + ' (aan de beurt)') : spelerNaam(p.in);
      meld(`Geplande wissel: ${inNaam} erin voor ${spelerNaam(p.uit)}`);
    }
  });
}

/* ==================== GEPLANDE WISSELS ====================
   Sentinel-waarde voor "Wie aan de beurt is": in plaats van een vaste speler
   kiest de coach dat de app op het wisselmoment automatisch de speler met de
   minste speeltijd van de bank inbrengt. Zo hoeft hij vooraf niet te weten wie
   het minst gespeeld heeft — dat rekent de app pas uit als de wissel valt. */
/* WISSEL_BEURT komt uit analyse.js (zodat de verwachte-speeltijdberekening
   dezelfde sentinel gebruikt). */

/* Wie is er "aan de beurt": de beschikbare bankspeler met de minste speeltijd
   over de hele wedstrijd. uitgesloten = spelers die op dit moment al ingepland
   staan (voorkomt dat dezelfde speler dubbel wordt gekozen). Retourneert een
   pid of null als er niemand (meer) op de bank staat. */
function beurtSpeler(k, uitgesloten = new Set()){
  const l = effectieveLineup(k);
  const opVeld = new Set(Object.values(l));
  const aWed = analyseWedstrijd(S.wedstrijd);
  const bank = (S.wedstrijd.selectie||[])
    .filter(pid => !opVeld.has(pid) && speler(pid) && !uitgesloten.has(pid))
    .sort((a,b) => (aWed.tijd[a]||0) - (aWed.tijd[b]||0));
  return bank[0] || null;
}
/* Leesbare naam voor een plan-"in", inclusief de aan-de-beurt-sentinel. */
function planInNaam(pid){ return pid === WISSEL_BEURT ? 'Wie aan de beurt is' : spelerNaam(pid); }
function planInNr(pid){ return pid === WISSEL_BEURT ? '★' : spelerNr(pid); }

function modalPlanWissel(){
  const k = huidigKwart();
  const l = effectieveLineup(k);
  const gepland = k.plan || [];
  const geplandIn = new Set(gepland.map(p => p.in));
  const geplandUit = new Set(gepland.map(p => p.uit));
  const veldSpelers = Object.values(l).filter(pid => speler(pid) && !geplandUit.has(pid));
  const bankSpelers = (S.wedstrijd.selectie||[]).filter(pid => !Object.values(l).includes(pid) && speler(pid) && !geplandIn.has(pid));
  if (!veldSpelers.length) return meld('Zet eerst een opstelling neer voor deze periode');
  if (!bankSpelers.length) return meld('Er staat niemand op de bank om in te brengen');
  const optie = pid => `<option value="${pid}">${esc(spelerNr(pid))}<span class="sep" aria-hidden="true"></span>${esc(spelerNaam(pid))}</option>`;
  openModal(`
    <h2>Wissel plannen — ${esc(periodeOmschrijving(S.wedstrijd))}</h2>
    <div class="veldgroep"><label>Erin (van de bank)</label>
      <select class="invoer" id="mPlanIn"><option value="${WISSEL_BEURT}">★ Wie aan de beurt is (minst gespeeld)</option>${bankSpelers.map(optie).join('')}</select>
      <p class="u-t-xs u-zacht u-mt-xs u-lh-ruim">Bij <b>“wie aan de beurt is”</b> kiest de app op het wisselmoment automatisch de speler met de minste speeltijd van de bank.</p></div>
    <div class="veldgroep"><label>Eruit (van het veld)</label>
      <select class="invoer" id="mPlanUit">${veldSpelers.map(optie).join('')}</select></div>
    <div class="veldgroep"><label>Na hoeveel minuten</label>
      <input class="invoer" id="mPlanMin" inputmode="decimal" value="${Math.round(S.wedstrijd.kwartduur/2)}"></div>
    <label class="u-t-xs u-fw-7 u-zacht" style="text-transform:uppercase;letter-spacing:.5px;display:block;margin:var(--space-sm) 0 var(--space-xs)">Reden (optioneel)</label>
    <div class="reden-rij" id="mPlanRedenen">${WISSEL_REDENEN.map(r =>
      `<button class="reden" data-reden="${r.id}"><span class="ic">${r.ico?ico(r.ico,18):r.emoji}</span> ${r.label}</button>`).join('')}</div>
    <button class="knop vol u-mt-md" id="mPlanOk" >Wissel inplannen</button>
    <p class="u-t-sm u-zacht u-mt-sm u-lh-ruim">Zodra de kwartklok dit moment passeert, licht de wissel op in het wisselvak. Tik dan op ✓ om hem door te voeren, de echte wisseltijd en reden worden geregistreerd.</p>`);
  let planReden = null;
  $$('#mPlanRedenen [data-reden]').forEach(b => b.onclick = () => {
    const id = b.dataset.reden;
    planReden = (planReden === id) ? null : id;
    $$('#mPlanRedenen [data-reden]').forEach(x => x.classList.toggle('aan', x.dataset.reden === planReden));
  });
  $('#mPlanOk').onclick = () => {
    const min = parseFloat(($('#mPlanMin').value||'').replace(',','.'));
    if (!(min >= 0)) return meld('Vul een geldig aantal minuten in');
    const k2 = huidigKwart();
    const item = {in: $('#mPlanIn').value, uit: $('#mPlanUit').value, min};
    if (planReden) item.reden = planReden;
    (k2.plan ||= []).push(item);
    k2.plan.sort((a,b) => a.min - b.min);
    telGebruik('wissel_gepland');
    sluitModal(); bewaarWedstrijd(); renderWedstrijd();
  };
}

function voerPlanUit(i){
  const k = huidigKwart();
  const p = (k.plan||[])[i];
  if (!p) return;
  const l = effectieveLineup(k);
  const slot = Object.keys(l).find(s => l[s] === p.uit);
  if (!slot) return meld(`${spelerNaam(p.uit)} staat niet (meer) op het veld`);
  /* "Wie aan de beurt is" pas nu omzetten naar een concrete speler: de
     minst-gespeelde bankspeler op dit moment. De uitgaande speler tellen we
     mee als "op het veld" zodat hij niet per ongeluk zichzelf vervangt. */
  const inPid = p.in === WISSEL_BEURT ? beurtSpeler(k) : p.in;
  if (!inPid) return meld('Er staat niemand op de bank om in te brengen');
  if (Object.values(l).includes(inPid)) return meld(`${spelerNaam(inPid)} staat al op het veld`);
  if (kwartLive(k)){
    const sec = Math.round(klokSec(k));
    const ev = {in: inPid, uit: p.uit, slot, sec};
    if (p.reden) ev.reden = p.reden;
    k.events.push(ev);
    telGebruik('wissel_direct');
    meld(`${spelerNaam(inPid)} erin, ${spelerNaam(p.uit)} eruit, ${mmss(sec)}`);
  } else {
    k.lineup[slot] = inPid;
    for (const e of k.events) if (e.in === p.uit && e.slot === slot) e.in = inPid;
  }
  k.plan.splice(i,1);
  bewaarWedstrijd(); renderWedstrijd();
}

/* ==================== SPEELTIJD-CORRECTIE ==================== */
/* Handmatige overschrijving van de berekende speeltijd voor één speler in de huidige
   periode — bedoeld voor het geval een wissel vergeten is door te voeren. */
function modalSpeeltijdCorrigeren(pid, opties = {}){
  const w = S.wedstrijd;
  const nr = opties.kwart != null ? String(opties.kwart) : S.kwart;
  /* Vangnet: bij oude wedstrijden kan een periode-object ontbreken. */
  const k = w.kwarten[nr] || (w.kwarten[nr] = leegKwart());
  const terug = () => { if (opties.terugNaarBijwerk){ S.bijwerkKwart = nr; toonBijwerkScherm(); } else { sluitModal(); renderWedstrijd(); } };
  const aKwart = analyseKwart(w, k);
  const huidigSec = aKwart.tijd[pid] || 0;
  const heeftCorrectie = k.correcties && k.correcties[pid] != null;
  openModal(`
    <h2>Speeltijd aanpassen</h2>
    <p class="u-t-sm u-zacht u-mb-md">${esc(spelerNaam(pid))}<span class="sep" aria-hidden="true"></span>${esc(periodeLabel(w, nr))}</p>
    <div class="veldgroep"><label>Gespeelde minuten</label>
      <input class="invoer" id="mCorrMin" inputmode="decimal" value="${String(Math.round(huidigSec/6)/10).replace('.',',')}"></div>
    <p class="u-t-xs u-zacht u-lh-ruim" style="margin:var(--space-xs) 0 var(--space-md)">Overschrijft de automatische berekening voor deze periode, handig als een wissel vergeten is door te voeren.</p>
    <button class="knop vol" id="mCorrOk">Opslaan</button>
    ${heeftCorrectie ? `<button class="knop licht vol u-mt-xs" id="mCorrWeg" >Correctie verwijderen</button>` : ''}`);
  if (opties.terugNaarBijwerk) kruisNaarBijwerk(terug);
  $('#mCorrOk').onclick = () => {
    const min = parseFloat(($('#mCorrMin').value||'').replace(',','.'));
    if (!(min >= 0)) return meld('Vul een geldig aantal minuten in');
    const sec = Math.round(min*60);
    (k.correcties ||= {})[pid] = sec;
    telGebruik('speeltijd_correctie');
    bewaarWedstrijd();
    meld(`Speeltijd ${spelerNaam(pid)} aangepast naar ${mmss(sec)}`);
    terug();
  };
  const wegBtn = $('#mCorrWeg');
  if (wegBtn) wegBtn.onclick = () => {
    delete k.correcties[pid];
    bewaarWedstrijd();
    meld(`Correctie verwijderd: speeltijd weer automatisch berekend`);
    terug();
  };
}

/* ==================== ACHTERAF BIJWERKEN ====================
   Eén centraal scherm om na afloop alles per periode recht te zetten: wissels,
   doelpunten, kaarten en speeltijd. Bedoeld voor het geval de coach tijdens de
   wedstrijd geen tijd had om alles bij te houden. De sub-modals sluiten dit
   scherm (er is maar één modal-laag) en heropenen het daarna, zodat de coach
   telkens terugkeert op de juiste periode.

   S.bijwerkKwart bewaart welke periode actief is in dit scherm. */

/* Leest een min:sec-paar uit twee invoervelden. Alleen ondergrens 0 — geen
   bovengrens, zodat blessuretijd (bv. 40+3) vrij ingevuld kan worden. De
   speeltijdberekening (analyseKwart) telt zelf niet verder dan de periodeduur;
   dit is puur de tijdstempel van de gebeurtenis. */
function leesMinSec(minId, secId){
  const min = parseInt(($(minId).value||'0').replace(/\D/g,''),10) || 0;
  const sec = parseInt(($(secId).value||'0').replace(/\D/g,''),10) || 0;
  return Math.max(0, min*60 + sec);
}

/* Toont een gebeurtenistijd in voetbalnotatie. Binnen de periodeduur gewoon
   mm:ss (bv. 12:30). Valt de tijd in de blessuretijd (voorbij de periodeduur),
   dan tonen we <duur>+<extra minuten> — bv. 40+3 bij een helft van 40 min, of
   15+2 bij een kwart van 15. De extra tijd rondt naar boven af op hele minuten,
   zodat 40:01 t/m 41:00 als 40+1 verschijnt. w = wedstrijd (voor kwartduur). */
function gebeurtenisTijd(sec, w){
  sec = Math.round(sec || 0);
  const duurMin = Math.round((w?.kwartduur || 0));
  const duurSec = duurMin * 60;
  if (!duurSec || sec <= duurSec) return mmss(sec);
  const extra = Math.ceil((sec - duurSec) / 60);
  return `${duurMin}+${extra}`;
}

/* Twee gekoppelde min/sec-invoervelden als HTML-fragment. */
function minSecInvoerHtml(minId, secId, sec){
  return `<div style="display:flex;align-items:center;gap:var(--space-sm)">
    <input class="invoer" id="${minId}" inputmode="numeric" style="max-width:80px;text-align:center;font-family:'Barlow Condensed';font-weight:700;font-size:var(--t-2xl)" value="${Math.floor((sec||0)/60)}">
    <span class="u-t-sm u-zacht">min</span>
    <input class="invoer" id="${secId}" inputmode="numeric" style="max-width:80px;text-align:center;font-family:'Barlow Condensed';font-weight:700;font-size:var(--t-2xl)" value="${String((sec||0)%60).padStart(2,'0')}">
    <span class="u-t-sm u-zacht">sec</span>
  </div>`;
}

/* Periodekeuze-knoppenrij (K1…/H1…/W…). geselecteerd = huidige periode-nr. */
function periodeKiesHtml(w, geselecteerd, veldId){
  return `<div class="bijwerk-periodekies" id="${veldId}">${periodeNrs(w).map(nr =>
    `<button data-p="${nr}" class="${String(nr)===String(geselecteerd)?'aan':''}">${esc(periodeLabel(w, nr))}</button>`).join('')}</div>`;
}
function bindPeriodeKies(veldId, huidig, onKies){
  let gek = String(huidig);
  $$(`#${veldId} button`).forEach(b => b.onclick = () => {
    gek = b.dataset.p;
    $$(`#${veldId} button`).forEach(x => x.classList.toggle('aan', x.dataset.p === gek));
    if (onKies) onKies(gek);
  });
  return () => gek;
}

/* Laat het kruisje (✕) van openModal terugkeren naar het bijwerk-scherm i.p.v.
   het hele scherm sluiten. Alleen aanroepen wanneer de modal vanuit het
   bijwerk-scherm is geopend. */
function kruisNaarBijwerk(terug){
  const btn = $('#modalSluitBtn');
  if (btn) btn.onclick = () => terug();
  /* Ook de hardware-terugknop en een tik op de achtergrond moeten naar het
     overzicht terugkeren i.p.v. de wedstrijd. Die sluiten de modal via
     sluitModal() (in state.js) — we onderscheppen dat hieronder met een
     observer die reageert zodra de modal daadwerkelijk dichtgaat. */
  S._bijwerkTerug = terug;
  startBijwerkModalWacht();
}

/* Eénmalige observer op de modal-container. Zodra de modal sluit terwijl er een
   bijwerk-terug openstaat én niets de modal opnieuw heeft geopend, keren we
   terug naar het overzicht. bijwerkHeropentZelf voorkomt dat een save/terug —
   die zelf al heropent — een dubbele render veroorzaakt. */
let _bijwerkObserver = null;
function startBijwerkModalWacht(){
  if (_bijwerkObserver) return;
  const el = document.querySelector('#modalAchter');
  if (!el) return;
  _bijwerkObserver = new MutationObserver(() => {
    const open = el.classList.contains('open');
    if (open) return;                       // nog/again open — niets doen
    const terug = S._bijwerkTerug;
    if (!terug) return;                      // geen bijwerk-context meer
    S._bijwerkTerug = null;                  // verbruik de context
    /* microtask: geef een gelijktijdige save/terug de kans de modal te
       heropenen; is hij daarna nog dicht, dan is dit een back/backdrop-sluiting
       en keren we terug naar het overzicht. */
    Promise.resolve().then(() => {
      if (!el.classList.contains('open')) terug();
    });
  });
  _bijwerkObserver.observe(el, {attributes:true, attributeFilter:['class']});
}

/* Het hoofdscherm. */
export function toonBijwerkScherm(){
  const w = S.wedstrijd; if (!w) return;
  /* Het overzicht zelf is geen sub-modal: sluiten hiervan (back/backdrop) mag
     gewoon de wedstrijd tonen. Wis daarom de terug-context, zodat de observer
     de gebruiker niet in het overzicht vasthoudt. */
  S._bijwerkTerug = null;
  const nrs = periodeNrs(w);
  if (!nrs.includes(String(S.bijwerkKwart))) S.bijwerkKwart = S.kwart && nrs.includes(String(S.kwart)) ? String(S.kwart) : nrs[0];
  const nr = String(S.bijwerkKwart);
  const k = w.kwarten[nr];
  const aKwart = k ? analyseKwart(w, k) : {tijd:{}, keeper:new Set()};
  const aWed = analyseWedstrijd(w);

  const wisselRegels = (k?.events||[]).map((e,i) => ({...e, i}))
    .sort((a,b) => (a.sec||0)-(b.sec||0));
  const goalRegels = (w.goals||[]).map((g,i) => ({...g, i}))
    .filter(g => String(g.kwart) === nr).sort((a,b) => (a.sec||0)-(b.sec||0));
  const kaartRegels = (w.kaarten||[]).map((c,i) => ({...c, i}))
    .filter(c => String(c.kwart) === nr).sort((a,b) => (a.sec||0)-(b.sec||0));

  const wisselRegel = e => {
    const r = e.reden ? wisselReden(e.reden) : null;
    return `<div class="bijwerk-regel" data-bw-wissel="${e.i}">
      ${e.in ? `<span class="nr in">▲${esc(spelerNr(e.in))}</span>` : ''}
      ${e.uit ? `<span class="nr uit">▼${esc(spelerNr(e.uit))}</span>` : ''}
      <span class="bw-naam">${e.in ? esc(spelerNaam(e.in)) : ''}${e.in && e.uit ? ' voor ' : ''}${e.uit ? esc(spelerNaam(e.uit)) : ''}</span>
      ${r ? `<span class="bw-badge">${r.ico?ico(r.ico,14):''}${esc(r.label)}</span>` : ''}
      <span class="bw-tijd">${gebeurtenisTijd(e.sec, w)} <span class="bw-pen">✎</span></span></div>`;
  };
  const goalRegel = g => `<div class="bijwerk-regel" data-bw-goal="${g.i}">
      <span class="bw-ico">${g.type==='voor' ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg>' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M3.4 19V7.6h17.2V19"/><path d="M9.2 7.6V19"/><path d="M14.8 7.6V19"/><path d="M3.4 13.3h17.2"/></svg>'}</span>
      <span class="bw-naam"><b>${g.type==='voor' ? (g.pid ? esc(spelerNaam(g.pid)) : 'Doelpunt') : 'Tegendoelpunt'}</b>${g.type==='voor' && g.assist ? ` <span class="goal-assist">assist ${esc(spelerNaam(g.assist))}</span>` : ''}</span>
      <span class="bw-tijd">${gebeurtenisTijd(g.sec, w)} <span class="bw-pen">✎</span></span></div>`;
  const kaartRegel = c => `<div class="bijwerk-regel${c.auto?' bw-auto':''}" ${c.auto?'':`data-bw-kaart="${c.i}"`}>
      <span class="bw-ico">${KAART_ICOON[c.type]||'<span class="kaartje geel" aria-hidden="true"></span>'}</span>
      <span class="bw-naam"><b>${esc(spelerNaam(c.pid))}</b><span class="sep" aria-hidden="true"></span>${esc(KAART_NAAM[c.type]||c.type)}${c.type==='tijd'&&c.duur?' ('+Math.round(c.duur/60)+' min)':''}${c.auto?' (automatisch)':''}</span>
      <span class="bw-tijd">${gebeurtenisTijd(c.sec, w)}${c.auto?'':' <span class="bw-pen">✎</span>'}</span></div>`;

  const speeltijdRij = pid => {
    const aangepast = k?.correcties && k.correcties[pid] != null;
    return `<tr><td class="bw-st-naam">${esc(spelerNaam(pid))}</td>
      <td class="bw-st-tijd${aangepast?' aangepast':''}" data-bw-speeltijd="${pid}">${aKwart.tijd[pid] ? mmss(aKwart.tijd[pid]) : '—'} <span class="bw-pen">✎</span></td>
      <td class="bw-st-tot">${aWed.tijd[pid] ? uurMin(aWed.tijd[pid]) : '—'}</td></tr>`;
  };

  /* Selectie-samenvatting (wedstrijdbreed, dus boven de periode-tabs) */
  const selIds = (w.selectie||[]).filter(pid => speler(pid));
  const afwIds = S.spelers.map(p => p.id).filter(pid => !selIds.includes(pid));
  const laterIds = (w.telaat||[]).filter(pid => selIds.includes(pid));
  const selChip = (pid, tekst) => `<span class="bw-badge bw-selchip">${esc(spelerNaam(pid))}${tekst ? '<span class="sep" aria-hidden="true"></span>'+tekst : ''}</span>`;
  const afwChips = afwIds.map(pid => {
    const rec = (w.afwezigRedenen||{})[pid];
    const info = rec ? afwezigRedenInfo(rec) : null;
    return selChip(pid, info ? `${info.ico?ico(info.ico,14):''}${esc(info.label)}` : 'afwezig');
  }).join('');
  const laterChips = laterIds.map(pid => {
    const m = (w.telaatVanaf||{})[pid];
    return selChip(pid, `later${m ? ' ('+esc(m)+"')" : ''}`);
  }).join('');
  const selectieBlok = `
    <div class="bijwerk-blok">
      <div class="bijwerk-blok-kop"><span class="t"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="9" cy="8" r="2.8"/><path d="M3.5 19a5.5 5.5 0 0 1 11 0"/><circle cx="17" cy="8.5" r="2.3"/><path d="M15.5 13.4A4.8 4.8 0 0 1 20.5 18"/></svg> Selectie</span></div>
      <div class="bw-sel-tel">${selIds.length} erbij${laterIds.length ? `, ${laterIds.length} kwam later` : ''}<span class="sep" aria-hidden="true"></span>${afwIds.length} afwezig</div>
      ${afwChips || laterChips ? `<div class="bw-sel-chips">${laterChips}${afwChips}</div>` : ''}
      <button class="bijwerk-toevoeg" id="bwSelectie">✎ Selectie &amp; afwezigheid aanpassen</button>
    </div>`;

  /* Startopstelling van deze periode: k.lineup (wie BEGON), niet de opstelling
     na wissels. Hier corrigeer je achteraf wie er op welke plek begon; de
     wissels blijven staan en de speeltijd rekent zichzelf opnieuw uit. */
  const startBlok = (() => {
    if (!k) return '';
    const kF = kwartFormatie(w, k);
    const slotsB = bouwSlots(w.format, kF);
    const bezet = slotsB.filter(sl => (k.lineup || {})[sl.id] && speler(k.lineup[sl.id])).length;
    const rij = sl => {
      const pid = (k.lineup || {})[sl.id];
      const sp = pid && speler(pid) ? pid : null;
      return `<div class="bijwerk-regel bw-start" data-bw-start="${esc(sl.id)}">
        <span class="bw-start-slot${sl.id === 'K' ? ' keeper' : ''}">${esc(sl.id)}</span>
        <span class="bw-start-nr">${sp ? esc(spelerNr(sp)) : '–'}</span>
        <span class="bw-naam">${sp ? esc(spelerNaam(sp)) : '<i>Leeg</i>'}</span>
        <span class="bw-tijd"><span class="bw-pen">✎</span></span></div>`;
    };
    return `<div class="bijwerk-blok">
      <div class="bijwerk-blok-kop"><span class="t"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="5" y="4.5" width="14" height="16" rx="2.2"/><path d="M9 3.2h6v3H9z"/><path d="M8.8 11.4h6.4"/><path d="M8.8 15.4h4"/></svg> Startopstelling ${esc(periodeLabel(w, nr))}</span>
        <span class="bw-start-tel">${bezet} van ${slotsB.length} spelers</span></div>
      <div class="bw-start-hint">Wie begon er op welke plek? Tik op een plek om de speler te wijzigen.</div>
      ${slotsB.map(rij).join('')}
      <div class="bw-start-hint onder">Wissels blijven staan. De speeltijd wordt opnieuw berekend.</div>
    </div>`;
  })();

  openModal(`
    <h2>Achteraf bijwerken</h2>
    <p class="u-t-sm u-zacht u-mb-md u-lh-ruim">${esc(w.tegenstander ? 'Tegen '+w.tegenstander : periodeOmschrijving(w))}<span class="sep" aria-hidden="true"></span>zet hier na afloop alles recht wat je tijdens de wedstrijd niet kon invoeren.</p>

    ${selectieBlok}

    <div class="bijwerk-tabs">${periodeNrs(w).map(p =>
      `<button data-bw-p="${p}" class="${p===nr?'actief':''}">${esc(periodeLabel(w, p))}</button>`).join('')}</div>

    ${startBlok}

    <div class="bijwerk-blok">
      <div class="bijwerk-blok-kop"><span class="t"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg> Wissels</span></div>
      ${wisselRegels.length ? wisselRegels.map(wisselRegel).join('') : `<div class="bijwerk-leeg">Geen wissels in ${esc(periodeLabel(w, nr))}.</div>`}
      <button class="bijwerk-toevoeg" id="bwWisselNieuw">↩ Vergeten wissel toevoegen</button>
    </div>

    <div class="bijwerk-blok">
      <div class="bijwerk-blok-kop"><span class="t"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg> Doelpunten</span></div>
      ${goalRegels.length ? goalRegels.map(goalRegel).join('') : `<div class="bijwerk-leeg">Geen doelpunten in ${esc(periodeLabel(w, nr))}.</div>`}
      <button class="bijwerk-toevoeg" id="bwGoalNieuw">+ Doelpunt toevoegen</button>
    </div>

    <div class="bijwerk-blok">
      <div class="bijwerk-blok-kop"><span class="t"><span class="kaartje geel" aria-hidden="true"></span> Kaarten &amp; straffen</span></div>
      ${kaartRegels.length ? kaartRegels.map(kaartRegel).join('') : `<div class="bijwerk-leeg">Geen kaarten in ${esc(periodeLabel(w, nr))}.</div>`}
      <button class="bijwerk-toevoeg" id="bwKaartNieuw">+ Kaart toevoegen</button>
    </div>

    <div class="bijwerk-blok">
      <div class="bijwerk-blok-kop"><span class="t"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.6"/><path d="M12 7.2V12l3.4 2.2"/></svg> Speeltijd ${esc(periodeLabel(w, nr))}</span></div>
      <table class="bijwerk-st"><thead><tr><th>Speler</th><th>${esc(periodeLabel(w, nr))}</th><th>Totaal</th></tr></thead>
        <tbody>${(w.selectie||[]).filter(pid => speler(pid))
          .sort((a,b) => (aWed.tijd[b]||0)-(aWed.tijd[a]||0)).map(speeltijdRij).join('')}</tbody></table>
      <p class="u-t-xs u-zacht u-mt-xs u-lh-ruim">Tik op een tijd om die periode handmatig te corrigeren, een <b class="u-c-accent">gekleurde</b> waarde is al aangepast.</p>
    </div>`);

  /* periode-tabs */
  $$('#modalInhoud [data-bw-p]').forEach(b => b.onclick = () => { S.bijwerkKwart = b.dataset.bwP; toonBijwerkScherm(); });
  /* rij-koppelingen */
  $$('#modalInhoud [data-bw-start]').forEach(el => el.onclick = () => modalStartSpeler(nr, el.dataset.bwStart));
  $$('#modalInhoud [data-bw-wissel]').forEach(el => el.onclick = () => modalWisselAchteraf(nr, Number(el.dataset.bwWissel)));
  $$('#modalInhoud [data-bw-goal]').forEach(el => el.onclick = () => modalGoalCorrigeren(Number(el.dataset.bwGoal), {terugNaarBijwerk:true}));
  $$('#modalInhoud [data-bw-kaart]').forEach(el => el.onclick = () => modalKaartCorrigeren(Number(el.dataset.bwKaart), {terugNaarBijwerk:true}));
  $$('#modalInhoud [data-bw-speeltijd]').forEach(el => el.onclick = () => modalSpeeltijdCorrigeren(el.dataset.bwSpeeltijd, {kwart:nr, terugNaarBijwerk:true}));
  /* toevoeg-knoppen */
  $('#bwWisselNieuw').onclick = () => modalWisselAchteraf(nr, null);
  $('#bwSelectie').onclick = () => modalSelectie({terugNaarBijwerk:true, kwart:nr});
  $('#bwGoalNieuw').onclick = () => modalGoalToevoegen(nr);
  $('#bwKaartNieuw').onclick = () => modalKaart({kwart:nr, terugNaarBijwerk:true});
}

/* Houdt de wissels kloppend nadat de startopstelling is gewijzigd. Wissels
   horen bij een plek: het eerste "eruit" op die plek is de speler die er op dat
   moment stond. Wie er nu begon, kan dus afwijken van wie de wissel eerder
   noemde; dan zetten we de wissel om naar de juiste speler. true = er is
   iets aangepast. Alleen wissels op de gewijzigde plekken (slots) worden
   aangeraakt; de rest van de historie blijft zoals hij was. */
function harmoniseerWissels(k, slots){
  let veranderd = false;
  const bezet = Object.assign({}, k.lineup || {});
  for (const e of [...(k.events || [])].sort((a, b) => (a.sec || 0) - (b.sec || 0))){
    const nu = bezet[e.slot];
    if (slots.has(e.slot) && nu && e.uit !== nu && (e.uit || e.in)){ e.uit = nu; veranderd = true; }
    if (e.in) bezet[e.slot] = e.in; else delete bezet[e.slot];
  }
  return veranderd;
}

/* Zet pid (of niemand) als starter op slotId. Staat pid al op een andere
   startplek, dan wisselen de twee van plek. */
function zetStartSpeler(nr, slotId, pid){
  const w = S.wedstrijd, k = w.kwarten[nr];
  if (!k) return;
  k.lineup ||= {};
  const vorige = k.lineup[slotId];
  if (pid && vorige === pid){ S.bijwerkKwart = nr; toonBijwerkScherm(); return; }
  let van = null;
  if (pid){
    van = Object.keys(k.lineup).find(sl => k.lineup[sl] === pid) || null;
    if (van && van !== slotId){
      if (vorige) k.lineup[van] = vorige; else delete k.lineup[van];
    }
    k.lineup[slotId] = pid;
  } else {
    delete k.lineup[slotId];
  }
  const wisselsAangepast = harmoniseerWissels(k, new Set([slotId, van].filter(Boolean)));
  telGebruik('startopstelling_achteraf');
  bewaarWedstrijd();
  meld(wisselsAangepast ? 'Startopstelling bijgewerkt, wissels aangepast' : 'Startopstelling bijgewerkt');
  S.bijwerkKwart = nr; toonBijwerkScherm();
}

/* Kies wie er op een plek begon (vanuit het bijwerk-scherm). */
function modalStartSpeler(startNr, slotId){
  const w = S.wedstrijd;
  const nr = String(startNr);
  const k = w.kwarten[nr];
  if (!k){ toonBijwerkScherm(); return; }
  const kF = kwartFormatie(w, k);
  const pos = slotPositieNaam(w.format, kF, slotId);
  const huidig = (k.lineup || {})[slotId];
  const startSlot = pid => Object.keys(k.lineup || {}).find(sl => k.lineup[sl] === pid);
  /* Wie in deze periode pas via een wissel erin komt, kan niet óók starter
     worden (dan stond hij op twee plekken). Eerst de wissel aanpassen. */
  const komtLater = new Map();
  for (const e of (k.events || [])) if (e.in && !komtLater.has(e.in)) komtLater.set(e.in, e.sec || 0);

  const ids = [...new Set([...(w.selectie || []), ...(huidig ? [huidig] : [])])].filter(pid => speler(pid));
  const rij = pid => {
    const sl = startSlot(pid);
    const geblokkeerd = !sl && komtLater.has(pid);
    const status = sl ? 'op ' + esc(sl) : geblokkeerd ? 'wissel ' + gebeurtenisTijd(komtLater.get(pid), w) : 'bank';
    return `<div class="bijwerk-regel bw-start${geblokkeerd ? ' bw-auto' : ''}" data-bw-sp="${esc(pid)}"${geblokkeerd ? ' data-bw-blok="1"' : ''}>
      <span class="bw-start-nr">${esc(spelerNr(pid))}</span>
      <span class="bw-naam">${esc(spelerNaam(pid))}</span>
      <span class="bw-tijd">${status}${pid === huidig ? ' ✓' : ''}</span></div>`;
  };

  openModal(`
    <h2>Wie begon op ${esc(slotId)}?</h2>
    <p class="u-t-sm u-zacht u-mb-sm u-lh-ruim">${esc(periodeOmschrijving(w, nr))}${pos ? '<span class="sep" aria-hidden="true"></span>' + esc(pos) : ''}. Kies je een speler die op een andere startplek staat, dan wisselen die twee van plek.</p>
    <div class="bijwerk-blok">
      ${ids.map(rij).join('')}
      <div class="bijwerk-regel bw-start" data-bw-leeg="1"><span class="bw-naam u-zacht">Plek leeg laten</span></div>
    </div>
    <button class="knop licht vol u-mt-xs" id="bwStTerug" >‹ Terug naar overzicht</button>`);

  const terug = () => { S.bijwerkKwart = nr; toonBijwerkScherm(); };
  kruisNaarBijwerk(terug);
  $$('#modalInhoud [data-bw-sp]').forEach(el => el.onclick = () => {
    if (el.dataset.bwBlok){ meld('Deze speler komt pas via een wissel erin. Pas eerst die wissel aan.'); return; }
    zetStartSpeler(nr, slotId, el.dataset.bwSp);
  });
  $('#modalInhoud [data-bw-leeg]').onclick = () => zetStartSpeler(nr, slotId, null);
  $('#bwStTerug').onclick = terug;
}

/* Wissel achteraf toevoegen of een bestaande wissel-event bewerken — mét
   periodekeuze. Bij bewerken (eventIndex != null) staat de periode al vast op
   startNr; bij toevoegen kan de coach de periode kiezen. Een wissel is een
   event {in, uit, slot, sec, reden?} in de events-array van de gekozen periode.
   De uitgaande speler bepaalt het slot binnen de effectieve opstelling van die
   periode. */
function modalWisselAchteraf(startNr, eventIndex = null){
  const w = S.wedstrijd;
  const bestaand = eventIndex != null;
  const origineelNr = String(startNr);   // periode waar het bestaande event nu staat
  let nr = String(startNr);               // gekozen periode (kan wijzigen)

  /* Snapshot van het bestaande event vóór eventueel verplaatsen. */
  const ev = bestaand ? (w.kwarten[origineelNr]?.events||[])[eventIndex] : null;
  if (bestaand && !ev) { toonBijwerkScherm(); return; }
  const opts = { get k(){ return w.kwarten[nr]; } };

  /* Bouwt de veld/bank-lijsten voor de huidige periode. Bij bewerken tellen we
     de betrokken spelers altijd mee zodat ze selecteerbaar blijven. */
  function velden(){
    const k = opts.k;
    const l = k ? effectieveLineup(k) : {};
    const opVeld = Object.values(l).filter(pid => speler(pid));
    const bank = (w.selectie||[]).filter(pid => speler(pid) && !opVeld.includes(pid));
    return {opVeld, bank, l};
  }

  function teken(){
    const {opVeld, bank} = velden();
    const uitOpties = [...new Set([...(bestaand && ev.uit ? [ev.uit] : []), ...opVeld])].filter(pid => speler(pid));
    const inOpties  = [...new Set([...(bestaand && ev.in  ? [ev.in ] : []), ...bank ])].filter(pid => speler(pid));
    const opt = (pid, sel) => `<option value="${pid}" ${sel?'selected':''}>${esc(spelerNr(pid))}<span class="sep" aria-hidden="true"></span>${esc(spelerNaam(pid))}</option>`;

    openModal(`
      <h2>${bestaand ? 'Wissel aanpassen' : 'Vergeten wissel toevoegen'}</h2>
      ${bestaand ? '' : `<div class="bijwerk-uitleg">Voor een wissel die je tijdens de wedstrijd niet kon invoeren. “In minuut x ging … eruit en … erin.” De speeltijd wordt automatisch herberekend.</div>`}
      <div class="veldgroep"><label>Periode</label>${periodeKiesHtml(w, nr, 'bwWaPeriode')}</div>
      <div class="veldgroep"><label>Eruit (van het veld)</label>
        <select class="invoer" id="bwWaUit">${uitOpties.length ? uitOpties.map(pid => opt(pid, bestaand && pid===ev.uit)).join('') : '<option value="">— niemand op het veld —</option>'}</select></div>
      <div class="veldgroep"><label>Erin (van de bank)</label>
        <select class="invoer" id="bwWaIn">${inOpties.length ? inOpties.map(pid => opt(pid, bestaand && pid===ev.in)).join('') : '<option value="">— niemand op de bank —</option>'}</select></div>
      <div class="veldgroep"><label>Op welke minuut</label>${minSecInvoerHtml('bwWaMin','bwWaSec', bestaand ? (ev.sec||0) : Math.round((w.kwartduur||20)*60/2))}</div>
      <div class="veldgroep"><label>Reden (optioneel)</label>
        <div class="reden-rij" id="bwWaReden">${WISSEL_REDENEN.map(r =>
          `<button class="reden ${bestaand && ev.reden===r.id?'aan':''}" data-reden="${r.id}"><span class="ic">${r.ico?ico(r.ico,18):r.emoji}</span> ${r.label}</button>`).join('')}</div></div>
      ${bestaand ? `<button class="knop gevaar vol u-mb-xs" id="bwWaWeg" ><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg> Wissel verwijderen</button>` : ''}
      <button class="knop vol" id="bwWaOk">${bestaand ? 'Opslaan' : 'Wissel toevoegen'}</button>
      <button class="knop licht vol u-mt-xs" id="bwWaTerug" >‹ Terug naar overzicht</button>`);

    kruisNaarBijwerk(() => { S.bijwerkKwart = nr; toonBijwerkScherm(); });
    bindPeriodeKies('bwWaPeriode', nr, (gek) => { nr = gek; teken(); });

    let reden = bestaand ? (ev.reden || null) : null;
    $$('#bwWaReden [data-reden]').forEach(b => b.onclick = () => {
      const id = b.dataset.reden;
      reden = (reden === id) ? null : id;
      $$('#bwWaReden [data-reden]').forEach(x => x.classList.toggle('aan', x.dataset.reden === reden));
    });

    $('#bwWaOk').onclick = () => {
      const uit = $('#bwWaUit').value || null;
      const inP = $('#bwWaIn').value || null;
      if (!uit && !inP) return meld('Kies minstens een speler erin of eruit');
      if (uit && inP && uit === inP) return meld('Erin en eruit kunnen niet dezelfde speler zijn');
      const sec = leesMinSec('#bwWaMin','#bwWaSec');
      const k = w.kwarten[nr];
      if (!k){ meld('Deze periode bestaat niet'); return; }
      /* slot bepalen aan de hand van de uitgaande speler in de effectieve
         opstelling van de gekozen periode; valt terug op het oude slot. */
      const l = effectieveLineup(k);
      const slot = (uit && Object.keys(l).find(s => l[s] === uit)) || (bestaand ? ev.slot : null);
      const nieuw = {in: inP, uit, slot, sec};
      if (reden) nieuw.reden = reden;
      if (bestaand){
        if (nr !== origineelNr){
          /* Verplaatst naar een andere periode: uit de oude events halen en in
             de nieuwe periode toevoegen. */
          (w.kwarten[origineelNr].events ||= []).splice(eventIndex, 1);
          (k.events ||= []).push(nieuw);
        } else {
          (k.events ||= [])[eventIndex] = nieuw;
        }
      } else {
        (k.events ||= []).push(nieuw);
      }
      telGebruik(bestaand ? 'wissel_bewerkt_achteraf' : 'wissel_achteraf');
      bewaarWedstrijd();
      meld(bestaand ? 'Wissel bijgewerkt' : `Wissel toegevoegd, ${gebeurtenisTijd(sec, w)}`);
      S.bijwerkKwart = nr; toonBijwerkScherm();
    };
    const wegBtn = $('#bwWaWeg');
    if (wegBtn) wegBtn.onclick = () => {
      (w.kwarten[origineelNr].events||[]).splice(eventIndex, 1);
      bewaarWedstrijd(); meld('Wissel verwijderd');
      S.bijwerkKwart = origineelNr; toonBijwerkScherm();
    };
    $('#bwWaTerug').onclick = () => { S.bijwerkKwart = nr; toonBijwerkScherm(); };
  }
  teken();
}

/* Doelpunt achteraf toevoegen (met periode + kant + scorer + minuut). */
function modalGoalToevoegen(startNr){
  const w = S.wedstrijd;
  let nr = String(startNr);
  let type = 'voor';

  function teken(){
    const k = w.kwarten[nr];
    const l = k ? effectieveLineup(k) : {};
    const veldSpelers = Object.values(l).filter(pid => speler(pid));
    const overig = (w.selectie||[]).filter(pid => speler(pid) && !veldSpelers.includes(pid));
    const scorerOptie = pid => `<option value="${pid}">${esc(spelerNr(pid))}<span class="sep" aria-hidden="true"></span>${esc(spelerNaam(pid))}</option>`;

    openModal(`
      <h2>Doelpunt toevoegen</h2>
      <div class="veldgroep"><label>Periode</label>${periodeKiesHtml(w, nr, 'bwGtPeriode')}</div>
      <div class="veldgroep"><label>Soort</label>
        <div class="bijwerk-seg" id="bwGtType">
          <button data-t="voor" class="${type==='voor'?'aan':''}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg> Vóór ${esc(S.team?.naam||'ons')}</button>
          <button data-t="tegen" class="${type==='tegen'?'aan':''}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M3.4 19V7.6h17.2V19"/><path d="M9.2 7.6V19"/><path d="M14.8 7.6V19"/><path d="M3.4 13.3h17.2"/></svg> Tegen</button>
        </div></div>
      <div class="veldgroep"><label>Op welke minuut</label>${minSecInvoerHtml('bwGtMin','bwGtSec', Math.round((w.kwartduur||20)*60/2))}</div>
      ${type==='voor' ? `<div class="veldgroep"><label>Scorer (optioneel)</label>
        <select class="invoer" id="bwGtScorer">
          <option value="">Onbekend / geen maker</option>
          ${veldSpelers.length ? `<optgroup label="Op het veld">${veldSpelers.map(scorerOptie).join('')}</optgroup>` : ''}
          ${overig.length ? `<optgroup label="Overige selectie">${overig.map(scorerOptie).join('')}</optgroup>` : ''}
        </select></div>
      <div class="veldgroep"><label>Assist (optioneel)</label>
        <select class="invoer" id="bwGtAssist">
          <option value="">Geen assist</option>
          ${veldSpelers.length ? `<optgroup label="Op het veld">${veldSpelers.map(scorerOptie).join('')}</optgroup>` : ''}
          ${overig.length ? `<optgroup label="Overige selectie">${overig.map(scorerOptie).join('')}</optgroup>` : ''}
        </select></div>` : ''}
      <button class="knop vol" id="bwGtOk">Doelpunt toevoegen</button>
      <button class="knop licht vol u-mt-xs" id="bwGtTerug" >‹ Terug naar overzicht</button>`);

    kruisNaarBijwerk(() => { S.bijwerkKwart = nr; toonBijwerkScherm(); });
    bindPeriodeKies('bwGtPeriode', nr, (gek) => { nr = gek; teken(); });
    $$('#bwGtType button').forEach(b => b.onclick = () => { type = b.dataset.t; teken(); });

    $('#bwGtOk').onclick = () => {
      const sec = leesMinSec('#bwGtMin','#bwGtSec');
      const pid = type==='voor' ? ($('#bwGtScorer')?.value || null) : null;
      const assist = type==='voor' ? ($('#bwGtAssist')?.value || null) : null;
      const g = {type, pid, kwart: nr, sec};
      if (assist && assist !== pid) g.assist = assist;
      (w.goals ||= []).push(g);
      telGebruik('doelpunt_achteraf');
      bewaarWedstrijd();
      meld(type==='voor' ? `Doelpunt toegevoegd, ${gebeurtenisTijd(sec, w)}` : `Tegendoelpunt toegevoegd, ${gebeurtenisTijd(sec, w)}`);
      S.bijwerkKwart = nr; toonBijwerkScherm();
    };
    $('#bwGtTerug').onclick = () => { S.bijwerkKwart = nr; toonBijwerkScherm(); };
  }
  teken();
}

/* ==================== DOELPUNTEN ==================== */
function registreerGoal({type, pid = null, assist = null, sec = null}){
  const w = S.wedstrijd;
  if (sec == null) sec = Math.round(klokSec(huidigKwart()));
  const g = {type, pid, kwart: S.kwart, sec};
  if (type === 'voor' && assist && assist !== pid) g.assist = assist;
  (w.goals ||= []).push(g);
  telGebruik('doelpunt');
  if (g.assist) telGebruik('assist');
  if (navigator.vibrate) navigator.vibrate(type === 'voor' ? [90,60,90,60,200] : 120);
  meld(type === 'voor' ? `GOAL! ${pid ? spelerNaam(pid) : S.team.naam}${g.assist ? ', assist ' + spelerNaam(g.assist) : ''}` : `Tegendoelpunt, ${mmss(sec)}`);
  bewaarWedstrijd(); renderWedstrijd();
}

/* [20260928e] Doelpunt in twee tikken: eerst de scorer, dan de assist (of
   "Geen assist"). De wedstrijdtijd leggen we vast bij de eerste tik, zodat
   nadenken over de assist de minuut niet verschuift. */
function modalGoalVoor(){
  const k = huidigKwart();
  const l = effectieveLineup(k);
  const veldSpelers = Object.values(l).filter(pid => speler(pid));
  if (!veldSpelers.length){ registreerGoal({type:'voor'}); return; }
  const sec = Math.round(klokSec(k));
  const chip = (pid, attr, uit = false) => `
      <div class="chip${uit ? ' goal-chip-uit' : ''}" ${uit ? '' : `${attr}="${pid}"`} style="cursor:${uit ? 'default' : 'pointer'}">
        <div class="shirt">${esc(spelerNr(pid))}</div>
        <div class="naam">${esc(spelerNaam(pid))}</div>
      </div>`;
  const stapAssist = (scorer) => {
    openModal(`
      <h2><b class="aanvoerder-a">A</b> Assist door?</h2>
      <p class="goal-scorer-sam"><b>${esc(spelerNaam(scorer))}</b> scoort<span class="sep" aria-hidden="true"></span>${mmss(sec)}</p>
      <div class="goal-kies">${veldSpelers.map(pid => chip(pid, 'data-assist-pid', pid === scorer)).join('')}</div>
      <button class="knop vol u-mt-sm" id="mGeenAssist" >Geen assist</button>`);
    $$('#modalInhoud [data-assist-pid]').forEach(c => c.onclick = () => { sluitModal(); registreerGoal({type:'voor', pid: scorer, assist: c.dataset.assistPid, sec}); });
    $('#mGeenAssist').onclick = () => { sluitModal(); registreerGoal({type:'voor', pid: scorer, sec}); };
  };
  openModal(`
    <h2><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg> Wie scoorde er?</h2>
    <div class="goal-kies">${veldSpelers.map(pid => chip(pid, 'data-goal-pid')).join('')}</div>
    <button class="knop licht vol u-mt-sm" id="mGoalOnbekend" >Eigen doelpunt tegenstander / onbekend</button>`);
  $$('#modalInhoud [data-goal-pid]').forEach(c => c.onclick = () => stapAssist(c.dataset.goalPid));
  $('#mGoalOnbekend').onclick = () => { sluitModal(); registreerGoal({type:'voor', sec}); };
}

/* ---------- Doelpunt corrigeren (verkeerde knop / scorer / periode / minuut) ---------- */
function modalGoalCorrigeren(i, opties = {}){
  const w = S.wedstrijd;
  const g = (w.goals||[])[i];
  if (!g) return;
  let nr = g.kwart != null ? String(g.kwart) : S.kwart;
  const terug = () => { if (opties.terugNaarBijwerk){ S.bijwerkKwart = nr; toonBijwerkScherm(); } else { sluitModal(); renderWedstrijd(); } };

  function teken(){
    const g2 = (w.goals||[])[i]; if (!g2) { terug(); return; }
    const k = w.kwarten[nr] || huidigKwart();
    const l = effectieveLineup(k);
    const veldSpelers = Object.values(l).filter(pid => speler(pid));
    const overig = (w.selectie||[]).filter(pid => speler(pid) && !veldSpelers.includes(pid));
    const huidigeOmschrijving = g2.type === 'voor'
      ? (g2.pid ? spelerNaam(g2.pid) : 'doelpunt (onbekende maker)')
      : 'tegendoelpunt';
    const scorerOptie = pid => `<option value="${pid}" ${g2.pid===pid?'selected':''}>${esc(spelerNr(pid))}<span class="sep" aria-hidden="true"></span>${esc(spelerNaam(pid))}</option>`;
    const assistOptie = pid => `<option value="${pid}" ${g2.assist===pid?'selected':''}>${esc(spelerNr(pid))}<span class="sep" aria-hidden="true"></span>${esc(spelerNaam(pid))}</option>`;
    // assist van iemand die niet (meer) in de lijsten staat: toch tonen
    const assistExtra = g2.assist && !veldSpelers.includes(g2.assist) && !overig.includes(g2.assist) && speler(g2.assist)
      ? assistOptie(g2.assist) : '';

    openModal(`
      <h2>Doelpunt corrigeren</h2>
      <p class="u-t-md u-zacht u-mb-md">Nu geregistreerd als <b>${esc(huidigeOmschrijving)}</b> op ${gebeurtenisTijd(g2.sec, w)}.</p>
      <div class="veldgroep"><label>Periode</label>${periodeKiesHtml(w, nr, 'mGcPeriode')}</div>
      <div class="veldgroep u-mb-sm"><label>Minuut in de periode</label>${minSecInvoerHtml('mGcMin','mGcSec', g2.sec||0)}
        <p class="u-t-xs u-zacht u-mt-xs u-lh-ruim">Blessuretijd mag: bij een helft van ${String(w.kwartduur).replace('.',',')} min vul je 40+3 in als <b>43</b> min.</p></div>
      <div class="correctie-opties">
        ${g2.type === 'voor' ? `
        <div class="veldgroep u-mb-xs"><label>Andere scorer kiezen</label>
          <select class="invoer" id="mGcScorer">
            <option value="">Onbekend / geen maker</option>
            ${veldSpelers.length ? `<optgroup label="Op het veld">${veldSpelers.map(scorerOptie).join('')}</optgroup>` : ''}
            ${overig.length ? `<optgroup label="Overige selectie">${overig.map(scorerOptie).join('')}</optgroup>` : ''}
          </select></div>
        <div class="veldgroep u-mb-xs"><label>Assist</label>
          <select class="invoer" id="mGcAssist">
            <option value="">Geen assist</option>${assistExtra}
            ${veldSpelers.length ? `<optgroup label="Op het veld">${veldSpelers.map(assistOptie).join('')}</optgroup>` : ''}
            ${overig.length ? `<optgroup label="Overige selectie">${overig.map(assistOptie).join('')}</optgroup>` : ''}
          </select></div>
        ` : `
        <p class="u-t-md u-c-ink u-mb-xs">Dit staat als doelpunt voor de tegenstander.</p>
        `}
        <button class="knop licht vol" id="mGcKant">${g2.type === 'voor' ? '↔ Toch een tegendoelpunt' : '↔ Maak er een doelpunt vóór '+esc(S.team.naam)+' van'}</button>
        <button class="knop gevaar vol u-mt-xs" id="mGcWeg" ><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg> Doelpunt verwijderen</button>
        <button class="knop vol u-mt-xs" id="mGcOk" >Opslaan</button>
      </div>`);

    if (opties.terugNaarBijwerk) kruisNaarBijwerk(terug);
    /* Periodewissel: onthoud eerst de zojuist ingevulde scorer/minuut niet —
       we her-renderen met de nieuwe periode-context (andere veldspelers). */
    bindPeriodeKies('mGcPeriode', nr, (gek) => { nr = gek; teken(); });

    const bewaarBasis = () => {
      w.goals[i].sec = leesMinSec('#mGcMin','#mGcSec');
      w.goals[i].kwart = nr;
    };
    $('#mGcOk').onclick = () => {
      bewaarBasis();
      if (w.goals[i].type === 'voor'){
        const sc = $('#mGcScorer'); if (sc) w.goals[i].pid = sc.value || null;
        const as = $('#mGcAssist');
        if (as){
          const a = as.value || null;
          if (a && a !== w.goals[i].pid) w.goals[i].assist = a; else delete w.goals[i].assist;
        }
      }
      bewaarWedstrijd(); meld('Doelpunt bijgewerkt'); terug();
    };
    $('#mGcKant').onclick = () => {
      bewaarBasis();
      if (w.goals[i].type === 'voor'){ w.goals[i].type = 'tegen'; w.goals[i].pid = null; delete w.goals[i].assist; }
      else { w.goals[i].type = 'voor'; }
      bewaarWedstrijd(); meld('Doelpunt omgezet'); terug();
    };
    $('#mGcWeg').onclick = () => {
      w.goals.splice(i,1);
      bewaarWedstrijd(); meld('Doelpunt verwijderd'); terug();
    };
  }
  teken();
}

/* ==================== KAARTEN & STRAFFEN ==================== */
function modalKaart(opties = {}){
  const w = S.wedstrijd;
  const achteraf = !!opties.terugNaarBijwerk;
  let nr = opties.kwart != null ? String(opties.kwart) : S.kwart;
  const terug = () => { if (achteraf){ S.bijwerkKwart = nr; toonBijwerkScherm(); } else { sluitModal(); renderWedstrijd(); } };
  const duur = tijdstrafSec();

  function teken(){
    const k = w.kwarten[nr];
    const l = k ? effectieveLineup(k) : {};
    const veldSpelers = Object.values(l).filter(pid => speler(pid));
    const bankSpelers = (w.selectie||[]).filter(pid => !veldSpelers.includes(pid) && speler(pid));
    const alle = [...veldSpelers, ...bankSpelers];
    if (!alle.length) return meld('Voeg eerst spelers toe aan de selectie');
    const optie = pid => `<option value="${pid}">${esc(spelerNr(pid))}<span class="sep" aria-hidden="true"></span>${esc(spelerNaam(pid))}${veldSpelers.includes(pid)?' (veld)':' (bank)'}</option>`;
    const startSec = achteraf ? Math.round((w.kwartduur||20)*60/2) : Math.round(klokSec(k));
    openModal(`
      <h2>${achteraf ? 'Kaart toevoegen' : 'Kaart of straf'}</h2>
      ${achteraf ? `<div class="veldgroep"><label>Periode</label>${periodeKiesHtml(w, nr, 'mKPeriode')}</div>` : ''}
      <div class="veldgroep"><label>Speler</label>
        <select class="invoer" id="mKSpeler">${alle.map(optie).join('')}</select></div>
      <div class="veldgroep"><label>Type</label>
        <div class="segment" id="mKType">
          <button data-t="geel" class="actief"><span class="kaartje geel" aria-hidden="true"></span> Geel</button>
          <button data-t="tijd"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.6"/><path d="M12 7.2V12l3.4 2.2"/></svg> Tijdstraf</button>
          <button data-t="rood"><span class="kaartje rood" aria-hidden="true"></span> Rood</button>
        </div></div>
      ${achteraf ? `<div class="veldgroep"><label>Op welke minuut</label>${minSecInvoerHtml('mKMin','mKSec', startSec)}</div>` : ''}
      <p class="u-t-sm u-zacht u-mb-md u-lh-ruim">
        <b>KNVB:</b> een gele kaart is een waarschuwing. Bij een tweede gele in dezelfde wedstrijd volgt rood. In de B-categorie geldt een tijdstrafregeling: ${Math.round(duur/60)} minuten voor deze leeftijd${duur===300?' (pupillen)':' (junioren/senioren)'}.
      </p>
      <button class="knop vol" id="mKOk">Registreren</button>
      ${achteraf ? `<button class="knop licht vol u-mt-xs" id="mKTerug" >‹ Terug naar overzicht</button>` : ''}`);
    if (achteraf) { bindPeriodeKies('mKPeriode', nr, (gek) => { nr = gek; teken(); }); kruisNaarBijwerk(terug); }
    let type = 'geel';
    $$('#mKType button').forEach(b => b.onclick = () => {
      $$('#mKType button').forEach(x=>x.classList.remove('actief')); b.classList.add('actief'); type = b.dataset.t;
    });
    $('#mKOk').onclick = () => {
      const k2 = w.kwarten[nr];
      const pid = $('#mKSpeler').value;
      const sec = achteraf ? leesMinSec('#mKMin','#mKSec') : Math.round(klokSec(k2));
      const kaart = {pid, type, kwart: nr, sec};
      if (type === 'tijd') kaart.duur = duur;
      (w.kaarten ||= []).push(kaart);
      telGebruik(achteraf ? 'kaart_achteraf' : 'kaart');
      if (type === 'geel'){
        const aantalGeel = w.kaarten.filter(c => c.pid === pid && c.type === 'geel').length;
        if (aantalGeel >= 2){
          w.kaarten.push({pid, type:'rood', kwart: nr, sec, auto:true});
          meld(`Tweede gele kaart → rode kaart voor ${spelerNaam(pid)}`);
        }
      }
      if (type === 'rood' || w.kaarten[w.kaarten.length-1].type === 'rood'){
        const lineup = effectieveLineup(k2);
        const slot = Object.keys(lineup).find(s => lineup[s] === pid);
        if (slot){
          if (kwartLive(k2) || achteraf) k2.events.push({in: null, uit: pid, slot, sec});
          else delete k2.lineup[slot];
        }
      }
      if (navigator.vibrate) navigator.vibrate(type==='rood' ? [300,100,300] : 180);
      bewaarWedstrijd();
      meld(`${KAART_NAAM[type]} voor ${spelerNaam(pid)} geregistreerd`);
      terug();
    };
    const tBtn = $('#mKTerug'); if (tBtn) tBtn.onclick = terug;
  }
  teken();
}

/* ---------- Kaart corrigeren ---------- */
function modalKaartCorrigeren(i, opties = {}){
  const w = S.wedstrijd;
  const c = (w.kaarten||[])[i];
  if (!c) return;
  let nr = c.kwart != null ? String(c.kwart) : S.kwart;
  const terug = () => { if (opties.terugNaarBijwerk){ S.bijwerkKwart = nr; toonBijwerkScherm(); } else { sluitModal(); renderWedstrijd(); } };
  const alle = (w.selectie||[]).filter(pid => speler(pid));
  const optie = pid => `<option value="${pid}" ${c.pid===pid?'selected':''}>${esc(spelerNr(pid))}<span class="sep" aria-hidden="true"></span>${esc(spelerNaam(pid))}</option>`;
  openModal(`
    <h2>Kaart corrigeren</h2>
    <p class="u-t-md u-zacht u-mb-md">Nu: <b>${esc(KAART_NAAM[c.type])}</b> voor <b>${esc(spelerNaam(c.pid))}</b> op ${gebeurtenisTijd(c.sec, w)}.</p>
    <div class="veldgroep"><label>Periode</label>${periodeKiesHtml(w, nr, 'mKcPeriode')}</div>
    <div class="veldgroep"><label>Andere speler</label>
      <select class="invoer" id="mKcSpeler">${alle.map(optie).join('')}</select></div>
    <div class="veldgroep"><label>Minuut in de periode</label>${minSecInvoerHtml('mKcMin','mKcSec', c.sec||0)}</div>
    <div class="correctie-opties">
      <button class="knop gevaar vol" id="mKcWeg"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M5.4 7.4h13.2"/><path d="M7.4 7.4 8.3 20h7.4l.9-12.6"/><path d="M9.6 4.4h4.8l.6 3H9z"/><path d="M10.6 11v5.4M13.4 11v5.4"/></svg> Kaart verwijderen</button>
      <button class="knop vol u-mt-xs" id="mKcOk" >Opslaan</button>
    </div>`);
  if (opties.terugNaarBijwerk) kruisNaarBijwerk(terug);
  bindPeriodeKies('mKcPeriode', nr, (gek) => { nr = gek; });
  $('#mKcOk').onclick = () => {
    w.kaarten[i].pid = $('#mKcSpeler').value;
    w.kaarten[i].sec = leesMinSec('#mKcMin','#mKcSec');
    w.kaarten[i].kwart = nr;
    bewaarWedstrijd(); meld('Kaart aangepast'); terug();
  };
  $('#mKcWeg').onclick = () => {
    w.kaarten.splice(i,1);
    bewaarWedstrijd(); meld('Kaart verwijderd'); terug();
  };
}

/* ==================== WEDSTRIJDVERSLAG ==================== */
function genereerVerslag(){
  const w = S.wedstrijd;
  const voor = (w.goals||[]).filter(g => g.type==='voor').length;
  const tegen = (w.goals||[]).filter(g => g.type==='tegen').length;
  const uitslag = w.thuis ? `${voor}–${tegen}` : `${tegen}–${voor}`;
  const wedstrijdtitel = isToernooi(w)
    ? `${w.tegenstander}`
    : (w.thuis ? `${S.team.naam} – ${w.tegenstander}` : `${w.tegenstander} – ${S.team.naam}`);
  const ww = voor > tegen ? 'gewonnen' : voor < tegen ? 'verloren' : 'gelijkgespeeld';

  const lines = [];
  lines.push(`${wedstrijdtitel}`);
  lines.push(`${new Date(w.datum+'T12:00').toLocaleDateString('nl-NL',{weekday:'long',day:'numeric',month:'long',year:'numeric'})}`);
  lines.push('');
  if (w.doel){ lines.push(`Wedstrijddoel: ${w.doel}`); lines.push(''); }
  if (voor + tegen > 0 || analyseWedstrijd(w).kwarten){ lines.push(`Eindstand: ${uitslag} (${ww})`); lines.push(''); }

  const scorers = {};
  for (const g of (w.goals||[])) if (g.type==='voor' && g.pid) scorers[g.pid] = (scorers[g.pid]||0)+1;
  const top = Object.entries(scorers).sort((a,b) => b[1]-a[1]);
  if (top.length){
    lines.push('Doelpuntenmakers:');
    for (const [pid, n] of top) lines.push(`• ${spelerNaam(pid)}${n>1?` (${n}×)`:''}`);
    lines.push('');
  }
  const gevers = {};
  for (const g of (w.goals||[])) if (g.type==='voor' && g.assist) gevers[g.assist] = (gevers[g.assist]||0)+1;
  const topA = Object.entries(gevers).sort((a,b) => b[1]-a[1]);
  if (topA.length){
    lines.push('Assists:');
    for (const [pid, n] of topA) lines.push(`• ${spelerNaam(pid)}${n>1?` (${n}×)`:''}`);
    lines.push('');
  }
  {
    const nP = w.periodes || Object.keys(w.kwarten||{}).length || 4;
    const uniek = aanvoerdersInWedstrijd(w);
    let ingevuld = 0; for (let i = 1; i <= nP; i++) if (aanvoerderVan(w, i)) ingevuld++;
    if (uniek.length === 1 && ingevuld === nP){
      lines.push(`Aanvoerder: ${spelerNaam(uniek[0])}`); lines.push('');
    } else if (uniek.length){
      lines.push('Aanvoerder:');
      for (let i = 1; i <= nP; i++){
        const pid = aanvoerderVan(w, i);
        if (pid) lines.push(`• ${periodeLabel(w, String(i))}: ${spelerNaam(pid)}`);
      }
      lines.push('');
    }
  }

  const a = analyseWedstrijd(w);
  if (a.kwarten){
    lines.push('Speeltijd:');
    const sorted = [...(w.selectie||[])].filter(pid => speler(pid) && a.tijd[pid])
      .sort((x,y) => (a.tijd[y]||0) - (a.tijd[x]||0));
    for (const pid of sorted){
      const kk = a.keeper[pid] ? ` (${a.keeper[pid]}× keeper)` : '';
      lines.push(`• ${spelerNaam(pid)}: ${uurMin(a.tijd[pid])}${kk}`);
    }
    const nietGespeeld = (w.selectie||[]).filter(pid => speler(pid) && !a.tijd[pid]);
    if (nietGespeeld.length) lines.push(`• Niet ingezet: ${nietGespeeld.map(spelerNaam).join(', ')}`);
    lines.push('');
  }

  const heeftWissels = periodeNrs(w).some(nr => (w.kwarten[nr]?.events||[]).length);
  if (heeftWissels){
    lines.push('Wissels:');
    for (const nr of periodeNrs(w)){
      const k = w.kwarten[nr];
      if (!k.events?.length) continue;
      lines.push(`  ${periodeLabel(w, nr)}:`);
      for (const e of [...k.events].sort((a,b)=>a.sec-b.sec)){
        const t = gebeurtenisTijd(e.sec, w);
        if (e.in && e.uit) lines.push(`  • ${t} — ${spelerNaam(e.in)} in voor ${spelerNaam(e.uit)}`);
        else if (e.in)     lines.push(`  • ${t} — ${spelerNaam(e.in)} erin`);
        else if (e.uit)    lines.push(`  • ${t} — ${spelerNaam(e.uit)} eruit`);
      }
    }
    lines.push('');
  }

  if ((w.kaarten||[]).filter(c => !c.auto).length){
    lines.push('Kaarten:');
    for (const c of [...w.kaarten].filter(c => !c.auto).sort((a,b)=>a.sec-b.sec)){
      const lbl = periodeLabel(w, String(c.kwart));
      const txt = c.type === 'tijd' ? `tijdstraf ${Math.round(c.duur/60)} min` : KAART_NAAM[c.type];
      lines.push(`• ${spelerNaam(c.pid)} — ${txt} (${lbl}, ${gebeurtenisTijd(c.sec, w)})`);
    }
    lines.push('');
  }
  return lines.join('\n').trim();
}

/* ---- AI-wedstrijdverslag ----
   We laten Claude (server-side Cloud Function 'genereerVerslagAI', europe-west1)
   een levendig, vlot lopend verslagje schrijven. AVG: er gaan NOOIT namen van
   (minderjarige) spelers naar het model. In plaats daarvan sturen we neutrale
   labels ("Speler 1", "Speler 2", …); ná het antwoord zetten we die labels
   client-side terug naar de echte namen. Zo blijft alle herleidbare data op het
   toestel. Lukt de AI-generatie niet, dan valt de modal terug op de kale
   feitentekst uit genereerVerslag(). */
function genereerVerslagData(){
  const w = S.wedstrijd;
  const voor = (w.goals||[]).filter(g => g.type==='voor').length;
  const tegen = (w.goals||[]).filter(g => g.type==='tegen').length;
  const ww = voor > tegen ? 'gewonnen' : voor < tegen ? 'verloren' : 'gelijkgespeeld';

  // Pseudonimiseer elke betrokken speler-id naar een neutraal label.
  const labels = {};                 // pid -> "Speler N"
  const naamVoor = {};               // "Speler N" -> echte naam (blijft client-side)
  let teller = 0;
  const label = (pid) => {
    if (!pid) return null;
    if (!labels[pid]){
      teller++;
      labels[pid] = 'Speler ' + teller;
      naamVoor[labels[pid]] = spelerNaam(pid);
    }
    return labels[pid];
  };

  const scorers = {};
  for (const g of (w.goals||[])) if (g.type==='voor' && g.pid) scorers[g.pid] = (scorers[g.pid]||0)+1;
  const doelpunten = Object.entries(scorers)
    .sort((a,b) => b[1]-a[1])
    .map(([pid,n]) => ({ speler: label(pid), aantal: n }));
  const gevers = {};
  for (const g of (w.goals||[])) if (g.type==='voor' && g.assist) gevers[g.assist] = (gevers[g.assist]||0)+1;
  const assists = Object.entries(gevers)
    .sort((a,b) => b[1]-a[1])
    .map(([pid,n]) => ({ speler: label(pid), aantal: n }));

  const a = analyseWedstrijd(w);
  const speeltijd = [];
  if (a.kwarten){
    for (const pid of (w.selectie||[]).filter(pid => speler(pid) && a.tijd[pid])){
      speeltijd.push({ speler: label(pid), minuten: Math.round((a.tijd[pid]||0)/60),
        keerKeeper: a.keeper[pid] || 0 });
    }
  }

  const data = {
    team: S.team?.naam || 'ons team',
    tegenstander: w.tegenstander || 'de tegenstander',
    thuis: !!w.thuis,
    toernooi: isToernooi(w),
    datum: w.datum || null,
    doel: w.doel || null,
    doelBin: voor, doelTegen: tegen, resultaat: ww,
    aanvoerder: (() => {
      const u = aanvoerdersInWedstrijd(w);
      return u.length === 1 ? label(u[0]) : (u.length ? u.map(label).join(', ') : null);
    })(),
    aanvoerdersPerPeriode: (() => {
      const nP = w.periodes || Object.keys(w.kwarten||{}).length || 4;
      const o = {};
      for (let i = 1; i <= nP; i++){ const pid = aanvoerderVan(w, i); if (pid) o[periodeLabel(w, String(i))] = label(pid); }
      return Object.keys(o).length ? o : null;
    })(),
    doelpunten,
    ...(assists.length ? { assists } : {}),
    speeltijd,
  };
  return { data, naamVoor };
}

/* Zet neutrale labels ("Speler 3") in de AI-tekst terug naar echte namen. */
function herstelNamen(tekst, naamVoor){
  let t = String(tekst);
  // langste labels eerst, zodat "Speler 12" niet half door "Speler 1" wordt geraakt
  for (const lbl of Object.keys(naamVoor).sort((a,b) => b.length - a.length)){
    t = t.split(lbl).join(naamVoor[lbl]);
  }
  return t;
}

async function modalVerslag(){
  telGebruik('verslag_ai');
  const fallback = genereerVerslag();
  openModal(`
    <h2><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="5" y="4.5" width="14" height="16" rx="2.2"/><path d="M9 3.2h6v3H9z"/><path d="M8.8 11.4h6.4"/><path d="M8.8 15.4h4"/></svg> Wedstrijdverslag</h2>
    <div id="mVLaad" class="u-zacht u-t-md" style="display:flex;align-items:center;gap:var(--space-sm);padding:var(--space-lg) var(--space-2xs)">
      <span class="mV-spin" aria-hidden="true"></span>
      <span>Cluppie schrijft het verslag…</span>
    </div>
    <textarea class="invoer" id="mVTekst" style="display:none;min-height:280px;font-family:inherit;line-height:1.55;resize:vertical;font-size:calc(13.5px * var(--fs))"></textarea>
    <p id="mVHint" style="display:none;font-size:calc(12px * var(--fs));color:var(--ink-2);margin:8px 0 14px">Je kunt de tekst nog aanpassen voordat je hem deelt.</p>
    <div id="mVKnoppen" style="display:none">
      <button class="knop vol" id="mVDeel">${ico('admin-upload',16)} Delen / kopiëren</button>
      <button class="knop licht vol u-mt-xs" id="mVFeiten" ><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 19V10"/><path d="M11 19V5"/><path d="M18 19v-7"/></svg> Toon kale feiten</button>
    </div>`);

  const toonTekst = (tekst, isAI) => {
    const laad = $('#mVLaad'); if (laad) laad.style.display = 'none';
    const ta = $('#mVTekst'); ta.style.display = ''; ta.value = tekst;
    $('#mVHint').style.display = ''; $('#mVKnoppen').style.display = '';
    // Bij de AI-versie kun je terugvallen op de feiten; bij de feiten verbergen.
    const fk = $('#mVFeiten'); if (fk) fk.style.display = isAI ? '' : 'none';
  };

  const koppelKnoppen = () => {
    $('#mVDeel').onclick = async () => {
      const t = $('#mVTekst').value;
      try {
        if (navigator.share) await navigator.share({title:'Wedstrijdverslag', text:t});
        else { await navigator.clipboard.writeText(t); meld('Verslag gekopieerd'); }
      } catch { try { await navigator.clipboard.writeText(t); meld('Verslag gekopieerd'); } catch { meld('Kon niet kopiëren'); } }
    };
    const fk = $('#mVFeiten');
    if (fk) fk.onclick = () => toonTekst(fallback, false);
  };
  koppelKnoppen();

  // Probeer de AI-versie; val bij elke hapering terug op de feitentekst.
  try {
    const { data, naamVoor } = genereerVerslagData();
    const res = await httpsCallable(functions, 'genereerVerslagAI')({ data });
    const ruw = res?.data?.verslag;
    if (ruw && $('#mVTekst')){          // modal kan intussen gesloten zijn
      toonTekst(herstelNamen(ruw, naamVoor), true);
    } else if ($('#mVTekst')){
      toonTekst(fallback, false);
    }
  } catch (err){
    console.warn('[verslag] AI-generatie mislukt, val terug op feiten:', err?.code, err?.message);
    if ($('#mVTekst')) toonTekst(fallback, false);
  }
}

/* ==================== OPSTELLING-LOGICA ==================== */
function plaats(pid, slotId){
  const k = huidigKwart(), live = kwartLive(k);
  const l = effectieveLineup(k);
  const huidigeSlot = Object.keys(l).find(s => l[s] === pid);
  const bezet = l[slotId];
  if (huidigeSlot === slotId) return;
  if (huidigeSlot){
    delete k.lineup[huidigeSlot];
    if (k.lineup[slotId] !== undefined || bezet){
      const ander = k.lineup[slotId];
      if (ander !== undefined){ k.lineup[huidigeSlot] = ander; }
      for (const e of k.events){ if (e.slot === slotId) e.slot = huidigeSlot; else if (e.slot === huidigeSlot) e.slot = slotId; }
    }
    k.lineup[slotId] = pid;
  } else if (live){
    const sec = Math.round(klokSec(k));
    k.events.push({in: pid, uit: bezet || null, slot: slotId, sec});
    telGebruik('wissel_direct');
    if (bezet){
      meld(`${spelerNaam(pid)} erin, ${spelerNaam(bezet)} eruit, ${mmss(sec)}`);
      S.geselecteerd = null;
      bewaarWedstrijd(); renderWedstrijd();
      modalWisselReden(k, k.events.length - 1); // facultatieve reden vragen
      return;
    }
  } else {
    k.lineup[slotId] = pid;
  }
  S.geselecteerd = null;
  bewaarWedstrijd(); renderWedstrijd();
}
function naarBank(pid){
  const k = huidigKwart(), live = kwartLive(k);
  const l = effectieveLineup(k);
  const slot = Object.keys(l).find(s => l[s] === pid);
  if (!slot){ S.geselecteerd = null; renderWedstrijd(); return; }
  if (live){
    const sec = Math.round(klokSec(k));
    k.events.push({in: null, uit: pid, slot, sec});
    telGebruik('wissel_direct');
    meld(`${spelerNaam(pid)} eruit, ${mmss(sec)}`);
    S.geselecteerd = null;
    bewaarWedstrijd(); renderWedstrijd();
    modalWisselReden(k, k.events.length - 1); // facultatieve reden vragen
    return;
  } else delete k.lineup[slot];
  S.geselecteerd = null;
  bewaarWedstrijd(); renderWedstrijd();
}

/* Facultatieve wisselreden koppelen aan een wissel-event. Nooit verplicht:
   de wissel is al doorgevoerd; dit is een korte, weg-te-tikken keuze achteraf. */
function modalWisselReden(k, eventIndex){
  const e = (k.events||[])[eventIndex];
  if (!e || !e.uit) return; // reden hoort bij iemand die eruit gaat
  const naam = spelerNaam(e.uit);
  const huidig = e.reden || null;
  openModal(`
    <h2>Reden wissel <span class="u-t-sm u-zacht" style="font-weight:500;text-transform:none;letter-spacing:0">(optioneel)</span></h2>
    <p class="u-t-sm u-zacht u-mb-sm">${esc(naam)} naar de bank<span class="sep" aria-hidden="true"></span>${mmss(e.sec)}</p>
    <div class="reden-rij" id="mWrRedenen">${WISSEL_REDENEN.map(r =>
      `<button class="reden ${huidig===r.id?'aan':''}" data-reden="${r.id}"><span class="ic">${r.ico?ico(r.ico,18):r.emoji}</span> ${r.label}</button>`).join('')}</div>
    <div class="disc-blok ${huidig==='gedrag'?'zicht':''}" id="mWrDisc">
      <label class="disc-toggle">
        <input type="checkbox" id="mWrDiscChk" ${e.disciplinair?'checked':''}>
        <span class="disc-toggle-t">Disciplinaire reservebeurt</span>
      </label>
      <div class="disc-uitleg">Deze bankbeurt telt <b>niet mee</b> in het speelminuten-percentage van de speler, zo verlaagt een strafmoment zijn eerlijke gemiddelde niet. Altijd terug te zien in het wedstrijdlog.</div>
      <input class="disc-notitie ${e.disciplinair?'zicht':''}" id="mWrDiscNotitie" placeholder="Reden (optioneel, alleen voor coaches)" value="${esc(e.discNotitie||'')}">
    </div>
    <button class="knop vol fluo u-mt-md" id="mWrOk" >Opslaan</button>
    <button class="knop vol licht u-mt-xs" id="mWrGeen" >${huidig?'Reden wissen':'Zonder reden'}</button>`);

  let gekozen = huidig;
  const discBlok = $('#mWrDisc'), discChk = $('#mWrDiscChk'), discNot = $('#mWrDiscNotitie');
  const werkDiscBij = () => {
    discBlok.classList.toggle('zicht', gekozen === 'gedrag');
    if (gekozen !== 'gedrag'){ discChk.checked = false; discNot.classList.remove('zicht'); }
  };
  $$('#mWrRedenen [data-reden]').forEach(b => b.onclick = () => {
    const id = b.dataset.reden;
    gekozen = (gekozen === id) ? null : id;
    $$('#mWrRedenen [data-reden]').forEach(x => x.classList.toggle('aan', x.dataset.reden === gekozen));
    werkDiscBij();
  });
  discChk.onchange = () => discNot.classList.toggle('zicht', discChk.checked);
  $('#mWrOk').onclick = () => {
    if (gekozen) e.reden = gekozen; else delete e.reden;
    // disciplinaire vlag alleen bij reden 'gedrag'
    if (gekozen === 'gedrag' && discChk.checked){
      e.disciplinair = true;
      const n = discNot.value.trim();
      if (n) e.discNotitie = n; else delete e.discNotitie;
    } else {
      delete e.disciplinair; delete e.discNotitie;
    }
    sluitModal(); bewaarWedstrijd(); renderWedstrijd();
  };
  $('#mWrGeen').onclick = () => {
    delete e.reden; delete e.disciplinair; delete e.discNotitie;
    sluitModal(); bewaarWedstrijd(); renderWedstrijd();
  };
}

/* Reden voor een speler die (vooraf) op de bank start. Bij reden 'gedrag' kan de
   coach een disciplinaire reservebeurt aanvinken; die banktijd telt dan niet mee
   in het speelminuten-percentage. Opgeslagen op w.startBankReden[pid]. */
function modalStartBankReden(pid){
  const w = S.wedstrijd;
  w.startBankReden ||= {};
  const huidig = w.startBankReden[pid] || null;
  openModal(`
    <h2>Bankbeurt <span class="u-t-sm u-zacht" style="font-weight:500;text-transform:none;letter-spacing:0">(optioneel)</span></h2>
    <p class="u-t-sm u-zacht u-mb-sm">${esc(spelerNaam(pid))} start op de bank. Waarom? Dit leg je vóór de wedstrijd vast.</p>
    <div class="reden-rij" id="mSbRedenen">${WISSEL_REDENEN.map(r =>
      `<button class="reden ${huidig?.reden===r.id?'aan':''}" data-reden="${r.id}"><span class="ic">${r.ico?ico(r.ico,18):r.emoji}</span> ${r.label}</button>`).join('')}</div>
    <div class="disc-blok ${huidig?.reden==='gedrag'?'zicht':''}" id="mSbDisc">
      <label class="disc-toggle">
        <input type="checkbox" id="mSbDiscChk" ${huidig?.disciplinair?'checked':''}>
        <span class="disc-toggle-t">Disciplinaire reservebeurt</span>
      </label>
      <div class="disc-uitleg">Deze bankbeurt telt <b>niet mee</b> in het speelminuten-percentage. Alleen zichtbaar voor coaches.</div>
      <input class="disc-notitie ${huidig?.disciplinair?'zicht':''}" id="mSbDiscNotitie" placeholder="Reden (optioneel, alleen voor coaches)" value="${esc(huidig?.notitie||'')}">
    </div>
    <button class="knop vol fluo u-mt-md" id="mSbOk" >Opslaan</button>
    <button class="knop vol licht u-mt-xs" id="mSbGeen" >${huidig?'Reden wissen':'Zonder reden'}</button>`);

  let gekozen = huidig?.reden || null;
  const discBlok = $('#mSbDisc'), discChk = $('#mSbDiscChk'), discNot = $('#mSbDiscNotitie');
  const werkDiscBij = () => {
    discBlok.classList.toggle('zicht', gekozen === 'gedrag');
    if (gekozen !== 'gedrag'){ discChk.checked = false; discNot.classList.remove('zicht'); }
  };
  $$('#mSbRedenen [data-reden]').forEach(b => b.onclick = () => {
    const id = b.dataset.reden;
    gekozen = (gekozen === id) ? null : id;
    $$('#mSbRedenen [data-reden]').forEach(x => x.classList.toggle('aan', x.dataset.reden === gekozen));
    werkDiscBij();
  });
  discChk.onchange = () => discNot.classList.toggle('zicht', discChk.checked);
  $('#mSbOk').onclick = () => {
    if (!gekozen){ delete w.startBankReden[pid]; }
    else {
      const rec = { reden: gekozen };
      if (gekozen === 'gedrag' && discChk.checked){
        rec.disciplinair = true;
        const n = discNot.value.trim(); if (n) rec.notitie = n;
      }
      w.startBankReden[pid] = rec;
    }
    sluitModal(); bewaarWedstrijd(); renderWedstrijd();
  };
  $('#mSbGeen').onclick = () => {
    delete w.startBankReden[pid];
    sluitModal(); bewaarWedstrijd(); renderWedstrijd();
  };
}
function verwijderEvent(i){
  huidigKwart().events.splice(i,1);
  bewaarWedstrijd(); renderWedstrijd();
}
function kopieerVorigKwart(){
  const nr = Number(S.kwart);
  if (nr === 1) return;
  const vorig = S.wedstrijd.kwarten[nr-1];
  const k = huidigKwart();
  k.lineup = effectieveLineup(vorig);
  k.formatie = kwartFormatie(S.wedstrijd, vorig);
  bewaarWedstrijd(); renderWedstrijd();
  meld('Eindopstelling ' + periodeOmschrijving(S.wedstrijd, String(nr-1)) + ' overgenomen: pas aan waar nodig');
}

/* ==================== STATISTIEK-TAB ==================== */
export function htmlStats(){
  if (!S.spelers.length) return `<div class="kaart leeg">Voeg eerst spelers toe.</div>`;
  const alleSeizoenen = S.statsSeizoen === 'alles';
  // [20260928e] team met 1e + 2e elftal: filter op elftal (Totaal = alles)
  const wedstrijdenLijst = filterOpElftal(alleSeizoenen ? S.wedstrijden : S.wedstrijden.filter(w => w.seizoen === S.statsSeizoen));
  const presentieLijst = alleSeizoenen ? (S.presentie||[]) : (S.presentie||[]).filter(p => p.seizoen === S.statsSeizoen);
  const tot = {tijd:{}, keeper:{}, lijn:{}, wedstrijden:{}, goals:{}, assists:{}, geel:{}, rood:{}, tijd_:{}, aanv:{}};
  for (const w of wedstrijdenLijst){
    for (const g of (w.goals||[])) if (g.type==='voor' && g.pid) tot.goals[g.pid] = (tot.goals[g.pid]||0) + 1;
    for (const g of (w.goals||[])) if (g.type==='voor' && g.assist) tot.assists[g.assist] = (tot.assists[g.assist]||0) + 1;
    for (const c of (w.kaarten||[])){
      if (c.auto) continue;
      if (c.type === 'geel') tot.geel[c.pid] = (tot.geel[c.pid]||0) + 1;
      if (c.type === 'rood') tot.rood[c.pid] = (tot.rood[c.pid]||0) + 1;
      if (c.type === 'tijd') tot.tijd_[c.pid] = (tot.tijd_[c.pid]||0) + 1;
    }
    for (const _ap of aanvoerdersInWedstrijd(w)) tot.aanv[_ap] = (tot.aanv[_ap]||0) + 1;
    const a = analyseWedstrijd(w);
    if (!a.kwarten) continue;
    for (const [pid, s] of Object.entries(a.tijd)){
      tot.tijd[pid] = (tot.tijd[pid]||0) + s;
      tot.wedstrijden[pid] = (tot.wedstrijden[pid]||0) + 1;
    }
    for (const [pid, n] of Object.entries(a.keeper)) tot.keeper[pid] = (tot.keeper[pid]||0) + n;
    for (const [pid, l] of Object.entries(a.lijn)){
      tot.lijn[pid] ||= {};
      for (const [ln, n] of Object.entries(l)) tot.lijn[pid][ln] = (tot.lijn[pid][ln]||0) + n;
    }
  }
  // speeltijd- en reserve-percentages, over wedstrijden waarin de speler in de selectie zat
  const sr = speeltijdReserve(wedstrijdenLijst);
  const pctSpeeltijd = {}, pctReserve = {};
  for (const [pid, r] of Object.entries(sr)){
    if (r.speelbaar > 0){
      pctSpeeltijd[pid] = Math.round((r.speeltijd / r.speelbaar) * 100);
      pctReserve[pid]   = 100 - pctSpeeltijd[pid];
    }
  }
  /* Sortering: alfabetisch op naam. De tabel is een naslagtabel — een coach
     zoekt er een specifieke speler in op, en dan is een vaste volgorde die niet
     verschuift zodra iemand een wedstrijd meer speelt het prettigst. Wie te
     weinig speelt wordt gesignaleerd via de eerlijkheidskaart erboven, de tint
     op de rij en het Aandacht-blad — niet via de sorteervolgorde. */
  const rijen = [...S.spelers].sort((a,b) =>
    (a.naam||'').localeCompare(b.naam||'', 'nl', {sensitivity:'base'}));
  const heeftData = Object.keys(tot.tijd).length > 0;
  const pctKleur = p => p==null ? 'var(--ink-2)' : p>=60?'var(--n5)':p>=45?'var(--n4)':p>=30?'var(--n3)':'var(--n2)';

  /* --- Ontwikkelreeks per speler, voor het lijntje achter de naam ---
     Bron: S.beoordelingen (teams/{teamId}/beoordelingen), dat al in de state
     staat — geen extra Firestore-lees. Een snelle beoordeling levert zijn
     niveau 1..5, een volledige het gemiddelde van de ingevulde domeinscores;
     beide op dezelfde schaal, zodat ze in één lijn passen. Oud → nieuw, want
     S.beoordelingen staat nieuwste eerst. */
  const ontwikkelReeks = {};
  for (const b of [...(S.beoordelingen||[])].reverse()){
    let v = null;
    if (b.soort === 'snel' && b.niveau) v = Number(b.niveau);
    else if (b.soort === 'volledig'){
      const sc = Object.values(b.scores || {}).filter(n => Number(n) > 0).map(Number);
      if (sc.length) v = sc.reduce((a,n) => a+n, 0) / sc.length;
    }
    if (v > 0) (ontwikkelReeks[b.spelerId] ||= []).push(v);
  }
  /* Mini-grafiekje achter de naam. Alleen bij ≥2 metingen — met één punt valt
     er niets te zien — en alleen als het team de evaluatiemodule gebruikt.
     De dode zone van ±0,15 voorkomt dat een vlakke lijn willekeurig groen of
     rood kleurt. */
  const spark = pid => {
    const r = ontwikkelReeks[pid];
    if (!modAan('evaluaties') || !r || r.length < 2) return '';
    const B = 38, H = 13, MIN = 1, MAX = 5;
    const hoogte = v => Math.max(0, Math.min(1, (v - MIN) / (MAX - MIN)));
    const punten = r.map((v,i) => {
      const x = (i/(r.length-1))*(B-2)+1;
      const y = H - 1.5 - hoogte(v)*(H-3);
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    }).join(' ');
    const delta = r[r.length-1] - r[0];
    const kl = delta > 0.15 ? 'var(--n5)' : delta < -0.15 ? 'var(--n2)' : 'var(--ink-2)';
    const pijl = delta > 0.15 ? '▲' : delta < -0.15 ? '▼' : '=';
    const ly = (H - 1.5 - hoogte(r[r.length-1])*(H-3)).toFixed(1);
    return `<span class="stats-spark" title="Ontwikkeling uit ${r.length} beoordelingen">`
      + `<svg width="${B}" height="${H}" viewBox="0 0 ${B} ${H}" fill="none" aria-hidden="true">`
      + `<polyline points="${punten}" stroke="${kl}" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/>`
      + `<circle cx="${B-1}" cy="${ly}" r="1.8" fill="${kl}"/></svg>`
      + `<span class="pijl" style="color:${kl}">${pijl}</span></span>`;
  };

  // Opkomst training: per speler geteld over alleen de trainingen die voor
  // hem meetellen — zie js/opkomst.js. Een later ingestroomde speler kreeg
  // anders 100% over trainingen waar hij nog niet bij het team was.
  // opkomst[pid] = {aanwezig, totaal, pct, overgeslagen}
  const totTrainingen = presentieLijst.length;
  const opkomst = {};
  if (totTrainingen) for (const p of S.spelers) opkomst[p.id] = opkomstVoor(p, presentieLijst);
  const toonOpkomst = totTrainingen > 0;
  /* Elftalfilter: in de spelerstabel alleen wie bij dat elftal hoort of er
     meespeelde. Trainingsopkomst geldt voor de hele selectie. */
  const ef = elftalFilter();
  const rijenElftal = ef === 't' ? rijen : rijen.filter(p => hoortBijElftal(p, ef) || tot.wedstrijden[p.id] || tot.goals[p.id] || tot.assists[p.id]);

  // Reden-uitsplitsing van afwezigheid per speler (training), voor inzicht onder
  // de opkomst. Telt per reden-type; oude vrije notities vallen onder 'anders'.
  const afwezigTelling = {}; // pid -> {redenId: aantal}
  if (totTrainingen){
    const spelerPerId = new Map(S.spelers.map(p => [p.id, p]));
    for (const sessie of presentieLijst){
      for (const pid of (sessie.afwezig || [])){
        // Sessies die niet voor deze speler meetellen leveren ook geen
        // afwezigheidsreden op — anders staat er een chip onder een training
        // die nergens in zijn percentage terugkomt.
        const sp = spelerPerId.get(pid);
        if (sp && !teltMee(sessie, sp)) continue;
        const rec = (sessie.afwezigRedenen || {})[pid];
        const info = rec ? afwezigRedenInfo(rec) : null;
        const id = info?.id || 'anders';
        (afwezigTelling[pid] ||= {}); afwezigTelling[pid][id] = (afwezigTelling[pid][id]||0) + 1;
      }
    }
  }

  // --- Eerlijkheids-score: spreiding in speeltijd-% over de selectie, samengevat
  // tot één getal 0..100 (100 = iedereen even veel). Gebaseerd op de
  // variatiecoëfficiënt (sd/gem) van de speeltijd-percentages; uitlegbaar aan
  // coaches: hoe dichter iedereen bij elkaar, hoe hoger. Alleen spelers met een
  // percentage (dus die in ≥1 selectie zaten) tellen mee. Sluit aan bij het
  // beleidsplan-uitgangspunt van eerlijke speeltijdverdeling.
  const speelPcts = Object.values(pctSpeeltijd);
  let eerlijk = null;
  if (speelPcts.length >= 3){
    const gem = speelPcts.reduce((a,b)=>a+b,0) / speelPcts.length;
    if (gem > 0){
      const sd = Math.sqrt(speelPcts.reduce((a,b)=>a+(b-gem)**2,0) / speelPcts.length);
      const cv = sd / gem;
      const score = Math.max(0, Math.min(100, Math.round(100 - cv*140)));
      // laagst spelende speler (met percentage) voor de toelichting
      let laagsteP = null, laagsteV = Infinity;
      for (const p of S.spelers){
        const v = pctSpeeltijd[p.id];
        if (v != null && v < laagsteV){ laagsteV = v; laagsteP = p; }
      }
      eerlijk = {score, gem:Math.round(gem), sd:Math.round(sd), laagsteP, laagsteV};
    }
  }
  const eerlijkKleur = sc => sc>=75?'var(--ok)':sc>=55?'var(--warn)':'var(--n1)';
  const eerlijkLabel = sc => sc>=75?'Goed verdeeld'
    : sc>=55?'Redelijk: houd de uitschieters in de gaten'
    : 'Scheef: een paar spelers krijgen structureel weinig';

  // --- Aandacht-signalen: spelers die opvallen op speeltijd, opkomst of
  // disciplinaire beurten. Combineert data die anders over drie bladen verspreid
  // staat, zodat een speler die op meerdere assen laag zit in één oogopslag
  // zichtbaar wordt. Puur signalerend, geen oordeel. Drempels bewust conservatief.
  const DREMPEL_SPEEL = 50, DREMPEL_OPKOMST = 60;
  const aandachtSignalen = [];
  for (const p of S.spelers){
    const ps = pctSpeeltijd[p.id];
    // Pas signaleren vanaf een handvol meetellende trainingen: één gemiste
    // training van een net ingestroomde speler is geen patroon.
    const o = toonOpkomst ? opkomst[p.id] : null;
    const op = (o && o.totaal >= MIN_OPKOMST_TRAININGEN) ? o.pct : null;
    const disc = Math.round(sr[p.id]?.disciplinair || 0) > 0;
    const redenen = [], tags = [];
    let gewicht = 0;
    if (ps != null && ps < DREMPEL_SPEEL){ redenen.push('weinig speeltijd'); tags.push({t:ps+'% speeltijd', k:'laag'}); gewicht += 2; }
    if (op != null && op < DREMPEL_OPKOMST){ redenen.push('lage trainingsopkomst'); tags.push({t:op+'% opkomst', k:'warn'}); gewicht += 1; }
    if (disc){ redenen.push('disciplinaire reservebeurt'); tags.push({t:'disc.', k:'warn'}); gewicht += 1; }
    if (redenen.length) aandachtSignalen.push({p, redenen, tags, gewicht});
  }
  aandachtSignalen.sort((a,b) => b.gewicht - a.gewicht);
  const aandachtAantal = aandachtSignalen.length;

  // Team-overzichtkaart: eerlijkheidsmeter + kern-cijfers. Verschijnt boven het
  // speel- en het aandacht-blad. Toont niets als er nog te weinig data is.
  const overzichtKaart = () => {
    const totWed = wedstrijdenLijst.length;
    const totGoals = Object.values(tot.goals).reduce((a,b)=>a+b, 0);
    const opkomstVals = (toonOpkomst ? Object.values(opkomst) : [])
      .map(o => o.pct).filter(v => v != null);
    const gemOpkomst = opkomstVals.length ? Math.round(opkomstVals.reduce((a,b)=>a+b,0)/opkomstVals.length) : null;
    if (!eerlijk && !totWed) return '';
    return `
    <div class="kaart">
      ${eerlijk ? `
      <div class="sectie-kop u-mt-0">Eerlijke speeltijd<span class="u-ml-auto u-t-2xs u-zacht" style="font-family:'Inter';font-weight:500;text-transform:none;letter-spacing:0">seizoen tot nu</span></div>
      <div class="u-mb-2xs" style="display:flex;align-items:baseline;gap:var(--space-xs)">
        <span style="font-family:'Barlow Condensed';font-weight:700;font-size:calc(38px * var(--fs));line-height:1;color:${eerlijkKleur(eerlijk.score)}">${eerlijk.score}</span>
        <span class="u-t-sm u-zacht">/ 100</span>
      </div>
      <div style="font-size:calc(13px * var(--fs));font-weight:600;margin-bottom:11px;color:${eerlijkKleur(eerlijk.score)}">${eerlijkLabel(eerlijk.score)}</div>
      <div class="u-mb-xs" style="height:12px;border-radius:6px;background:var(--surface-2);overflow:hidden">
        <div style="height:100%;border-radius:6px;width:${eerlijk.score}%;background:${eerlijkKleur(eerlijk.score)}"></div>
      </div>
      <div class="u-t-2xs u-zacht" style="display:flex;justify-content:space-between"><span>scheef</span><span>gelijk verdeeld</span></div>
      <div class="u-t-xs u-zacht u-lh-ruim u-mt-xs">
        Gemiddeld <b class="u-c-ink">${eerlijk.gem}%</b> speeltijd per speler, spreiding ±${eerlijk.sd}%.${eerlijk.score < 75 && eerlijk.laagsteP ? ` <b class="u-c-ink">${esc(eerlijk.laagsteP.naam)}</b> zit met ${eerlijk.laagsteV}% het laagst, de moeite van een blik waard.` : ' Iedereen zit dicht bij elkaar.'}
      </div>` : ''}
      <div class="kern-strip">
        <div class="kern-box"><div class="v">${totWed}</div><div class="l">Wedstrijden</div></div>
        <div class="kern-box"><div class="v">${totGoals}</div><div class="l">Doelpunten</div></div>
        <div class="kern-box"><div class="v">${gemOpkomst != null ? gemOpkomst+'%' : '—'}</div><div class="l">Opkomst</div></div>
      </div>
    </div>`;
  };

  // Vier bladen: het nieuwe 'aandacht'-blad staat vooraan met een teller-badge,
  // daarna speelminuten, wedstrijdstatistiek en trainingsopkomst. De actieve
  // keuze staat in S.statsBlad (default 'spelers'); koppeling in koppelStatsBlad().
  /* 'speel' en 'wed' waren twee losse bladen tot deze release; die waarde kan
     nog in S staan uit een lopende sessie. Beide wijzen nu naar het
     samengevoegde spelers-blad, zodat niemand op een leeg scherm belandt. */
  const blad = ({speel:'spelers', wed:'spelers'})[S.statsBlad] || S.statsBlad || 'spelers';
  const aandachtBadge = aandachtAantal ? `<span class="stats-blad-badge">${aandachtAantal}</span>` : '';
  const bladBalk = `
    <div class="segment stats-blad u-mb-md" id="statsBlad" >
      <button data-statsblad="aandacht" class="${blad==='aandacht'?'actief':''}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg> Aandacht${aandachtBadge}</button>
      <button data-statsblad="spelers" class="${blad==='spelers'?'actief':''}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M9.2 4.5 6 6.2v4l2.2-.7v10h7.6v-10l2.2.7v-4l-3.2-1.7a2.9 2.9 0 0 1-5.6 0z"/></svg> Spelers</button>
      <button data-statsblad="tr" class="${blad==='tr'?'actief':''}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4.4 19.6 13.4 10.6"/><path d="M8.8 10.6h4.6v4.6"/><path d="M16.4 4.4h4.2v4.2h-4.2z"/></svg> Train</button>
    </div>`;

  // Naam in de stats-tabel is klikbaar → opent het spelersprofiel (details).
  // De koppeling zit in koppelStatsBlad(); navigatie via de Spelers-tab zodat
  // de terugknop netjes terugkeert naar Stats.
  const naamCel = p => `<td class="naam-cel"><button type="button" class="stats-naam" data-statsprofiel="${p.id}">${esc(p.naam)}</button></td>`;
  // naam-cel met disciplinaire-badge als de speler ≥1 disciplinaire beurt had
  const naamCelDisc = p => {
    const dsec = Math.round((sr[p.id]?.disciplinair || 0));
    const badge = dsec > 0 ? ` <span class="disc-badge" title="Disciplinaire reservebeurt(en): niet meegeteld in %">disc.</span>` : '';
    return `<td class="naam-cel"><button type="button" class="stats-naam" data-statsprofiel="${p.id}">${esc(p.naam)}</button>${badge}${spark(p.id)}</td>`;
  };

  // Uitgeleende speeltijd: opgeteld uit speeltijdPerWedstrijd op elk actief
  // uitgaand leen-record van deze speler (zie bijwerkLeenSpeeltijd in
  // wedstrijd.js). Alleen tonen zolang de uitlening loopt — zie de
  // beperking hierboven bij bijwerkLeenSpeeltijd.
  const leenSpeeltijd = {}; // pid -> seconden elders gespeeld
  for (const u of (S.uitleningenUit||[])){
    const per = u.speeltijdPerWedstrijd || {};
    const sec = Object.values(per).reduce((a,b) => a + (b||0), 0);
    if (sec > 0) leenSpeeltijd[u.spelerId] = sec;
  }
  const heeftUitleen = Object.keys(leenSpeeltijd).length > 0;
  const minSec = s => `${Math.floor(s/3600)}u ${Math.round((s%3600)/60)}m`;

  /* ==================== SPELERS-BLAD ====================
     Speeltijd én wedstrijdcijfers in één tabel: een coach die naar een speler
     kijkt wil beide tegelijk zien, en twee losse bladen dwongen tot heen en
     weer schakelen. Om de tabel op een telefoon leesbaar te houden vallen
     kolommen weg waarin het hele team op nul staat — een elftal zonder kaarten
     krijgt geen twee kolommen vol nullen te zien. Een 0 in een kolom die wél
     getoond wordt staat gedempt, zodat het oog naar de gevulde cellen gaat. */
  const spelersBlad = () => {
    const mogelijk = [
      {th:'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M3.4 19V7.6h17.2V19"/><path d="M9.2 7.6V19"/><path d="M14.8 7.6V19"/><path d="M3.4 13.3h17.2"/></svg>',  titel:'Doelpunten',          val:p => tot.goals[p.id]||0,     nadruk:true},
      {th:'A',   titel:'Assists',             val:p => tot.assists[p.id]||0,   nadruk:true},
      {th:'C',   titel:'Aanvoerdersbeurten',  val:p => tot.aanv[p.id]||0,      fmt:n => n+'×'},
      {th:'K',   titel:'Periodes als keeper', val:p => tot.keeper[p.id]||0},
      {th:'<span class="kaartje geel" aria-hidden="true"></span>',  titel:'Gele kaarten',        val:p => tot.geel[p.id]||0},
      {th:'<span class="kaartje rood" aria-hidden="true"></span>',  titel:'Rode kaarten',        val:p => tot.rood[p.id]||0},
      {th:'⇄',   titel:'Elders gespeeld terwijl uitgeleend',
                                              val:p => leenSpeeltijd[p.id]||0, fmt:n => minSec(n), accent:true},
    ];
    const kol = mogelijk.filter(k => rijenElftal.some(p => k.val(p) > 0));
    const cel = (p, k) => {
      const n = k.val(p);
      if (!n) return `<td class="leeg-cel">0</td>`;
      const stijl = k.nadruk ? ' style="font-weight:700"'
        : k.accent ? ' style="color:var(--accent);font-weight:700"' : '';
      return `<td${stijl}>${k.fmt ? k.fmt(n) : n}</td>`;
    };
    return overzichtKaart() + `
    <table class="stat-tabel">
      <thead><tr><th>Speler</th><th>Speeltijd</th><th>Wed.</th><th>Res.</th>
        ${kol.map(k => `<th title="${esc(k.titel)}">${k.th}</th>`).join('')}</tr></thead>
      <tbody>${rijenElftal.map(p => {
        const ps = pctSpeeltijd[p.id], pr = pctReserve[p.id];
        const laag = ps != null && ps < DREMPEL_SPEEL;
        return `<tr${laag ? ' class="stats-laag"' : ''}>
          ${naamCelDisc(p)}
          <td class="pct-cel">${ps!=null
            ? `<span style="font-weight:700;color:${pctKleur(ps)}">${ps}%</span><span class="pct-bar"><span style="width:${ps}%;background:${pctKleur(ps)}"></span></span>`
            : '—'}</td>
          <td>${tot.wedstrijden[p.id]||0}</td>
          <td class="res-cel${pr ? '' : ' leeg-cel'}">${pr!=null?pr+'%':'—'}</td>
          ${kol.map(k => cel(p, k)).join('')}</tr>`;
      }).join('')}</tbody>
    </table>
    <p class="u-t-xs u-zacht u-mt-sm u-lh-ruim">
      <b>Speeltijd</b>/<b>Res.</b> = % gespeeld resp. reserve, over de wedstrijden waarin de speler in de selectie zat (samen 100%). Een <span class="disc-badge">disc.</span>-beurt telt niet mee in het percentage, en de tijd vóór aankomst van een speler die later kwam (minuut ingevuld bij Selectie of Presentie) ook niet. De exacte minuten staan in het spelersprofiel.
      ${kol.length ? '<br>' + kol.map(k => `${k.th} ${k.titel.toLowerCase()}`).join(', ') + '.' : ''}
      ${heeftUitleen ? ' Uitgeleende tijd telt niet mee in de eerlijkheidsscore hierboven, en verdwijnt zodra de uitlening wordt teruggezet.' : ''}
      ${modAan('evaluaties') ? '<br>Het lijntje achter een naam is zijn ontwikkeling uit de beoordelingen, oudste meting links.' : ''}</p>`;
  };

  const redenLabel = id => (AFWEZIG_REDENEN.find(r => r.id === id) || {emoji:'❓',label:'Anders'});
  const trBlad = () => toonOpkomst ? `
    <table class="stat-tabel">
      <thead><tr><th>Speler</th><th>Aanwezig</th><th>Opkomst</th></tr></thead>
      <tbody>${rijen.map(p => {
        const o = opkomst[p.id] || {aanwezig:0, totaal:0, pct:null, overgeslagen:0};
        const pct = o.pct;
        // Te weinig meetellende trainingen voor een oordeel: het percentage
        // staat er wel, maar gedempt in plaats van in rood/groen.
        const pril = o.totaal > 0 && o.totaal < MIN_OPKOMST_TRAININGEN;
        const kleurKlasse = pct == null ? '' : pct>=80?'goed':pct>=50?'matig':'laag';
        const chips = [];
        // Trainingen van vóór zijn komst: benoemen waarom zijn noemer lager is,
        // anders leest 1/1 als een registratiefout.
        if (o.overgeslagen){
          chips.push(`<span class="reden-tel-chip" style="border-style:dashed"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 9.5h17M8 3v4M16 3v4"/><circle cx="12" cy="14.5" r="1.4" fill="currentColor" stroke="none"/></svg> ${p.meetelVanaf
            ? `Meegeteld vanaf ${esc(datumNL(p.meetelVanaf))}` : 'Later ingestroomd'} <b>${o.overgeslagen}× niet</b></span>`);
        }
        const tel = afwezigTelling[p.id] || {};
        for (const [id,n] of Object.entries(tel).sort((a,b) => b[1]-a[1])){
          const r = redenLabel(id);
          chips.push(`<span class="reden-tel-chip">${r.ico?ico(r.ico,14):''}${esc(r.label)} <b>${n}×</b></span>`);
        }
        return `<tr>
          ${naamCel(p)}
          <td>${o.aanwezig} / ${o.totaal}</td>
          <td class="opkomst-cel ${kleurKlasse}"${pril ? ' style="color:var(--ink-2);font-weight:600"' : ''}>${pct != null ? pct+'%' : '—'}</td></tr>
          ${chips.length ? `<tr class="reden-tel-rij"><td colspan="3"><div class="reden-tel">${chips.join('')}</div></td></tr>` : ''}`;
      }).join('')}</tbody>
    </table>
    <p class="u-t-xs u-zacht u-mt-sm u-lh-ruim">
      <b>Opkomst</b> = % aanwezig van de trainingen waarvoor de speler in de selectie zat, er staan er ${totTrainingen} geregistreerd. Onder elke speler zie je waarom hij afwezig was. Een gedempt percentage betekent: nog te weinig trainingen voor een conclusie.</p>`
    : `<div class="kaart leeg">Nog geen trainingsopkomst geregistreerd.<br>Zodra je op de Training-tab presentie bijhoudt, verschijnt hier per speler het opkomstpercentage.</div>`;

  // Aandacht-blad: de gecombineerde signalenlijst. Elke kaart is klikbaar en
  // opent — net als de tabelnamen — het spelersprofiel via data-statsprofiel.
  const aandachtBlad = () => {
    const kop = overzichtKaart();
    if (!aandachtSignalen.length){
      return kop + `<div class="kaart"><div class="geen-aandacht"><span class="groot"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4.6 12.4 9.6 17.4 19.6 6.6"/></svg></span>
        Niemand vraagt nu extra aandacht.<br>Speeltijd en opkomst zitten voor iedereen op orde.</div></div>`;
    }
    return kop + `
    <div class="kaart">
      <div class="sectie-kop u-mt-0"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg> Spelers die aandacht vragen<span class="u-ml-auto u-t-2xs u-zacht" style="font-family:'Inter';font-weight:500;text-transform:none;letter-spacing:0">${aandachtSignalen.length} van ${S.spelers.length}</span></div>
      ${aandachtSignalen.map(({p, redenen, tags, gewicht}) => `
        <button type="button" class="aandacht-kaart" data-statsprofiel="${p.id}">
          <span class="stip" style="background:${gewicht>=2?'var(--n1)':'var(--warn)'}"></span>
          <span class="aandacht-body">
            <span class="aandacht-naam">${esc(p.naam)}<span class="chev">›</span></span>
            <span class="aandacht-reden">${redenen.join(', ')}</span>
            <span class="mini-tags">${tags.map(t => `<span class="mini-tag ${t.k}">${esc(t.t)}</span>`).join('')}</span>
          </span>
        </button>`).join('')}
      <p class="u-t-xs u-zacht u-mt-sm u-lh-ruim">
        Automatisch samengesteld uit speeltijd (&lt; ${DREMPEL_SPEEL}%), trainingsopkomst (&lt; ${DREMPEL_OPKOMST}%) en disciplinaire beurten. Tik op een speler voor het profiel. <b>Puur ter signalering</b>: geen oordeel.</p>
    </div>`;
  };

  const leegWed = `<div class="kaart leeg u-mb-sm">Nog geen gespeelde wedstrijden.<br>Zodra je opstellingen maakt, verschijnt hier automatisch de speeltijd per speler.</div>`;

  let inhoud;
  if (blad === 'aandacht') inhoud = aandachtBlad();
  else if (blad === 'spelers') inhoud = (heeftData ? '' : leegWed) + spelersBlad();
  else inhoud = trBlad();

  return (blad === 'tr' ? '' : elftalFilterHtml('elf-filter-stats')) + bladBalk + inhoud;
}

/* Koppelt de stats-blad-knoppen (aandacht / spelers / training).
   Aangeroepen vanuit teams.js nadat de Stats-tab is getekend. */
export function koppelStatsBlad(root){
  (root || document).querySelectorAll('[data-statsblad]').forEach(b => b.onclick = () => {
    S.statsBlad = b.dataset.statsblad;
    import('./teams.js?v=20261106h').then(m => m.renderTeam?.());
  });
}

/* ==================== EXCEL-EXPORT (stats) ====================
   Zelfde patroon als de club-evaluatie-export: ExcelJS wordt pas van de CDN
   geladen op het moment dat een coach echt exporteert. De export gebruikt de
   al bestaande, geëxporteerde analysefuncties (analyseWedstrijd,
   speeltijdReserve) — de speeltijd/klok-logica zelf blijft ongewijzigd; we
   lézen alleen de uitkomsten en zetten ze in drie tabbladen die de drie
   stats-bladen spiegelen: Speelminuten, Wedstrijd, Training.
   AVG: enkel spelersnaam + eigen teamgegevens, geen externe/gevoelige data. */
let _exceljsLoadStats = null;
function laadExcelJsStats(){
  if (window.ExcelJS) return Promise.resolve();
  if (_exceljsLoadStats) return _exceljsLoadStats;
  _exceljsLoadStats = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/exceljs@4.4.0/dist/exceljs.min.js';
    script.onload = resolve;
    script.onerror = () => { _exceljsLoadStats = null; reject(new Error('Kon Excel-library niet laden: controleer je internetverbinding')); };
    document.head.appendChild(script);
  });
  return _exceljsLoadStats;
}

/* Bouwt dezelfde totalen op als htmlStats(), maar dan als platte data voor de
   export. Bewust een aparte functie zodat htmlStats() (weergave) ongemoeid
   blijft. */
function statsExportData(){
  const alleSeizoenen = S.statsSeizoen === 'alles';
  const wedstrijdenLijst = filterOpElftal(alleSeizoenen ? S.wedstrijden : S.wedstrijden.filter(w => w.seizoen === S.statsSeizoen));
  const presentieLijst = alleSeizoenen ? (S.presentie||[]) : (S.presentie||[]).filter(p => p.seizoen === S.statsSeizoen);

  const tot = {tijd:{}, keeper:{}, wedstrijden:{}, goals:{}, assists:{}, geel:{}, rood:{}, aanv:{}};
  for (const w of wedstrijdenLijst){
    for (const g of (w.goals||[])) if (g.type==='voor' && g.pid) tot.goals[g.pid] = (tot.goals[g.pid]||0) + 1;
    for (const g of (w.goals||[])) if (g.type==='voor' && g.assist) tot.assists[g.assist] = (tot.assists[g.assist]||0) + 1;
    for (const c of (w.kaarten||[])){
      if (c.auto) continue;
      if (c.type === 'geel') tot.geel[c.pid] = (tot.geel[c.pid]||0) + 1;
      if (c.type === 'rood') tot.rood[c.pid] = (tot.rood[c.pid]||0) + 1;
    }
    for (const _ap of aanvoerdersInWedstrijd(w)) tot.aanv[_ap] = (tot.aanv[_ap]||0) + 1;
    const a = analyseWedstrijd(w);
    if (!a.kwarten) continue;
    for (const [pid, s] of Object.entries(a.tijd)){
      tot.tijd[pid] = (tot.tijd[pid]||0) + s;
      tot.wedstrijden[pid] = (tot.wedstrijden[pid]||0) + 1;
    }
    for (const [pid, n] of Object.entries(a.keeper)) tot.keeper[pid] = (tot.keeper[pid]||0) + n;
  }

  const sr = speeltijdReserve(wedstrijdenLijst);
  const pctSpeeltijd = {}, pctReserve = {};
  for (const [pid, r] of Object.entries(sr)){
    if (r.speelbaar > 0){
      pctSpeeltijd[pid] = Math.round((r.speeltijd / r.speelbaar) * 100);
      pctReserve[pid]   = 100 - pctSpeeltijd[pid];
    }
  }

  // Zelfde telling als het Train-blad: per speler alleen de trainingen die
  // voor hem meetellen (js/opkomst.js), zodat export en scherm gelijk lopen.
  const totTrainingen = presentieLijst.length;
  const opkomstTot = {};
  if (totTrainingen) for (const p of S.spelers) opkomstTot[p.id] = opkomstVoor(p, presentieLijst);

  const rijen = [...S.spelers].sort((a,b) => (pctSpeeltijd[b.id]??-1) - (pctSpeeltijd[a.id]??-1) || (tot.tijd[b.id]||0) - (tot.tijd[a.id]||0));
  return { rijen, tot, sr, pctSpeeltijd, pctReserve, totTrainingen, opkomstTot };
}

export async function exportStatsExcel(knop){
  const label = knop ? knop.innerHTML : null;
  if (knop){ knop.disabled = true; knop.innerHTML = 'Bezig…'; }
  meld('Excel-export wordt klaargezet…');
  try {
    await laadExcelJsStats();
    const d = statsExportData();
    const seizoenLabel = (S.statsSeizoen && S.statsSeizoen !== 'alles') ? S.statsSeizoen : 'alle seizoenen';
    const elftalLabel = elftalFilter() !== 't' ? ', ' + elftalNaam(elftalFilter()) : '';

    const wb = new window.ExcelJS.Workbook();
    wb.creator = 'Cluppie'; wb.created = new Date();

    /* --- Tabblad 1: Speelminuten --- */
    const ws1 = wb.addWorksheet('Speelminuten');
    ws1.columns = [
      {header:'Speler', key:'speler', width:22},
      {header:'Wedstrijden', key:'wed', width:12},
      {header:'Speeltijd %', key:'speel', width:12},
      {header:'Reserve %', key:'res', width:11},
      {header:'Totaal minuten', key:'min', width:14},
      {header:'Disc. reservetijd (min)', key:'disc', width:20},
    ];
    ws1.getRow(1).font = {bold:true};
    for (const p of d.rijen){
      ws1.addRow({
        speler: p.naam,
        wed: d.tot.wedstrijden[p.id]||0,
        speel: d.pctSpeeltijd[p.id] ?? null,
        res: d.pctReserve[p.id] ?? null,
        min: Math.round((d.tot.tijd[p.id]||0)/60),
        disc: Math.round((d.sr[p.id]?.disciplinair || 0)/60),
      });
    }

    /* --- Tabblad 2: Wedstrijd --- */
    const ws2 = wb.addWorksheet('Wedstrijd');
    ws2.columns = [
      {header:'Speler', key:'speler', width:22},
      {header:'Doelpunten', key:'goals', width:12},
      {header:'Assists', key:'assists', width:10},
      {header:'Aanvoerder (×)', key:'aanv', width:14},
      {header:'Periodes keeper', key:'keeper', width:15},
      {header:'Geel', key:'geel', width:8},
      {header:'Rood', key:'rood', width:8},
    ];
    ws2.getRow(1).font = {bold:true};
    for (const p of d.rijen){
      ws2.addRow({
        speler: p.naam,
        goals: d.tot.goals[p.id]||0,
        assists: d.tot.assists[p.id]||0,
        aanv: d.tot.aanv[p.id]||0,
        keeper: d.tot.keeper[p.id]||0,
        geel: d.tot.geel[p.id]||0,
        rood: d.tot.rood[p.id]||0,
      });
    }

    /* --- Tabblad 3: Training (opkomst) --- */
    const ws3 = wb.addWorksheet('Training');
    ws3.columns = [
      {header:'Speler', key:'speler', width:22},
      {header:'Aanwezig', key:'aanw', width:10},
      {header:'Meegeteld', key:'totaal', width:11},
      {header:'Opkomst %', key:'opkomst', width:11},
      {header:'Niet meegeteld', key:'over', width:14},
    ];
    ws3.getRow(1).font = {bold:true};
    if (d.totTrainingen){
      for (const p of d.rijen){
        const o = d.opkomstTot[p.id] || {aanwezig:0, totaal:0, pct:null, overgeslagen:0};
        ws3.addRow({
          speler: p.naam,
          aanw: o.aanwezig,
          totaal: o.totaal,
          opkomst: o.pct ?? '',
          over: o.overgeslagen || '',
        });
      }
    } else {
      ws3.addRow({speler:'Nog geen trainingsopkomst geregistreerd'});
    }

    const buffer = await wb.xlsx.writeBuffer();
    const blob = new Blob([buffer], {type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
    const naam = `stats-${(S.team?.naam || 'team').replace(/[^\w\- ]+/g,'').trim().replace(/\s+/g,'_') || 'team'}${elftalFilter() !== 't' ? '-elftal' + elftalFilter() : ''}-${new Date().toISOString().slice(0,10)}.xlsx`;

    // Zelfde betrouwbaarheids-afweging als bij de PDF: op mobiel de deel-sheet,
    // op desktop de klassieke download.
    if (navigator.canShare){
      try {
        const file = new File([blob], naam, {type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'});
        if (navigator.canShare({ files: [file] })){
          await navigator.share({ files: [file], title: `Stats — ${seizoenLabel}${elftalLabel}` });
          meld('Excel-export gedeeld');
          return;
        }
      } catch(e){ if (e && e.name === 'AbortError') return; }
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = naam;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    meld('Excel-export gedownload');
  } catch(e){
    meld(e.message || 'Export mislukt');
  } finally {
    if (knop){ knop.disabled = false; if (label != null) knop.innerHTML = label; }
  }
}

/* ==================== WEERGAVE ==================== */
/* Melding "X van Y spelers op het veld". Alleen zinvol zolang de periode nog
   loopt: na het eindsignaal is de eindopstelling gewoon wat hij is, en na een
   rode kaart speel je terecht met minder. Dan geen alarm, maar (bij rood) een
   neutrale mededeling. */
function veldMelding(w, k, aantalOpVeld, aantalSlots){
  if (aantalOpVeld <= 0 || aantalOpVeld >= aantalSlots) return '';
  const duurSec = Math.round((w.kwartduur || 0) * 60);
  const afgelopen = !k.klok.running && k.klok.base > 0 && k.klok.base >= duurSec;
  if (afgelopen) return '';
  /* Een rode kaart geldt voor de rest van de wedstrijd (ook in latere periodes);
     bij een toernooi telt hij alleen binnen de eigen periode. */
  const nu = Number(S.kwart);
  const rood = new Set((w.kaarten || [])
    .filter(c => c.type === 'rood' && (String(c.kwart) === String(S.kwart) || (!isToernooi(w) && Number(c.kwart) < nu)))
    .map(c => c.pid));
  if (rood.size && aantalOpVeld >= aantalSlots - rood.size)
    return `<div class="waarschuwing neutraal"><span>${KAART_ICOON.rood}</span><span>Je speelt met ${aantalOpVeld} spelers na ${rood.size > 1 ? 'rode kaarten' : 'een rode kaart'}.</span></div>`;
  return `<div class="waarschuwing"><span><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg></span><span>Er staan ${aantalOpVeld} van ${aantalSlots} spelers op het veld, vul de opstelling aan.</span></div>`;
}

export function renderWedstrijd(){
  const w = S.wedstrijd; if (!w) return;
  /* Scrollpositie vasthouden: elke tik op een speler (of geplande wissel, doelpunt,
     enz.) tekent het hele wedstrijdscherm opnieuw. Zonder dit sprong de pagina
     naar boven — hinderlijk als je onderin bij de bank of het log bezig bent.
     De eerste keer binnenkomen scrollt toon('wedstrijd') zelf al naar boven, dus
     dit herstelt alleen bij hertekenen binnen hetzelfde scherm. */
  const bewaardeScroll = window.scrollY;
  w.goals ||= [];
  w.kaarten ||= [];
  const k = huidigKwart();
  const kFormatie = kwartFormatie(w, k);
  const slots = bouwSlots(w.format, kFormatie);
  const lineup = effectieveLineup(k);
  const opVeld = new Set(Object.values(lineup));
  const aKwart = analyseKwart(w, k);
  const aWed = analyseWedstrijd(w);
  const bank = (w.selectie||[]).filter(pid => !opVeld.has(pid) && speler(pid))
    .sort((a,b) => (aWed.tijd[a]||0) - (aWed.tijd[b]||0));

  const historie = {};
  for (let nr = 1; nr < Number(S.kwart); nr++){
    const kk = w.kwarten[nr];
    if (!kk || !kwartGespeeld(kk)) continue;
    const a = analyseKwart(w, kk);
    for (const pid of (w.selectie||[]))
      (historie[pid] ||= []).push({nr, speelde: (a.tijd[pid]||0) > 0});
  }
  const dotsHtml = pid => (historie[pid]||[]).length
    ? `<div class="dots">${historie[pid].map(h =>
        `<span class="dot ${h.speelde?'s':'b'}" title="${esc(periodeLabel(w, String(h.nr)))}: ${h.speelde?'gespeeld':'bank'}"></span>`).join('')}</div>`
    : '';

  // Het veld is compleet gevuld wanneer alle posities een speler hebben.
  // Pas dan is een bankbeurt een bewuste keuze en tonen we het reden-vlaggetje.
  const veldVol = opVeld.size >= slots.length;
  const chipHtml = (pid, bron, slotId='') => {
    const sel = S.geselecteerd?.pid === pid;
    const aanv = aanvoerderVan(w, S.kwart) === pid;
    // Vooraf ingestelde disciplinaire bankbeurt (start op de bank met straf)
    const straf = bron === 'bank' && (w.startBankReden||{})[pid]?.disciplinair;
    // Te laat met ingestelde minuut: klein label op de bank ("⏱ 30'")
    const laatMin = bron === 'bank' && (w.telaat||[]).includes(pid) ? (w.telaatVanaf||{})[pid] : null;
    return `<div class="chip ${slotId==='K'?'keeper':''} ${sel?'geselecteerd':''} ${straf?'straf-chip':''}"
      data-chip="${pid}" data-bron="${bron}" data-chipslot="${slotId}">
      ${bron === 'bank' && veldVol ? `<button class="chip-reden ${straf?'straf':''}" data-bankreden="${pid}" title="Reden bankbeurt"></button>` : ''}
      <div class="shirt">${esc(spelerNr(pid))}${aanv ? '<span class="aanvoerder-band">C</span>' : ''}</div>
      <div class="naam">${esc(spelerNaam(pid))}</div>${laatMin ? `<div class="telaat-label" title="Komt later, erbij vanaf minuut ${esc(laatMin)}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.6"/><path d="M12 7.2V12l3.4 2.2"/></svg> ${esc(laatMin)}'</div>` : ''}${dotsHtml(pid)}</div>`;
  };

  const inHuidigeW = g => !isToernooi(w) || toernooiWnr(w, g.kwart) === toernooiWnr(w);
  const voor = w.goals.filter(g => g.type==='voor' && inHuidigeW(g)).length;
  const tegen = w.goals.filter(g => g.type==='tegen' && inHuidigeW(g)).length;
  const tegenNaam = isToernooi(w)
    ? ((w.tegenstanders||{})[toernooiWnr(w)] || 'Tegenstander '+toernooiWnr(w))
    : w.tegenstander;
  const sbLinks  = w.thuis ? {naam:S.team.naam, n:voor, knop:'goalVoor'}  : {naam:tegenNaam, n:tegen, knop:'goalTegen'};
  const sbRechts = w.thuis ? {naam:tegenNaam, n:tegen, knop:'goalTegen'} : {naam:S.team.naam, n:voor, knop:'goalVoor'};

  const confroHtml = bouwConfrontatie(w);
  const teamEvalBestaand = (S.teamEvaluaties||[]).some(e => e.wedstrijdId === S.wedstrijdId);

  const v = $('#view-wedstrijd');
  v.innerHTML = `
    <div class="kop"><button class="terug" id="naarTeam">‹</button>
      <h1>${isToernooi(w)
        ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M8.4 4h7.2v3.6a3.6 3.6 0 0 1-7.2 0z"/><path d="M8.4 5.4H5.8a2.4 2.4 0 0 0 2.6 3.2"/><path d="M15.6 5.4h2.6a2.4 2.4 0 0 1-2.6 3.2"/><path d="M12 11.2v3"/><path d="M9.2 19.8h5.6l-.7-3.6h-4.2z"/></svg> '+esc(w.tegenstander)
        : (w.thuis ? esc(S.team.naam)+' – '+esc(w.tegenstander) : esc(w.tegenstander)+' – '+esc(S.team.naam))}
      <span class="sub">${datumNL(w.datum)}<span class="sep" aria-hidden="true"></span>${isToernooi(w) ? w.toernooi.wedstrijden+' wedstrijden<span class="sep" aria-hidden="true"></span>' : ''}<span id="subFormatieKlik" class="u-klikbaar" style="text-decoration:underline dotted">${esc(kFormatie)}</span></span></h1>
      <button class="terug opzet-knop" id="wInstellingen" title="Wedstrijd aanpassen">
        <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 3L20 6.5V11C20 15.5 16.9 19.7 12 21C7.1 19.7 4 15.5 4 11V6.5L12 3Z" stroke="var(--accent)" stroke-width="1.7" stroke-linejoin="round"/>
          <path d="M9 12L11 14L15.5 9.5" stroke="var(--accent)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span>Wijzig opzet</span>
      </button></div>
    <div class="kaart doelbanner" id="doelBanner" style="${w.doel
      ? 'background:rgba(226,52,47,.12);border-left:3px solid var(--accent)'
      : 'background:rgba(226,52,47,.10);border-left:3px dashed var(--accent)'};font-size:calc(13.5px * var(--fs));color:var(--ink);padding:10px 12px;margin-bottom:10px;cursor:pointer;display:flex;align-items:center;gap:8px">${w.doel
        ? `<span class="u-t-lg"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.5"/><circle cx="12" cy="12" r="0.6" fill="currentColor" stroke="none"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3"/></svg></span><span><b>Doel:</b> ${esc(w.doel)}</span>`
        : `<span class="u-t-lg"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.5"/><circle cx="12" cy="12" r="0.6" fill="currentColor" stroke="none"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3"/></svg></span><span><b>Wedstrijddoel kiezen</b>, tik hier om een doel voor vandaag te zetten <span class="u-c-accent u-fw-7">›</span></span>`}</div>
${confroHtml}
    <div class="scorebord v2">
      <div class="sb-rij">
        <button class="sb-goal" id="${sbLinks.knop}" title="Doelpunt ${esc(sbLinks.naam)}"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg></button>
        <span class="sb-cijfers">${sbLinks.n} – ${sbRechts.n}</span>
        <button class="sb-goal" id="${sbRechts.knop}" title="Doelpunt ${esc(sbRechts.naam)}"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg></button>
      </div>
      <div class="sb-namen">
        <span class="sb-team" ${!w.thuis && isToernooi(w) ? 'id="sbTegenNaam" style="text-decoration:underline dotted;cursor:pointer"' : ''}>${esc(sbLinks.naam)}</span>
        <span class="sb-team" ${w.thuis && isToernooi(w) ? 'id="sbTegenNaam" style="text-decoration:underline dotted;cursor:pointer"' : ''}>${esc(sbRechts.naam)}</span>
      </div>
    </div>

    ${veldMelding(w, k, opVeld.size, slots.length)}
    ${(w.selectie||[]).filter(pid => speler(pid)).length < slots.length ? `<div class="waarschuwing"><span><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg></span><span>Selectie heeft maar ${(w.selectie||[]).filter(pid => speler(pid)).length} spelers, je hebt er ${slots.length} nodig voor ${w.format} tegen ${w.format}.</span></div>` : ''}

    <div class="kwarten" style="${(w.periodes||4) > 5 ? 'flex-wrap:wrap' : ''}">${periodeNrs(w).map(nr => {
      const kk = w.kwarten[nr];
      return `<button data-kwart="${nr}" style="${(w.periodes||4) > 5 ? 'font-size:calc(14px * var(--fs));flex:1 1 20%;padding:8px 0' : ''}" class="${S.kwart===nr?'actief':''}">${periodeLabel(w, nr)}${kwartGespeeld(kk)?' •':''}</button>`;
    }).join('')}</div>

    ${(() => {
      /* Leeg kwart na een gespeeld kwart: expliciete overneem-keuze in plaats
         van de vroegere automatische kopie bij het aantikken van de tab —
         kijken naar een kwart mag nooit stilletjes data wijzigen. */
      const nr = Number(S.kwart);
      const vorig = w.kwarten[nr-1];
      if (nr <= 1 || opVeld.size > 0 || !vorig || !kwartGespeeld(vorig)) return '';
      return `<div class="kwart-leeg-actie"><span>${esc(periodeOmschrijving(w))} heeft nog geen opstelling.</span><button id="overneemVorigKwart">⧉ Eindopstelling ${esc(periodeLabel(w, String(nr-1)))} overnemen</button></div>`;
    })()}

    <div class="klok">
      <div><div class="tijd klok-tijd-knop" id="klokTijd" title="Tik om de wedstrijdtijd handmatig in te stellen">${mmss(klokSec(k))}<span class="klok-pen">✎</span></div>
        <div class="label">${esc(periodeOmschrijving(w))}<span class="sep" aria-hidden="true"></span>max ${String(w.kwartduur).replace('.',',')} min</div></div>
      <div class="acties">
        <button id="kaartKnop" title="Kaart of straf"><span class="kaartje geel" aria-hidden="true"></span></button>
        <button id="klokReset" title="Klok terugzetten">↺</button>
        <button id="klokNaarEinde" title="Spring naar eindtijd"></button>
        <button id="klokStart" class="primair" title="${k.klok.running?'Pauze':'Start'}">${k.klok.running?'❚❚':'▶'}</button>
      </div>
    </div>

    ${(() => {
      // "Opstelling invoegen" — snelknop bovenaan zolang de héle wedstrijd nog
      // leeg is: vult in één keer alle kwarten uit een sjabloon of vorige
      // wedstrijd. Verschijnt alleen op kwart 1 om het scherm rustig te houden.
      if (Number(S.kwart) !== 1) return '';
      const leeg = !Object.values(w.kwarten || {}).some(k => Object.keys(k.lineup || {}).length);
      if (!leeg) return '';
      return `<button class="sj-invoeg-knop" id="opstellingInvoegen">
        <span class="ico">⧉</span>
        <span class="tk"><span class="tt">Opstelling invoegen</span>
          <span class="ts">Uit een sjabloon of vorige wedstrijd, vult alle kwarten in één keer</span></span>
        <span class="pijl">›</span></button>`;
    })()}

    ${(() => {
      if (Number(S.kwart) !== 1 || opVeld.size > 0) return '';
      const vorige = laatsteOpstelling(w.format);
      if (!vorige || vorige.bron?.id === S.wedstrijdId) return '';
      return `<button class="knop vol u-mb-sm u-c-ink" id="neemVorigeOver" style="background:var(--surface-2);border:1px solid var(--line-d)">⧉ Opstelling vorige wedstrijd overnemen${vorige.bron.tegenstander ? ' (tegen '+esc(vorige.bron.tegenstander)+')' : ''}</button>`;
    })()}

    <div class="veld-wrap"><div class="veld" id="veld">
      <div class="veld-overlay">
        <span class="vo-badge">
          <span class="k">${esc(periodeLabel(w, S.kwart))}</span>
          <span class="f">${esc(kFormatie)}</span>
        </span>
        <button class="vo-knop" id="kwartFormatieKnop" title="Speelwijze van ${esc(periodeOmschrijving(w))} aanpassen">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
            <path d="M4 7h11M4 12h16M4 17h8" stroke="#fff" stroke-width="2" stroke-linecap="round"/>
            <circle cx="18" cy="7" r="2.4" fill="#fff"/><circle cx="9" cy="17" r="2.4" fill="#fff"/>
          </svg>
          <span>Speelwijze</span>
        </button>
      </div>
      <div class="lijn midden"></div><div class="lijn cirkel"></div>
      <div class="lijn zestien-o"></div><div class="lijn vijf-o"></div>
      <div class="lijn zestien-b"></div><div class="lijn vijf-b"></div>
      ${slots.map(s => `
        <div class="slot ${s.id==='K'?'doel':''}" data-slot="${s.id}" style="left:${s.x}%;top:${s.y}%">
          ${lineup[s.id] ? chipHtml(lineup[s.id], 'veld', s.id) : `<div class="ring">${s.id}</div>`}
        </div>`).join('')}
    </div></div>

    <div class="bank" id="bank">
      <div class="bank-kop"><span class="t">Wissels</span>
        <span class="n">${bank.length} op de bank<span class="sep" aria-hidden="true"></span><span class="sorteer">minst gespeeld eerst</span><span class="sep" aria-hidden="true"></span><button id="kiesSelectie" class="u-fw-6 u-t-xs" style="color:var(--fluo);text-decoration:underline">selectie</button></span></div>
      <div class="bank-chips">${bank.length ? bank.map(pid => chipHtml(pid, 'bank')).join('')
        : `<div class="leeg-bank">Iedereen staat op het veld. Sleep een veldspeler hierheen om te wisselen.</div>`}</div>
      <div class="plan-lijst">
        ${(k.plan||[]).length ? `<div class="plan-kop">Geplande wissels</div>` : ''}
        ${(k.plan||[]).map((p,i) => `
          <div class="plan-item ${klokSec(k) >= p.min*60 ? 'nu' : ''}" data-plan-i="${i}">
            <span class="nr in">▲${esc(planInNr(p.in))}</span>
            <span class="nr uit">▼${esc(spelerNr(p.uit))}</span>
            <span>${esc(planInNaam(p.in))} voor ${esc(spelerNaam(p.uit))}</span>
            <span class="min">${String(p.min).replace('.',',')}'</span>
            <button class="pk ok" data-plan-uitvoer="${i}" title="Wissel nu doorvoeren">✓</button>
            <button class="pk weg" data-plan-weg="${i}" title="Geplande wissel verwijderen">✕</button>
          </div>`).join('')}
        <button class="plan-toevoegen" id="planWissel">+ Wissel plannen voor ${esc(periodeOmschrijving(w))}</button>
      </div>
    </div>

    ${(() => {
      const items = [
        ...k.events.map((e,i) => ({soort:'wissel', ...e, i})),
        ...w.goals.map((g,i) => ({soort:'goal', ...g, i})).filter(g => String(g.kwart) === S.kwart),
        ...(w.kaarten||[]).map((c,i) => ({soort:'kaart', ...c, i})).filter(c => String(c.kwart) === S.kwart),
      ].sort((a,b) => (a.sec||0) - (b.sec||0));
      if (!items.length) return '';
      return `<div class="log">
        <div class="sectie-kop">Gebeurtenissen ${esc(periodeOmschrijving(w))}</div>
        ${items.map(e => {
          if (e.soort === 'wissel'){
            const r = e.reden ? wisselReden(e.reden) : null;
            return `
            <div class="log-item">
              ${e.in ? `<span class="nr in">▲${esc(spelerNr(e.in))}</span>` : ''}
              ${e.uit ? `<span class="nr uit">▼${esc(spelerNr(e.uit))}</span>` : ''}
              <span>${e.in ? esc(spelerNaam(e.in)) : ''}${e.in && e.uit ? ' ↔ ' : ''}${e.uit ? esc(spelerNaam(e.uit)) : ''}</span>
              ${e.uit ? `<button class="wissel-reden-badge${r?'':' leeg'}${e.disciplinair?' disc':''}" data-reden-ev="${e.i}" title="Wisselreden ${r?'wijzigen':'toevoegen'}">${r ? (r.ico?ico(r.ico,14):'')+esc(r.label)+(e.disciplinair?' ⚑':'') : '+ reden'}</button>` : ''}
              <span class="min">${gebeurtenisTijd(e.sec, w)}</span>
              <button class="verwijder" data-weg-ev="${e.i}" title="Wissel verwijderen">✕</button>
            </div>`;
          }
          if (e.soort === 'goal') return `
            <div class="log-item bewerkbaar" data-corrigeer-goal="${e.i}" title="Tik om te corrigeren">
              <span class="goal-bal">${e.type==='voor' ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg>' : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M3.4 19V7.6h17.2V19"/><path d="M9.2 7.6V19"/><path d="M14.8 7.6V19"/><path d="M3.4 13.3h17.2"/></svg>'}</span>
              <span><b>${e.type==='voor' ? (e.pid ? esc(spelerNaam(e.pid)) : 'Doelpunt') : 'Tegendoelpunt'}</b>${e.type==='voor' && e.assist ? `<span class="goal-assist">assist ${esc(spelerNaam(e.assist))}</span>` : ''}</span>
              <span class="min">${gebeurtenisTijd(e.sec, w)}</span>
              <span class="bewerk-hint">✎</span>
            </div>`;
          return `
            <div class="log-item kaart bewerkbaar ${e.type==='rood'?'rood':''}" ${e.auto?'':`data-corrigeer-kaart="${e.i}" title="Tik om te corrigeren"`}>
              <span class="goal-bal">${KAART_ICOON[e.type]}</span>
              <span><b>${esc(spelerNaam(e.pid))}</b><span class="sep" aria-hidden="true"></span>${esc(KAART_NAAM[e.type])}${e.type==='tijd' ? ' ('+Math.round(e.duur/60)+' min)' : ''}${e.auto?' (automatisch)':''}</span>
              <span class="min">${gebeurtenisTijd(e.sec, w)}</span>
              ${e.auto ? '' : '<span class="bewerk-hint">✎</span>'}
            </div>`;
        }).join('')}
      </div>`;
    })()}

    <details class="uitklap" id="speeltijdUitklap"${(() => { const o = S._speeltijdOpen; S._speeltijdOpen = false; return o ? ' open' : ''; })()}><summary>Speeltijd deze wedstrijd</summary>
      ${(() => {
        /* Alle periodes naast elkaar: per periode een kolom, plus het wedstrijdtotaal.
           Spelernaam en Totaal blijven bij horizontaal scrollen staan (sticky), zodat
           een toernooi met veel periodes ook op een telefoon leesbaar blijft. */
        const nrs = periodeNrs(w);
        const perP = {}, perV = {};
        for (const nr of nrs){
          const kk = w.kwarten?.[nr];
          perP[nr] = kk ? analyseKwart(w, kk) : {tijd:{}, keeper:new Set(), lijn:{}};
          perV[nr] = kk ? analyseKwartVerwacht(w, kk) : null;
        }
        /* Verwachte speeltijd (geplande wissels als of ze doorgaan): puur weergave.
           De echte speeltijd (perP / aWed) blijft ongemoeid en voedt alle statistieken. */
        const toonVerw = S._toonVerwacht !== false;
        const aVerw = analyseWedstrijdVerwacht(w);
        const heeftPlan = nrs.some(nr => perV[nr] && perV[nr].wissels.length);
        const heeftBeurt = nrs.some(nr => perV[nr] && perV[nr].wissels.some(x => x.beurt));
        let keeperGezien = false;
        const rijen = (w.selectie||[]).filter(pid => speler(pid))
          .sort((a,b) => (aWed.tijd[b]||0) - (aWed.tijd[a]||0)).map(pid => {
          const cellen = nrs.map(nr => {
            const kk = w.kwarten?.[nr];
            const rol = toonVerw && perV[nr] ? perV[nr].rol[pid] : null; // zit in een geplande wissel
            const sec = rol ? perV[nr].tijd[pid] : perP[nr].tijd[pid];
            const opDoel = (rol ? perV[nr].keeper : perP[nr].keeper).has(pid);
            if (opDoel) keeperGezien = true;
            const aangepast = kk && kk.correcties && kk.correcties[pid] != null;
            const wk = rol ? 'w-' + 'abc'[rol.set % 3] : '';
            const kl = ['p-cel','bewerkbaar', sec ? '' : 'leeg', nr === S.kwart ? 'nu' : '', aangepast ? 'aangepast' : '', rol ? 'verw' : '', wk].filter(Boolean).join(' ');
            const tijdTxt = rol ? '~' + mmss(sec || 0) + (rol.beurt ? '★' : '') : (sec ? mmss(sec) : '—');
            const tag = rol ? `<div><span class="wtag ${wk}" title="Geplande wissel">${rol.soort === 'uit' ? 'uit' : 'in'} ${mmss(Math.round(rol.min * 60)).replace(/^0/, '')}</span></div>` : '';
            return `<td class="${kl}" data-corrigeer-speeltijd="${pid}" data-corrigeer-periode="${nr}" title="Tik om speeltijd ${esc(periodeLabel(w, nr))} aan te passen"><div>${tijdTxt}${opDoel ? '<span class="keep" title="Stond op doel">K</span>' : ''}<span class="bewerk-hint">✎</span></div>${tag}</td>`;
          }).join('');
          const totV = aVerw.tijd[pid] || 0;
          const subTot = toonVerw && Math.round(totV) !== Math.round(aWed.tijd[pid] || 0)
            ? `<div class="verw-tot" title="Verwacht als alle geplande wissels doorgaan">~${uurMin(totV)}</div>` : '';
          return `<tr><td class="naam-cel">${esc(spelerNaam(pid))}</td>${cellen}<td class="tijd-cel tot"><div>${aWed.tijd[pid] ? uurMin(aWed.tijd[pid]) : '—'}</div>${subTot}</td></tr>`;
        }).join('');
        /* Schakelaar + uitleg verschijnen alleen als er geplande wissels zijn;
           zonder plan is de tabel exact zoals voorheen. */
        const schakel = heeftPlan
          ? `<button type="button" class="verw-schakel" id="verwSchakel" aria-pressed="${toonVerw}"><span class="knop"><i></i></span><span>Verwachte speeltijd tonen</span></button>` : '';
        const legenda = !heeftPlan ? '' : toonVerw
          ? `<p class="st-legenda"><span class="verw-v">~0:00</span> = verwacht door geplande wissels. Telt niet mee in statistieken, profielen of verslag.</p>
          <p class="st-legenda">Zelfde kleur = één wissel: <span class="wtag w-a">uit</span> <span class="wtag w-a">in</span>. Een volgende wissel in dezelfde periode krijgt een andere kleur.</p>
          ${heeftBeurt ? `<p class="st-legenda">★ = invaller “wie aan de beurt is”; die telt pas mee zodra de wissel is doorgevoerd.</p>` : ''}`
          : `<p class="st-legenda">Zo zien de statistieken de wedstrijd: alleen opstelling en doorgevoerde wissels.</p>`;
        return `<div class="inhoud">
          ${schakel}
          <div class="st-scroll"><table class="stat-tabel st-periodes">
            <thead><tr><th>Speler</th>${nrs.map(nr => `<th class="${nr === S.kwart ? 'nu' : ''}">${esc(periodeLabel(w, nr))}</th>`).join('')}<th class="tot">Totaal</th></tr></thead>
            <tbody>${rijen}</tbody></table></div>
          ${legenda}
          ${keeperGezien ? `<p class="st-legenda"><span class="keep">K</span> = stond die periode op doel</p>` : ''}
          <p class="st-uitleg">Tik op een speeltijd om die periode voor een speler handmatig te corrigeren, bijvoorbeeld als een wissel vergeten is door te voeren.</p>
        </div>`;
      })()}
    </details>

    <button class="knop fluo vol u-mt-md" id="wedstrijdKlaar" >${ico('admin-save',16)} Opslaan &amp; terug naar team</button>
    <button class="knop secundair vol u-mt-sm" id="bijwerkKnop" >✎ Wedstrijd achteraf bijwerken</button>
    <button class="knop secundair vol u-mt-sm" id="toonVerslag" ><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="5" y="4.5" width="14" height="16" rx="2.2"/><path d="M9 3.2h6v3H9z"/><path d="M8.8 11.4h6.4"/><path d="M8.8 15.4h4"/></svg> Wedstrijdverslag</button>
    ${modAan('evaluaties') ? `<button class="knop secundair vol u-mt-sm" id="teamEvalKnop" >${teamEvalBestaand?'✓ Teamevaluatie bijwerken':'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/></svg> Team evalueren'}</button>` : ''}
    <button class="knop secundair vol u-mt-sm" id="tactiekbordKnop" >✎ Tactiekbord</button>
    <button class="knop secundair vol u-mt-sm" id="bewaarSjabloon" >⧉ Opslaan als sjabloon</button>
    <button class="knop destructief vol u-mt-md" id="wegWedstrijd" >Wedstrijd verwijderen</button>`;

  /* ---- koppelingen ---- */
  v.querySelector('#naarTeam').onclick = () => history.back();
  v.querySelector('#wInstellingen').onclick = () => toonWijzigOpzet();
  const bsj = v.querySelector('#bewaarSjabloon');
  if (bsj) bsj.onclick = () => bewaarWedstrijdAlsSjabloon(w);
  const tbk = v.querySelector('#tactiekbordKnop');
  if (tbk) tbk.onclick = () => import('./tactiekbord.js?v=20261106h').then(m => m.openTactiekLijst(w));
  v.querySelector('#doelBanner').onclick = () => toonWijzigOpzet('doel');
  v.querySelector('#subFormatieKlik').onclick = (e) => { e.stopPropagation(); toonKwartFormatie(); };
  { const kfk = v.querySelector('#kwartFormatieKnop'); if (kfk) kfk.onclick = toonKwartFormatie; }
  v.querySelectorAll('[data-kwart]').forEach(b => b.onclick = () => {
    /* Alleen van tab wisselen — geen automatische kopie meer; het lege kwart
       toont zelf een expliciete overneem-knop (kwart-leeg-actie). */
    S.kwart = b.dataset.kwart; S.geselecteerd = null;
    telNav('wedstrijd:kwart' + b.dataset.kwart, 'tab');
    renderWedstrijd();
  });
  v.querySelector('#goalVoor').onclick = modalGoalVoor;
  v.querySelector('#goalTegen').onclick = () => registreerGoal({type:'tegen'});
  v.querySelector('#kaartKnop').onclick = modalKaart;
  v.querySelector('#wedstrijdKlaar').onclick = () => {
    // Directe (flush) save — het meeste is al automatisch bewaard, maar dit
    // geeft de coach het vertrouwde "opslaan"-gevoel en dekt de laatste wijziging.
    clearTimeout(S.saveTimer);
    setDoc(doc(db,'teams',S.teamId,'wedstrijden',S.wedstrijdId), S.wedstrijd)
      .catch(e => meld('Opslaan mislukt: ' + e.code));
    meld('Wedstrijd opgeslagen');
    sluitWedstrijd('wedstrijden');
  };
  v.querySelector('#toonVerslag').onclick = modalVerslag;
  { const bwk = v.querySelector('#bijwerkKnop'); if (bwk) bwk.onclick = () => { S.bijwerkKwart = S.kwart; toonBijwerkScherm(); }; }
  const teamEvalKnop = v.querySelector('#teamEvalKnop');
  if (teamEvalKnop) teamEvalKnop.onclick = () => {
    import('./teams.js?v=20261106h').then(m => m.modalTeamEvaluatie(S.wedstrijdId));
  };
  v.querySelectorAll('[data-corrigeer-goal]').forEach(b => b.onclick = e => {
    e.stopPropagation(); modalGoalCorrigeren(Number(b.dataset.corrigeerGoal));
  });
  v.querySelectorAll('[data-corrigeer-kaart]').forEach(b => b.onclick = e => {
    e.stopPropagation(); modalKaartCorrigeren(Number(b.dataset.corrigeerKaart));
  });
  const sbT = v.querySelector('#sbTegenNaam');
  if (sbT) sbT.onclick = () => {
    const wnr = toernooiWnr(w);
    openModal(`
      <h2>Tegenstander wedstrijd ${wnr}</h2>
      <p class="u-t-md u-zacht u-mb-sm">Vul de naam in zoals die op het wedstrijdschema staat.</p>
      <input class="invoer" id="mTegenNaam" value="${esc((w.tegenstanders||{})[wnr] || '')}" style="margin-bottom:var(--space-md)">
      <div style="display:flex;gap:var(--space-sm)">
        <button class="knop secundair u-flex-1" id="mTegenNee" >Annuleren</button>
        <button class="knop fluo u-flex-1" id="mTegenJa" >Opslaan</button>
      </div>`);
    $('#mTegenNaam').focus();
    $('#mTegenNee').onclick = sluitModal;
    $('#mTegenJa').onclick = () => {
      (w.tegenstanders ||= {})[wnr] = $('#mTegenNaam').value.trim();
      sluitModal(); bewaarWedstrijd(); renderWedstrijd();
    };
  };
  { const kt = v.querySelector('#klokTijd'); if (kt) kt.onclick = modalKlokInstellen; }
  v.querySelector('#klokStart').onclick = klokStartPauze;
  v.querySelector('#klokReset').onclick = () => {
    if (klokSec(k) < 1){ klokReset(); return; }
    openModal(`
      <h2>Klok terugzetten?</h2>
      <p class="u-t-md u-zacht u-lh-ruim u-mb-md">Er is al <b class="u-c-ink">${mmss(klokSec(k))}</b> gespeeld in ${esc(periodeOmschrijving(w))}. De klok gaat terug naar 00:00, geregistreerde wissels en doelpunten blijven staan.</p>
      <div style="display:flex;gap:var(--space-sm)">
        <button class="knop secundair u-flex-1" id="mResetNee" >Annuleren</button>
        <button class="knop fluo u-flex-1" id="mResetJa" >↺ Terugzetten</button>
      </div>`, {vorm:'dialoog'});
    $('#mResetNee').onclick = sluitModal;
    $('#mResetJa').onclick = () => { sluitModal(); klokReset(); };
  };
  v.querySelector('#klokNaarEinde').onclick = klokNaarEinde;
  const ovk = v.querySelector('#overneemVorigKwart'); if (ovk) ovk.onclick = kopieerVorigKwart;
  // (selectie-hint verwijderd op verzoek — gaf visuele ruis en veroorzaakte
  // een scroll-sprong doordat de pagina-hoogte veranderde bij het selecteren)

  /* Vorige confrontatie: regeltje klapt het paneel open/dicht (lokale UI-stand). */
  const confroRegel = v.querySelector('#confroRegel');
  if (confroRegel) confroRegel.onclick = () => {
    S._confroOpen = !S._confroOpen;
    v.querySelector('#confroRegel')?.classList.toggle('open', S._confroOpen);
    v.querySelector('#confroPaneel')?.classList.toggle('open', S._confroOpen);
  };
  const confroOpen = v.querySelector('#confroOpen');
  if (confroOpen) confroOpen.onclick = () => {
    const wid = confroOpen.dataset.wid;
    if (wid){ S._confroOpen = false; openWedstrijd(wid); }
  };
  const oiv = v.querySelector('#opstellingInvoegen');
  if (oiv) oiv.onclick = () => {
    // callback zodat de sjabloon-module na toepassen kan laten opslaan+hertekenen
    zetNaToepassenCallback(() => { S.kwart = '1'; bewaarWedstrijd(); renderWedstrijd(); });
    openInvoegSheet(w);
  };
  const nvo = v.querySelector('#neemVorigeOver');
  if (nvo) nvo.onclick = () => {
    const vorige = laatsteOpstelling(w.format);
    if (!vorige){ meld('Geen vorige opstelling gevonden'); return; }
    const lineup = {};
    for (const [slot, pid] of Object.entries(vorige.lineup))
      if ((w.selectie||[]).includes(pid) && speler(pid)) lineup[slot] = pid;
    if (!Object.keys(lineup).length){ meld('Geen spelers uit de vorige opstelling zitten in deze selectie'); return; }
    w.kwarten['1'].lineup = lineup;
    if (formatieBestaat(w.format, vorige.formatie, eigenFormatiesVanTeam()) || parseFormatie(vorige.formatie, w.format)) w.formatie = vorige.formatie;
    S.kwart = '1';
    bewaarWedstrijd(); renderWedstrijd();
    meld(`Opstelling overgenomen${vorige.bron.tegenstander ? ' van wedstrijd tegen '+vorige.bron.tegenstander : ''} — pas aan waar nodig`);
  };
  v.querySelector('#kiesSelectie').onclick = modalSelectie;
  v.querySelector('#planWissel').onclick = modalPlanWissel;
  { const vs = v.querySelector('#verwSchakel');
    if (vs) vs.onclick = () => { S._toonVerwacht = S._toonVerwacht === false; S._speeltijdOpen = true; renderWedstrijd(); }; }
  v.querySelectorAll('[data-plan-uitvoer]').forEach(b => b.onclick = e => { e.stopPropagation(); voerPlanUit(Number(b.dataset.planUitvoer)); });
  v.querySelectorAll('[data-plan-weg]').forEach(b => b.onclick = e => { e.stopPropagation(); (huidigKwart().plan||[]).splice(Number(b.dataset.planWeg),1); bewaarWedstrijd(); renderWedstrijd(); });
  v.querySelectorAll('[data-weg-ev]').forEach(b => b.onclick = e => { e.stopPropagation(); verwijderEvent(Number(b.dataset.wegEv)); });
  v.querySelectorAll('[data-reden-ev]').forEach(b => b.onclick = e => { e.stopPropagation(); modalWisselReden(huidigKwart(), Number(b.dataset.redenEv)); });
  v.querySelectorAll('[data-corrigeer-speeltijd]').forEach(td => td.onclick = e => {
    e.stopPropagation();
    modalSpeeltijdCorrigeren(td.dataset.corrigeerSpeeltijd, td.dataset.corrigeerPeriode ? {kwart: td.dataset.corrigeerPeriode} : {});
  });
  /* Speeltijdtabel: bij veel periodes (of een smal scherm) past niet alles naast
     elkaar. We schuiven de actieve periode dan in beeld, links van de vastgezette
     Totaal-kolom. Ook na het openklappen, want dan pas is de breedte bekend. */
  { const sp = v.querySelector('#speeltijdUitklap');
    if (sp){
      const naarNu = () => {
        const sc = sp.querySelector('.st-scroll'); if (!sc || !sc.clientWidth) return;
        const nu = sc.querySelector('th.nu'), tot = sc.querySelector('th.tot');
        if (!nu) return;
        const doel = nu.offsetLeft + nu.offsetWidth + (tot ? tot.offsetWidth : 0) - sc.clientWidth;
        if (doel > 0) sc.scrollLeft = doel;
      };
      sp.addEventListener('toggle', naarNu);
      naarNu();
    } }
  v.querySelector('#wegWedstrijd').onclick = async () => {
    if (!confirm('Deze wedstrijd en alle opstellingen verwijderen?')) return;
    await deleteDoc(doc(db,'teams',S.teamId,'wedstrijden',S.wedstrijdId));
    sluitWedstrijd();
  };

  clearInterval(S.klokInterval);
  if (k.klok.running) S.klokInterval = setInterval(tikKlok, 500);

  koppelSleep(v);

  /* Scrollpositie terugzetten na het hertekenen, zodat de coach niet steeds
     omhoog springt bij het selecteren van een speler. In een rAF zodat de
     browser eerst de nieuwe layout heeft berekend voordat we terugscrollen. */
  if (bewaardeScroll > 0) requestAnimationFrame(() => window.scrollTo(0, bewaardeScroll));
}

/* ==================== WEDSTRIJDINSTELLINGEN & SELECTIE ==================== */
/* ==================== WIJZIG OPZET (basisgegevens + speelwijze + doel & notitie) ====================
   Eén doorlopend top-paneel met alle drie onderdelen onder elkaar (i.p.v. los doorklikken via
   een menu). Klapt van bovenaf open — een bewuste keuze t.o.v. de bottom-sheet die de rest van
   de app gebruikt, omdat dit paneel bewust "zwaarder" mag voelen dan een snelle actie.
   sectie ('basis' | 'speelwijze' | 'doel') scrollt direct naar het juiste kopje wanneer je
   binnenkomt via een snelkoppeling (tik op de formatie of het doel-banner in het wedstrijdscherm). */
function toonWijzigOpzet(sectie){
  const w = S.wedstrijd;
  let format = w.format, formatie = w.formatie;

  $('#woPaneel').innerHTML = `
    <div class="wo-topbar"><h2>Wijzig opzet</h2><div class="wo-sluit" id="woSluit">✕</div></div>

    <div class="wo-sectiekop" id="woSecBasis"><span class="ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M15.4 4.8 19.2 8.6 9 18.8l-4 1.2 1.2-4z"/><path d="M13.4 6.8 17.2 10.6"/></svg></span><span>Basisgegevens</span><div class="wo-lijn"></div></div>
    <div class="veldgroep"><label>${isToernooi(w) ? 'Naam toernooi' : 'Tegenstander'}</label>
      <span class="wo-opg" data-opg="tegen"></span>
      <input class="invoer" id="woTegen" value="${esc(w.tegenstander)}"></div>
    ${heeftElftallen() && !isToernooi(w) ? `<div class="veldgroep"><label>Elftal</label>
      <span class="wo-opg" data-opg="elftal"></span>
      <div class="segment" id="woElftal">${['1','2'].map(e =>
        `<button data-el="${e}" class="${elftalWedstrijd(w)===e?'actief':''}">${elftalNaam(e)}</button>`).join('')}</div></div>` : ''}
    <div class="rij">
      <div class="veldgroep"><label>Datum</label><span class="wo-opg" data-opg="datum"></span><input class="invoer" type="date" id="woDatum" value="${esc(w.datum)}"></div>
      <div class="veldgroep"><label>Minuten per periode</label><span class="wo-opg" data-opg="duur"></span><input class="invoer" id="woDuur" inputmode="decimal" value="${esc(w.kwartduur)}"></div>
    </div>
    <div class="veldgroep"><label>Aanvoerder</label>
      <span class="wo-opg" data-opg="aanvoerder"></span>
      <button type="button" class="wo-aanv-knop" id="woAanvoerderKnop">
        <span class="wo-aanv-ico"><span class="aanvoerder-band">C</span></span>
        <span class="wo-aanv-tekst">
          <span class="wo-aanv-titel">${(w.periodes||4) === 2 ? 'Aanvoerder per helft' : 'Aanvoerder per kwart'}</span>
          <span class="wo-aanv-sam" id="woAanvoerderSam"></span>
        </span>
        <span class="wo-aanv-pijl">${ico('navigation-forward',18)}</span>
      </button></div>

    <div class="wo-sectiekop" id="woSecSpeelwijze"><span class="ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><rect x="3.2" y="4.6" width="17.6" height="14.8" rx="2.4"/><path d="M12 4.6v14.8"/><circle cx="12" cy="12" r="2.8"/></svg></span><span>Speelwijze & formatie</span><div class="wo-lijn"></div></div>
    <div class="veldgroep"><label>Aantal spelers</label>
      <span class="wo-opg" data-opg="format"></span>
      <div class="segment" id="woFormat">${['4','5','6','7','8','9','10','11'].map(f =>
        `<button data-f="${f}" class="${w.format===f?'actief':''}">${f}×${f}</button>`).join('')}</div></div>
    <div class="veldgroep"><label>Formatie (excl. keeper)</label>
      <span class="wo-opg" data-opg="formatie"></span>
      <div class="segment wrap" id="woFormatie"></div>
      <div id="woEigen">${eigenFormatieInvoerHtml()}</div>
      <p class="u-t-xs u-zacht u-mt-xs">Wijzig je het format, dan past de app de formatie automatisch aan en blijven spelers zoveel mogelijk op hun plek.</p>
      <div id="woFormatieHint"></div></div>
    <button class="knop licht vol u-mt-3xs" id="woSjabloon" >⧉ Standaardopstelling invoegen</button>
    <p class="u-t-2xs u-zacht u-mt-2xs">Vult alle kwarten met een opgeslagen sjabloon of een vorige wedstrijd. Dit vervangt de huidige opstellingen.</p>

    <div class="wo-sectiekop" id="woSecDoel"><span class="ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.5"/><circle cx="12" cy="12" r="3.5"/><circle cx="12" cy="12" r="0.6" fill="currentColor" stroke="none"/><path d="M12 3.5v3M12 17.5v3M3.5 12h3M17.5 12h3"/></svg></span><span>Doel & notitie</span><div class="wo-lijn"></div></div>
    <div class="veldgroep"><label>Wedstrijddoel</label>
      <span class="wo-opg" data-opg="doel"></span>
      <input class="invoer" id="woDoel" value="${esc(w.doel||'')}" placeholder="Bijv. opbouw van achteruit, durven schieten">
      <div id="woTrainDoelen"></div>
      <div class="doel-suggesties" id="woDoelSug">
        ${doelSuggesties(S.team?.categorie).map(s => `<button type="button" data-doelsug="${esc(s)}">${esc(s)}</button>`).join('')}
      </div>
      <p class="u-t-2xs u-zacht u-mt-2xs"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.2"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2M6.3 6.3l1.5 1.5M16.2 16.2l1.5 1.5M17.7 6.3l-1.5 1.5M7.8 16.2l-1.5 1.5"/></svg> Suggesties op basis van de leercurve (§3.3) voor ${esc(S.team?.categorie||'dit team')} — tik om over te nemen, of typ je eigen doel.</p></div>
    <div class="veldgroep"><label>Notitie</label>
      <span class="wo-opg" data-opg="notitie"></span>
      <textarea class="invoer" id="woNotitie" rows="3" placeholder="Bijv. sterke counter, druk zetten op hun nr. 7. Zichtbaar bij de volgende keer tegen deze tegenstander.">${esc(w.notitie||'')}</textarea></div>

    <div class="wo-status" id="woStatus">${ico('admin-save',15)}<span id="woStatusTekst">Alles wordt automatisch opgeslagen</span></div>
    <button class="knop vol fluo u-mt-sm" id="woOk" >Klaar</button>`;
  $('#woAchter').classList.add('open');

  const toonFormatieHint = () => {
    const el = $('#woFormatieHint');
    if (!el) return;
    if (format !== '11'){ el.innerHTML = ''; return; }
    if (formatie === CLUB_FORMATIE_11){
      el.innerHTML = `<div class="formatie-hint match"><span class="fh-ico">✓</span><span><b>Sluit aan bij de clubvisie (§3.2).</b> Bij balbezit schuift één verdediger in naar het middenveld (1:3:4:3) voor een overtal, steeds een andere speler, zodat iedereen leert opbouwen.</span></div>`;
    } else {
      el.innerHTML = `<div class="formatie-hint info"><span class="fh-ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="3.2"/><path d="M12 4v2M12 18v2M4 12h2M18 12h2M6.3 6.3l1.5 1.5M16.2 16.2l1.5 1.5M17.7 6.3l-1.5 1.5M7.8 16.2l-1.5 1.5"/></svg></span><span>Het jeugdbeleidsplan gaat uit van <b>${esc(CLUB_FORMATIE_11)}</b> als basis (§3.2). Kies je bewust voor ${esc(formatie)}? Laat dan de vrije verdediger een opbouwende rol spelen, niet achter de mandekkers.</span></div>`;
    }
  };
  // ── Autosave-helper ──────────────────────────────────────────────
  // Toont kort een groen "Opgeslagen"-vinkje bij het veld + statusregel,
  // en laat bewaarWedstrijd() (600ms-debounce) het naar Firestore schrijven.
  const opgTimers = {};
  const bewaarVeld = (opg, label) => {
    bewaarWedstrijd();
    const badge = $(`.wo-opg[data-opg="${opg}"]`);
    if (badge){
      badge.innerHTML = `${ico('admin-save',12)} Opgeslagen`;
      badge.classList.add('zichtbaar');
      clearTimeout(opgTimers[opg]);
      opgTimers[opg] = setTimeout(() => badge.classList.remove('zichtbaar'), 1600);
    }
    const st = $('#woStatus'), stt = $('#woStatusTekst');
    if (st && stt){
      st.classList.add('actief');
      stt.textContent = 'Laatst opgeslagen: ' + label;
      clearTimeout(opgTimers._st);
      opgTimers._st = setTimeout(() => {
        st.classList.remove('actief');
        stt.textContent = 'Alles wordt automatisch opgeslagen';
      }, 2000);
    }
  };

  // Past een gewijzigd format/formatie meteen toe op het wedstrijdmodel:
  // schoont opstelling-slots + events op die niet meer bestaan en slaat op.
  // Spelers op nog bestaande plekken blijven staan.
  const pasSpeelwijzeToe = (opg, label) => {
    if (format === w.format && formatie === w.formatie) return;
    const nieuweIds = new Set(bouwSlots(format, formatie).map(s => s.id));
    for (const kk of Object.values(w.kwarten)){
      for (const slot of Object.keys(kk.lineup)) if (!nieuweIds.has(slot)) delete kk.lineup[slot];
      kk.events = kk.events.filter(e => nieuweIds.has(e.slot));
    }
    w.format = format; w.formatie = formatie;
    bewaarVeld(opg, label);
  };

  const efInvoer = koppelEigenFormatieInvoer($('#woEigen'), () => format, (naam) => {
    formatie = naam; vulFormaties(); toonFormatieHint(); pasSpeelwijzeToe('formatie', 'Formatie → ' + naam);
  });
  const vulFormaties = () => {
    const namen = formatieNamen(format, eigenFormatiesVanTeam());
    $('#woFormatie').innerHTML = namen.map(f =>
      `<button data-f="${f}" class="${formatie===f?'actief':''}">${f}</button>`).join('') +
      `<button class="ef-knop" data-eigen="1">+ Eigen</button>`;
    $$('#woFormatie button[data-f]').forEach(b => b.onclick = () => {
      $$('#woFormatie button').forEach(x=>x.classList.remove('actief')); b.classList.add('actief'); formatie = b.dataset.f;
      toonFormatieHint(); pasSpeelwijzeToe('formatie', 'Formatie → ' + formatie);
    });
    const eb = $('#woFormatie button[data-eigen]');
    if (eb) eb.onclick = () => efInvoer.toonInvoer();
    toonFormatieHint();
  };
  vulFormaties();
  $$('#woFormat button').forEach(b => b.onclick = () => {
    $$('#woFormat button').forEach(x=>x.classList.remove('actief')); b.classList.add('actief');
    format = b.dataset.f;
    if (!formatieBestaat(format, formatie, eigenFormatiesVanTeam())) formatie = Object.keys(FORMATIES[format])[0];
    vulFormaties();
    pasSpeelwijzeToe('format', 'Aantal spelers → ' + format + '×' + format);
  });

  // ── Basisgegevens: aanvoerder per periode (sheet) + tekstvelden (blur) ──
  const vulAanvoerderSam = () => {
    const el = $('#woAanvoerderSam'); if (!el) return;
    const n = w.periodes || 4;
    const delen = [];
    for (let i = 1; i <= n; i++){
      const pid = aanvoerderVan(w, i);
      if (pid) delen.push(`${periodeLabel(w, String(i))} ${spelerNaam(pid)}`);
    }
    // Alle periodes dezelfde aanvoerder? Toon dan één compacte regel.
    const uniek = aanvoerdersInWedstrijd(w);
    if (uniek.length === 1 && delen.length === n){
      el.textContent = `Hele wedstrijd: ${spelerNaam(uniek[0])}`;
      el.classList.remove('leeg');
    } else if (delen.length){
      el.textContent = delen.join(', ');
      el.classList.remove('leeg');
    } else {
      el.textContent = 'Nog niet ingesteld';
      el.classList.add('leeg');
    }
  };
  vulAanvoerderSam();
  $('#woAanvoerderKnop').onclick = () => toonAanvoerderSheet(() => {
    vulAanvoerderSam();
    bewaarVeld('aanvoerder', 'Aanvoerder');
  });
  $$('#woElftal button').forEach(b => b.onclick = () => {
    if (elftalWedstrijd(w) === b.dataset.el) return;
    $$('#woElftal button').forEach(x => x.classList.toggle('actief', x === b));
    w.elftal = b.dataset.el;
    bewaarVeld('elftal', 'Elftal');
  });
  const tekstVelden = [
    ['#woTegen',   'tegen',   'Tegenstander', el => { const v = el.value.trim(); if (v) w.tegenstander = v; }],
    ['#woDatum',   'datum',   'Datum',        el => { if (el.value) w.datum = el.value; }],
    ['#woDuur',    'duur',    'Minuten',      el => { const n = parseFloat((el.value||'').replace(',','.')); if (n) w.kwartduur = n; }],
    ['#woDoel',    'doel',    'Wedstrijddoel',el => { w.doel = el.value.trim(); }],
    ['#woNotitie', 'notitie', 'Notitie',      el => { w.notitie = el.value.trim(); }],
  ];
  tekstVelden.forEach(([sel, opg, label, apply]) => {
    const el = $(sel); if (!el) return;
    el._startwaarde = el.value;
    el.addEventListener('blur', () => {
      if (el.value === el._startwaarde) return;
      el._startwaarde = el.value;
      apply(el);
      bewaarVeld(opg, label);
    });
  });

  $$('#woDoelSug [data-doelsug]').forEach(b => b.onclick = () => {
    const inp = $('#woDoel'); inp.value = b.dataset.doelsug; inp._startwaarde = inp.value;
    w.doel = inp.value.trim();
    bewaarVeld('doel', 'Wedstrijddoel');
  });

  // Trainingsdoelen van deze week als tegels boven de leercurve-suggesties.
  // Kiest een tegel → vult het wedstrijddoel-veld. Faalt stil (leeg = geen blok).
  const kiesTrainDoel = (tekst) => {
    const inp = $('#woDoel'); if (inp){ inp.value = tekst; inp._startwaarde = tekst; }
    $$('#woTrainDoelen .wz-doel-tegel').forEach(x => x.classList.remove('wz-actief'));
    w.doel = (tekst||'').trim();
    bewaarVeld('doel', 'Wedstrijddoel');
  };
  laadTrainingsdoelTegels(w, kiesTrainDoel, 'woTrainDoelen')
    .catch(e => console.warn('[wo] trainingsdoelen laden faalde', e));

  // Sluiten via ✕ of tik naast het paneel: neem een nog niet ge-blurde
  // tekstveldwijziging mee, sluit en herteken het wedstrijdscherm.
  const sluitOpzet = () => {
    w.tegenstander = $('#woTegen').value.trim() || w.tegenstander;
    w.datum = $('#woDatum').value || w.datum;
    w.kwartduur = parseFloat(($('#woDuur').value||'').replace(',','.')) || w.kwartduur;
    w.doel = $('#woDoel').value.trim();
    w.notitie = $('#woNotitie').value.trim();
    verbergWijzigOpzet();
    bewaarWedstrijd();
    renderWedstrijd();
  };
  $('#woSluit').onclick = sluitOpzet;
  $('#woAchter').onclick = (e) => { if (e.target.id === 'woAchter') sluitOpzet(); };

  const woSj = $('#woSjabloon');
  if (woSj) woSj.onclick = () => {
    // sluit eerst het wijzig-opzet-paneel zodat de invoeg-sheet er bovenop komt,
    // en registreer de callback die na toepassen opslaat + hertekent.
    verbergWijzigOpzet();
    zetNaToepassenCallback(() => { S.kwart = '1'; bewaarWedstrijd(); renderWedstrijd(); });
    openInvoegSheet(w);
  };

  // "Klaar" — alles is al automatisch bewaard; we pakken alleen nog een
  // eventuele wijziging mee die nog in een tekstveld staat zonder blur.
  $('#woOk').onclick = sluitOpzet;

  if (sectie){
    const anker = {basis:'woSecBasis', speelwijze:'woSecSpeelwijze', doel:'woSecDoel'}[sectie];
    if (anker) requestAnimationFrame(() => $(`#${anker}`)?.scrollIntoView({block:'start'}));
  }
}

/* Kwart-formatie kiezer (bottom-sheet). Wijzigt ALLEEN de speelwijze van het
   actieve kwart; andere kwarten blijven ongemoeid. Spelers schuiven zoveel
   mogelijk mee naar hun plek (zie herplaatsKwart). Bereikbaar via de knop in
   de balk boven het veld én via de onderstreepte formatie onder de titel. */
function toonKwartFormatie(){
  const w = S.wedstrijd; if (!w) return;
  const k = huidigKwart();
  const huidig = kwartFormatie(w, k);
  let gekozen = huidig;
  const kwartTekst = periodeOmschrijving(w);

  const el = document.createElement('div');
  el.className = 'kf-achter';
  el.innerHTML = `
    <div class="kf-sheet">
      <div class="kf-greep"></div>
      <h2>Speelwijze ${esc(periodeLabel(w, S.kwart))}</h2>
      <p class="kf-sub">Alleen de speelwijze van <b>${esc(kwartTekst)}</b> verandert. Andere ${esc((w.periodes||4)===2?'helften':'kwarten')} blijven staan. Opgestelde spelers schuiven zoveel mogelijk mee naar hun plek.</p>
      <div class="kf-grid">${formatieNamen(w.format, eigenFormatiesVanTeam()).map(f =>
        `<button data-f="${esc(f)}" class="${f===huidig?'actief':''}">${esc(f)}</button>`).join('')}<button class="ef-knop kf-eigen" data-eigen="1">+ Eigen</button></div>
      <div id="kfEigen">${eigenFormatieInvoerHtml()}</div>
      <div class="kf-acties">
        <button class="kf-annuleer" id="kfAnnuleer">Annuleren</button>
        <button class="kf-ok" id="kfOk">Toepassen op dit ${esc((w.periodes||4)===2?'helft':'kwart')}</button>
      </div>
    </div>`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('open'));

  const sluit = () => { el.classList.remove('open'); setTimeout(() => el.remove(), 220); };

  const efKwart = koppelEigenFormatieInvoer(el.querySelector('#kfEigen'), () => w.format, (naam) => {
    gekozen = naam; vulGrid();
  });
  const bindGrid = () => {
    el.querySelectorAll('.kf-grid button[data-f]').forEach(b => b.onclick = () => {
      el.querySelectorAll('.kf-grid button').forEach(x => x.classList.remove('actief'));
      b.classList.add('actief'); gekozen = b.dataset.f;
    });
    const eb = el.querySelector('.kf-grid button[data-eigen]');
    if (eb) eb.onclick = () => efKwart.toonInvoer();
  };
  const vulGrid = () => {
    el.querySelector('.kf-grid').innerHTML = formatieNamen(w.format, eigenFormatiesVanTeam()).map(f =>
      `<button data-f="${esc(f)}" class="${f===gekozen?'actief':''}">${esc(f)}</button>`).join('') +
      `<button class="ef-knop kf-eigen" data-eigen="1">+ Eigen</button>`;
    bindGrid();
  };
  bindGrid();
  el.querySelector('#kfAnnuleer').onclick = sluit;
  el.onclick = (e) => { if (e.target === el) sluit(); };
  el.querySelector('#kfOk').onclick = () => {
    if (gekozen !== huidig && formatieBestaat(w.format, gekozen, eigenFormatiesVanTeam())){
      herplaatsKwart(w, k, gekozen);
      bewaarWedstrijd();
      sluit();
      renderWedstrijd();
      meld(`Speelwijze ${periodeOmschrijving(w)} → ${gekozen}`);
    } else {
      sluit();
    }
  };
}

/* Aanvoerder-per-periode kiezer (bottom-sheet). Bovenaan een carrousel met de
   periodes (Q1…Qn of 1e/2e helft — meebewegend met w.periodes); daaronder de
   selectie om per periode de aanvoerder te tikken. "Hele wedstrijd" kopieert de
   keuze van de actieve periode naar alle periodes. Schrijft rechtstreeks in
   w.aanvoerders via zetAanvoerder(); onKlaar wordt bij sluiten aangeroepen zodat
   de aanroeper (Wijzig opzet) de samenvatting kan verversen + opslaan. */
function toonAanvoerderSheet(onKlaar){
  const w = S.wedstrijd; if (!w) return;
  const n = w.periodes || Object.keys(w.kwarten||{}).length || 4;
  const nrs = []; for (let i = 1; i <= n; i++) nrs.push(String(i));
  const selSpelers = (w.selectie||[]).map(pid => speler(pid)).filter(Boolean);
  let actief = '1';

  const el = document.createElement('div');
  el.className = 'kf-achter aanv-achter';
  el.innerHTML = `
    <div class="kf-sheet aanv-sheet">
      <div class="kf-greep"></div>
      <h2>Aanvoerder ${(n===2?'per helft':'per kwart')}</h2>
      <p class="kf-sub">Kies per ${(n===2?'helft':'kwart')} wie de band draagt. Tik een ${(n===2?'helft':'kwart')} en daarna een speler.</p>
      <div class="aanv-carr" id="aanvCarr" style="--aanv-cols:${Math.min(n, 4)}"></div>
      <button type="button" class="aanv-heel" id="aanvHeel">${ico('action-copy',15)}<span>Hele wedstrijd dezelfde aanvoerder</span></button>
      <div class="aanv-lijstkop" id="aanvLijstKop"></div>
      <div class="aanv-lijst" id="aanvLijst"></div>
      <div class="kf-acties">
        <button class="kf-ok aanv-klaar" id="aanvKlaar">Klaar</button>
      </div>
    </div>`;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('open'));

  const sluit = () => {
    el.classList.remove('open');
    setTimeout(() => el.remove(), 220);
    onKlaar && onKlaar();
  };

  const carr = el.querySelector('#aanvCarr');
  const lijst = el.querySelector('#aanvLijst');
  const lijstKop = el.querySelector('#aanvLijstKop');

  const tekenCarr = () => {
    carr.innerHTML = nrs.map(nr => {
      const pid = aanvoerderVan(w, nr);
      const isA = nr === actief;
      const naam = pid ? spelerNaam(pid).split(' ')[0] : '–';
      return `<button type="button" data-nr="${nr}" class="aanv-tegel ${isA?'actief':''}">
        ${pid ? '<span class="aanv-punt"></span>' : ''}
        <span class="aanv-q">${esc(periodeLabel(w, nr))}</span>
        <span class="aanv-naam">${esc(naam)}</span>
      </button>`;
    }).join('');
    carr.querySelectorAll('[data-nr]').forEach(b => b.onclick = () => { actief = b.dataset.nr; teken(); });
  };

  const tekenLijst = () => {
    lijstKop.innerHTML = `Aanvoerder voor <b>${esc(periodeLabel(w, actief))}</b>`;
    lijst.innerHTML = selSpelers.map(p => {
      const isA = aanvoerderVan(w, actief) === p.id;
      const eerder = nrs.filter(nr => nr !== actief && aanvoerderVan(w, nr) === p.id)
        .map(nr => periodeLabel(w, nr));
      const badge = isA
        ? `<span class="aanv-b c">C</span>`
        : `<span class="aanv-b nr">${esc(spelerNr(p.id))}</span>`;
      const meta = eerder.length ? `<span class="aanv-meta">band in ${esc(eerder.join(', '))}</span>` : '';
      return `<button type="button" data-pid="${p.id}" class="aanv-rij ${isA?'actief':''}">
        ${badge}
        <span class="aanv-rij-tekst"><span class="aanv-rij-naam">${esc(p.naam)}</span>${meta}</span>
        ${isA ? `<span class="aanv-vink">${ico('action-check',18)}</span>` : ''}
      </button>`;
    }).join('');
    lijst.querySelectorAll('[data-pid]').forEach(b => b.onclick = () => {
      const pid = b.dataset.pid;
      zetAanvoerder(w, actief, aanvoerderVan(w, actief) === pid ? null : pid);
      teken();
    });
  };

  const teken = () => { tekenCarr(); tekenLijst(); };
  teken();

  el.querySelector('#aanvHeel').onclick = () => {
    const pid = aanvoerderVan(w, actief);
    for (const nr of nrs) zetAanvoerder(w, nr, pid);
    teken();
    meld(pid ? `Hele wedstrijd: ${spelerNaam(pid)} als aanvoerder` : 'Aanvoerder overal gewist');
  };
  el.querySelector('#aanvKlaar').onclick = sluit;
  el.onclick = (e) => { if (e.target === el) sluit(); };
}

function verbergWijzigOpzet(){
  const el = $('#woAchter');
  if (!el) return;
  el.classList.remove('open');
}

function modalSelectie(opties = {}){
  const w = S.wedstrijd;
  // Vanuit "Achteraf bijwerken": na Klaar/✕ terug naar dat overzicht
  const achteraf = !!opties.terugNaarBijwerk;
  const terugBijwerk = () => { S.bijwerkKwart = opties.kwart || S.bijwerkKwart; toonBijwerkScherm(); };
  let bevestigdVerlies = false;   // "toch afwezig zetten" is bevestigd
  let sel = new Set(w.selectie || []);
  let telaat = new Set(w.telaat || []);   // erbij, maar te laat gekomen
  // wedstrijdminuut waarop een te-late speler erbij was (optioneel, per pid)
  let vanaf = {...(w.telaatVanaf || {})};
  const maxMin = Math.round((w.periodes || 4) * (w.kwartduur || 0)) || 90;
  // afwezig-redenen op de wedstrijd; kopie zodat annuleren niks wijzigt
  let redenen = JSON.parse(JSON.stringify(w.afwezigRedenen || {}));

  /* [20260928e] Selectie met 1e + 2e elftal: eerst de spelers van het elftal
     van deze wedstrijd, dan de rest van de selectie. Wie daar niet meedoet is
     "niet mee" (geen afwezigheid), dus zonder redenkeuze. */
  const tweeElftallen = heeftElftallen() && !isToernooi(w);
  const groepen = tweeElftallen ? spelersVoorElftal(S.spelers, elftalWedstrijd(w)) : { eigen: S.spelers, rest: [] };
  const rijenHtml = () => (tweeElftallen ? `<div class="elf-groep">${elftalNaam(elftalWedstrijd(w))}</div>` : '')
    + groepen.eigen.map(p => rijHtml(p, false)).join('')
    + (groepen.rest.length ? `<div class="elf-groep">Rest van de selectie</div>` + groepen.rest.map(p => rijHtml(p, true)).join('') : '');
  const rijHtml = (p, rest) => {
    const aanwezig = sel.has(p.id);
    const isLaat = aanwezig && telaat.has(p.id);
    const klasse = !aanwezig ? 'afwezig' : (isLaat ? 'telaat' : 'aanwezig');
    const nietMee = !aanwezig && rest && !redenen[p.id];
    const statusTxt = !aanwezig ? (nietMee ? 'Niet mee' : 'Afwezig') : (isLaat ? 'Komt later' : 'Erbij');
    const info = redenen[p.id] ? afwezigRedenInfo(redenen[p.id]) : null;
    return `
    <div class="pres-speler ${klasse}${nietMee ? ' nietmee' : ''}">
      <button type="button" class="pres-speler-kop" data-seltoggle="${p.id}">
        <span class="pres-shirt">${esc(p.nummer ?? '·')}</span>
        <span class="pres-naam">${esc(p.naam)}</span>
        <span class="pres-status">${statusTxt}</span>
      </button>
      ${!aanwezig && !nietMee ? `
      <div class="pres-reden-rij">${AFWEZIG_REDENEN.map(r =>
        `<button type="button" class="pres-reden-chip ${info?.id===r.id?'actief':''}" data-selreden="${r.id}" data-pid="${p.id}">${r.ico?ico(r.ico,16):r.emoji} ${r.label}</button>`).join('')}<button type="button" class="pres-reden-chip telaat-chip" data-seltelaat="${p.id}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.6"/><path d="M12 7.2V12l3.4 2.2"/></svg> Komt later</button></div>
      ${info?.id==='anders' || (info && redenen[p.id]?.notitie) ? `<input class="invoer pres-reden-notitie" data-pid="${p.id}" placeholder="Toelichting (optioneel)" value="${esc(redenen[p.id]?.notitie||'')}">` : ''}
      ` : isLaat ? `
      <div class="pres-telaat-rij"><button type="button" class="pres-reden-chip telaat-chip actief" data-seltelaat="${p.id}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="8.6"/><path d="M12 7.2V12l3.4 2.2"/></svg> Komt later: tik om te wissen</button>
        <label class="telaat-minuut">erbij vanaf min.<input type="number" inputmode="numeric" min="1" max="${maxMin}" class="invoer" data-selvanaf="${p.id}" value="${esc(vanaf[p.id] ?? '')}" placeholder="—"></label></div>
      ` : ''}
    </div>`;
  };

  openModal(`
    <h2>Selectie voor deze wedstrijd</h2>
    <p class="u-t-md u-zacht u-mb-sm">Iedereen staat op <b>erbij</b>. Tik wie er <b>niet</b> is en geef eventueel de reden. Afwezige spelers verschijnen niet op de bank.</p>
    <p class="u-t-sm u-zacht" style="margin:-4px 0 var(--space-sm)">Komt iemand <b>later</b>? Vul in vanaf welke wedstrijdminuut hij erbij was (doorlopend geteld over alle periodes). De tijd daarvóór telt dan niet mee in zijn speeltijd-%.</p>
    <div id="mSelLijst">${rijenHtml()}</div>
    <div id="mSelWaarsch"></div>
    <button class="knop vol u-mt-xs" id="mSelOk" >Klaar</button>
    ${achteraf ? `<button class="knop licht vol u-mt-xs" id="mSelTerug" >‹ Terug naar overzicht</button>` : ''}`);
  if (achteraf){
    kruisNaarBijwerk(terugBijwerk);
    $('#mSelTerug').onclick = terugBijwerk;
  }

  /* Wie uit de selectie gaat, verliest zijn opstellingsplekken, wissels en
     kaarten in deze wedstrijd (zie opschoning hieronder). Heeft hij die al,
     dan eerst waarschuwen — vooral achteraf is dat anders ongemerkt dataverlies. */
  const metGegevens = () => {
    const weg = (w.selectie||[]).filter(pid => !sel.has(pid) && speler(pid));
    return weg.filter(pid =>
      Object.values(w.kwarten||{}).some(kk =>
        Object.values(kk.lineup||{}).includes(pid) ||
        (kk.events||[]).some(e => e.in === pid || e.uit === pid)) ||
      (w.kaarten||[]).some(c => c.pid === pid));
  };
  const resetWaarsch = () => {
    bevestigdVerlies = false;
    $('#mSelWaarsch').innerHTML = '';
    $('#mSelOk').textContent = 'Klaar';
  };
  const koppel = () => {
    $$('#mSelLijst [data-seltoggle]').forEach(b => b.onclick = () => {
      const id = b.dataset.seltoggle;
      if (sel.has(id)){ sel.delete(id); telaat.delete(id); }   // afwezig: geen te-laat
      else { sel.add(id); delete redenen[id]; }
      resetWaarsch();
      $('#mSelLijst').innerHTML = rijenHtml(); koppel();
    });
    // Te-laat chip: afwezige speler terug erbij+vlag, of vlag weer weg. Telt als erbij.
    $$('#mSelLijst [data-seltelaat]').forEach(b => b.onclick = () => {
      const id = b.dataset.seltelaat;
      if (telaat.has(id)){ telaat.delete(id); }
      else { sel.add(id); delete redenen[id]; telaat.add(id); }
      resetWaarsch();
      $('#mSelLijst').innerHTML = rijenHtml(); koppel();
    });
    $$('#mSelLijst [data-selreden]').forEach(b => b.onclick = () => {
      const id = b.dataset.pid, type = b.dataset.selreden;
      const huidig = redenen[id];
      if (huidig && afwezigRedenInfo(huidig).id === type) delete redenen[id];
      else redenen[id] = {type, notitie: huidig?.notitie || ''};
      $('#mSelLijst').innerHTML = rijenHtml(); koppel();
    });
    $$('#mSelLijst [data-selvanaf]').forEach(inp => inp.oninput = () => {
      const id = inp.dataset.selvanaf;
      const m = parseInt(inp.value, 10);
      if (m > 0) vanaf[id] = Math.min(m, maxMin); else delete vanaf[id];
    });
    $$('#mSelLijst .pres-reden-notitie').forEach(inp => inp.oninput = () => {
      const id = inp.dataset.pid;
      if (redenen[id]) redenen[id].notitie = inp.value;
    });
  };
  koppel();

  $('#mSelOk').onclick = () => {
    const verlies = metGegevens();
    if (verlies.length && !bevestigdVerlies){
      bevestigdVerlies = true;
      $('#mSelWaarsch').innerHTML = `<div class="waarschuwing u-mt-xs"><span><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M12 4.2 21 19.4H3z"/><path d="M12 10v4.2"/><circle cx="12" cy="17" r="0.7" fill="currentColor" stroke="none"/></svg></span><span><b>${verlies.map(pid => esc(spelerNaam(pid))).join(', ')}</b> ${verlies.length === 1 ? 'heeft' : 'hebben'} al opstelling, wissels of kaarten in deze wedstrijd. Afwezig zetten wist die, en daarmee ook de speeltijd. Tik nog een keer om toch op te slaan.</span></div>`;
      $('#mSelOk').textContent = 'Toch opslaan';
      return;
    }
    w.selectie = [...sel];
    // alleen te-laat-vlaggen bewaren van wie ook echt in de selectie zit
    w.telaat = [...telaat].filter(pid => sel.has(pid));
    // minuut alleen bewaren voor wie ook echt als te laat staat
    const schoonVanaf = {};
    for (const pid of w.telaat) if (vanaf[pid] > 0) schoonVanaf[pid] = vanaf[pid];
    w.telaatVanaf = schoonVanaf;
    // alleen redenen bewaren van wie ook echt afwezig is
    const schoon = {};
    for (const [pid, r] of Object.entries(redenen)) if (!sel.has(pid)) schoon[pid] = r;
    w.afwezigRedenen = schoon;
    telGebruik('selectie_kiezen');
    const toegestaan = new Set(w.selectie);
    for (const kk of Object.values(w.kwarten)){
      for (const [slot, pid] of Object.entries(kk.lineup)) if (!toegestaan.has(pid)) delete kk.lineup[slot];
      kk.events = kk.events.filter(e => (!e.in || toegestaan.has(e.in)) && (!e.uit || toegestaan.has(e.uit)));
      kk.plan = (kk.plan||[]).filter(p => (p.in === WISSEL_BEURT || toegestaan.has(p.in)) && toegestaan.has(p.uit));
    }
    w.kaarten = (w.kaarten||[]).filter(c => toegestaan.has(c.pid));
    for (const nr of Object.keys(w.aanvoerders||{}))
      if (w.aanvoerders[nr] && !toegestaan.has(w.aanvoerders[nr])) w.aanvoerders[nr] = null;
    if (w.aanvoerder && !toegestaan.has(w.aanvoerder)) w.aanvoerder = null;
    if (achteraf){ bewaarWedstrijd(); renderWedstrijd(); meld('Selectie bijgewerkt'); terugBijwerk(); return; }
    sluitModal(); bewaarWedstrijd(); renderWedstrijd();
  };
}

/* ==================== TIKKEN (geen slepen meer — verticaal scrollen blijft werken) ==================== */
/* Zoekt of er onder de tik-locatie een LEEG veldvak ligt (een .slot zonder
   speler-chip). Nodig omdat een breed naam-label van een naburige chip soms
   over een leeg vak heen steekt en de tik "opvangt"; dankzij deze check landt
   de speler dan toch in het bedoelde lege vak. Retourneert de slot-id of null. */
function leegSlotOnderPunt(ev, negeerPid){
  const x = ev.clientX, y = ev.clientY;
  if (x == null || y == null || !document.elementsFromPoint) return null;
  const onder = document.elementsFromPoint(x, y);
  for (const el of onder){
    const slot = el.closest && el.closest('.slot');
    if (!slot) continue;
    const chip = slot.querySelector('[data-chip]');
    if (!chip) return slot.dataset.slot;            // leeg vak → dit bedoelen we
    if (negeerPid && chip.dataset.chip === negeerPid) continue; // eigen chip: kijk verder
    return null;                                    // ander bezet vak: niet stelen
  }
  return null;
}

function koppelSleep(v){
  const veld = v.querySelector('#veld');
  const bank = v.querySelector('#bank');

  // tik op een chip: selecteer/deselecteer, of wissel met al-geselecteerde speler
  v.querySelectorAll('[data-chip]').forEach(chip => {
    chip.addEventListener('click', ev => {
      ev.stopPropagation();
      const pid = chip.dataset.chip;
      const bron = chip.dataset.bron;
      if (S.geselecteerd && S.geselecteerd.pid !== pid){
        const k = huidigKwart(), l = effectieveLineup(k);
        // Als er al een speler geselecteerd is en de tik landt (deels) op een
        // LEEG veldvak dat onder het brede naam-label van deze chip uitsteekt,
        // dan bedoelt de coach dat lege vak — niet deze chip. Plaats daar.
        // (Anders kon een naburige naam een leeg slot "blokkeren".)
        const leegSlot = leegSlotOnderPunt(ev, pid);
        if (leegSlot){ plaats(S.geselecteerd.pid, leegSlot); return; }
        // staat de getikte speler op het veld? dan ruilen we van plek
        const slot = Object.keys(l).find(s => l[s] === pid);
        if (slot){ plaats(S.geselecteerd.pid, slot); return; }
      }
      S.geselecteerd = S.geselecteerd?.pid === pid ? null : {pid, bron};
      renderWedstrijd();
    });
  });

  v.querySelectorAll('[data-bankreden]').forEach(b => b.addEventListener('click', ev => {
    ev.stopPropagation();
    modalStartBankReden(b.dataset.bankreden);
  }));

  // tik op een leeg veldvak: plaats de geselecteerde speler daar.
  // Eén gedelegeerde handler op het hele veld (i.p.v. per slot), zodat een tik
  // op de rand van een slot of op de 'M1'-ring altijd wordt opgevangen — ook
  // bij zelfgemaakte formaties. Klikken op een veldspeler-chip wordt door de
  // chip-handler zelf afgehandeld (met stopPropagation), dus die botst niet.
  veld.addEventListener('click', ev => {
    if (!S.geselecteerd) return;
    if (ev.target.closest('.veld-overlay')) return;        // badge/Speelwijze-knop
    // eerst: valt de tik op (of over) een leeg slot? dan dat vullen
    const leeg = leegSlotOnderPunt(ev, S.geselecteerd.pid);
    if (leeg){ plaats(S.geselecteerd.pid, leeg); return; }
    if (ev.target.closest('[data-chip]')) return;         // chip regelt zichzelf
    const slotEl = ev.target.closest('.slot');
    if (!slotEl) return;
    plaats(S.geselecteerd.pid, slotEl.dataset.slot);
  });

  // tik op de bank: haal de geselecteerde veldspeler naar de bank
  bank.addEventListener('click', ev => {
    if (!S.geselecteerd || S.geselecteerd.bron !== 'veld') return;
    if (ev.target.closest('[data-chip],button')) return;
    naarBank(S.geselecteerd.pid);
  });
}
